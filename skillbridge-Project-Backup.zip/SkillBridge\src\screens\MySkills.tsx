import { useState } from "react";
import { SKILL_CATEGORIES, categoryOf, ALL_SKILLS } from "../lib/catalog";
import { LEVELS, levelLabel, useStore } from "../lib/store";

const statusColors: Record<string, string> = {
  verified: "bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300",
  assessed: "bg-sky-100 text-sky-700 dark:bg-sky-950/60 dark:text-sky-300",
  self: "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300",
};
const statusLabel: Record<string, string> = { verified: "✓ Verified", assessed: "Assessed", self: "Self-reported" };

const getSkillGradient = (n: number) => {
  if (n < 40) return "linear-gradient(90deg, #F43F5E 0%, #DC2626 100%)";
  if (n < 65) return "linear-gradient(90deg, #3B82F6 0%, #4F46E5 100%)";
  if (n < 85) return "linear-gradient(90deg, #F59E0B 0%, #D97706 100%)";
  return "linear-gradient(90deg, #10B981 0%, #059669 100%)";
};

export default function MySkills() {
  const { state, patch, skills } = useStore();
  const [filter, setFilter] = useState("All");
  const [adding, setAdding] = useState(false);
  const [newSkill, setNewSkill] = useState("");
  const [newLevel, setNewLevel] = useState<number>(LEVELS.Beginner);

  const filters = ["All", ...SKILL_CATEGORIES.map((c) => c.category)];
  const entries = Object.entries(skills);
  const count = (s: string) => entries.filter(([, v]) => v.status === s).length;
  const groups = SKILL_CATEGORIES.filter((c) => filter === "All" || c.category === filter)
    .map((c) => ({ category: c.category, skills: entries.filter(([n]) => categoryOf(n) === c.category) }))
    .filter((g) => g.skills.length > 0);
  const addable = ALL_SKILLS.filter((s) => !skills[s]);

  const setLevel = (name: string, level: number) => patch((s) => ({ selected: { ...s.selected, [name]: level } }));
  const remove = (name: string) => patch((s) => { const sel = { ...s.selected }; delete sel[name]; return { selected: sel }; });

  return (
    <div className="p-5 max-w-5xl mx-auto">
      <div className="mb-6">
        <h1 className="text-xl font-semibold text-slate-800">My Skills</h1>
        <p className="text-sm text-slate-500 mt-0.5">
          {entries.length} skills tracked · {count("assessed")} assessed · {count("verified")} verified
        </p>
      </div>

      {/* Summary row: three separate statuses */}
      <div className="grid grid-cols-3 gap-3 mb-2">
        <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-center">
          <p className="text-2xl font-bold text-slate-700 font-mono">{count("self")}</p>
          <p className="text-xs text-slate-500 mt-0.5">Self-reported</p>
        </div>
        <div className="bg-sky-50 border border-sky-100 rounded-2xl p-4 text-center">
          <p className="text-2xl font-bold text-sky-700 font-mono">{count("assessed")}</p>
          <p className="text-xs text-sky-600 mt-0.5">Assessed</p>
        </div>
        <div className="bg-emerald-50 border border-emerald-100 rounded-2xl p-4 text-center">
          <p className="text-2xl font-bold text-emerald-700 font-mono">{count("verified")}</p>
          <p className="text-xs text-emerald-600 mt-0.5">Verified</p>
        </div>
      </div>
      <p className="text-[11px] text-slate-400 mb-5">Skills are never verified automatically. “Verified” requires review by an external mentor or recruiter, which is not available in this prototype.</p>

      {/* Filter tabs */}
      <div className="flex gap-2 flex-wrap mb-5">
        {filters.map((f) => (
          <button key={f} onClick={() => setFilter(f)}
            className={`text-xs px-3 py-1.5 rounded-lg font-medium transition-all ${filter === f ? "bg-indigo-600 text-white" : "bg-white border border-slate-200 text-slate-600 hover:border-indigo-300"}`}>
            {f}
          </button>
        ))}
      </div>

      <div className="space-y-4">
        {groups.map((cat) => (
          <div key={cat.category} className="bg-white rounded-2xl border border-slate-200 p-5">
            <p className="text-sm font-semibold text-slate-700 mb-4">{cat.category}</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {cat.skills.map(([name, skill]) => (
                <div key={name} className="group p-3 rounded-xl bg-slate-50 hover:bg-indigo-50/50 transition-colors">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <p className="text-sm font-medium text-slate-800">{name}</p>
                      <p className="text-[11px] text-slate-500">{levelLabel(skill.level)}</p>
                    </div>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${statusColors[skill.status]}`}>{statusLabel[skill.status]}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-2 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden shadow-2xs">
                      <div className="h-full rounded-full transition-all duration-500" style={{ width: `${skill.level}%`, background: getSkillGradient(skill.level) }} />
                    </div>
                    <span className="text-[11px] font-mono font-bold text-slate-700 dark:text-slate-300 w-9 text-right">{skill.level}%</span>
                  </div>
                  <div className="mt-2 flex items-center gap-1.5 flex-wrap">
                    {skill.status === "self" ? (
                      <>
                        {(Object.entries(LEVELS) as [string, number][]).map(([label, v]) => (
                          <button key={label} onClick={() => setLevel(name, v)}
                            className={`text-[10px] px-2 py-0.5 rounded-full border ${levelLabel(skill.level) === label ? "bg-indigo-100 text-indigo-700 border-indigo-200" : "bg-white border-slate-200 text-slate-500 hover:border-indigo-300"}`}>{label}</button>
                        ))}
                        <button onClick={() => remove(name)} className="text-[10px] text-slate-400 hover:text-rose-600 ml-auto">Remove</button>
                      </>
                    ) : (
                      <span className="text-[10px] text-slate-400">Level set by {skill.status === "assessed" ? "your diagnostic assessment" : "a reviewer"}</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Add skill */}
      {!adding ? (
        <button onClick={() => { setAdding(true); setNewSkill(addable[0] ?? ""); }} disabled={addable.length === 0}
          className="mt-4 w-full py-3 rounded-2xl border-2 border-dashed border-slate-300 text-sm text-slate-500 hover:border-indigo-400 hover:text-indigo-600 transition-colors font-medium disabled:opacity-40">
          + Add a skill
        </button>
      ) : (
        <div className="mt-4 bg-white rounded-2xl border border-slate-200 p-4 flex flex-wrap items-end gap-3">
          <div className="flex-1 min-w-40">
            <label className="text-xs font-medium text-slate-600 block mb-1">Skill</label>
            <select value={newSkill} onChange={(e) => setNewSkill(e.target.value)} className="w-full text-sm border border-slate-200 rounded-xl px-3 py-2 bg-white outline-none focus:ring-2 focus:ring-indigo-300">
              {addable.map((s) => <option key={s}>{s}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs font-medium text-slate-600 block mb-1">Your level</label>
            <select value={newLevel} onChange={(e) => setNewLevel(Number(e.target.value))} className="text-sm border border-slate-200 rounded-xl px-3 py-2 bg-white outline-none focus:ring-2 focus:ring-indigo-300">
              {Object.entries(LEVELS).map(([l, v]) => <option key={l} value={v}>{l}</option>)}
            </select>
          </div>
          <button onClick={() => { if (newSkill) setLevel(newSkill, newLevel); setAdding(false); }} className="text-sm px-4 py-2 bg-indigo-600 text-white rounded-xl font-medium hover:bg-indigo-700">Add (self-reported)</button>
          <button onClick={() => setAdding(false)} className="text-sm px-3 py-2 text-slate-500">Cancel</button>
        </div>
      )}
    </div>
  );
}
