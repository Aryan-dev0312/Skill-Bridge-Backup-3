import React from "react";
import logoPng from "../assets/logo.png";

export interface BrandLogoProps {
  size?: "xs" | "sm" | "md" | "lg" | "xl";
  variant?: "full" | "icon" | "horizontal";
  showText?: boolean;
  className?: string;
  badge?: string;
  onClick?: () => void;
}

export default function BrandLogo({
  size = "md",
  variant = "horizontal",
  showText = true,
  className = "",
  badge,
  onClick,
}: BrandLogoProps) {
  // Dimensions for container sizing
  const dimensions = {
    xs: { icon: "w-6 h-6", text: "text-xs", img: "h-6" },
    sm: { icon: "w-7 h-7", text: "text-sm", img: "h-7" },
    md: { icon: "w-9 h-9", text: "text-base", img: "h-9" },
    lg: { icon: "w-12 h-12", text: "text-lg", img: "h-12" },
    xl: { icon: "w-20 h-20", text: "text-2xl", img: "h-20" },
  }[size];

  // If user requests full original image logo
  if (variant === "full") {
    return (
      <div
        onClick={onClick}
        className={`inline-flex flex-col items-center select-none ${onClick ? "cursor-pointer" : ""} ${className}`}
      >
        <div className="relative flex items-center justify-center p-2 rounded-2xl bg-white/95 dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs">
          <img
            src={logoPng}
            alt="SkillBridge Official Logo"
            className={`${dimensions.img} w-auto object-contain dark:invert dark:contrast-200 transition-all`}
          />
        </div>
      </div>
    );
  }

  // If user requests horizontal lockup: icon + brand name
  return (
    <div
      onClick={onClick}
      className={`inline-flex items-center gap-2.5 select-none ${onClick ? "cursor-pointer" : ""} ${className}`}
    >
      {/* Mortarboard Emblem Container */}
      <div
        className={`relative ${dimensions.icon} rounded-xl bg-slate-950 dark:bg-white text-white dark:text-slate-950 flex items-center justify-center shadow-xs shrink-0 overflow-hidden transition-transform duration-200 hover:scale-105 border border-slate-800 dark:border-slate-200`}
      >
        {/* Authentic Mortarboard with S-Ribbon Vector */}
        <svg
          viewBox="0 0 100 100"
          className="w-4/5 h-4/5 fill-current"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Mortarboard Cap Top Diamond */}
          <path
            d="M 50 18 L 88 38 L 50 58 L 12 38 Z"
            fill="none"
            stroke="currentColor"
            strokeWidth="8"
            strokeLinejoin="round"
            strokeLinecap="round"
          />
          {/* Mortarboard Lower Skull Cap */}
          <path
            d="M 28 47 L 28 66 L 50 78"
            fill="none"
            stroke="currentColor"
            strokeWidth="8"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          {/* Stylized S Ribbon Drop */}
          <path
            d="M 72 38 L 72 74"
            fill="none"
            stroke="currentColor"
            strokeWidth="8"
            strokeLinecap="round"
          />
          <path
            d="M 50 78 L 72 74"
            fill="none"
            stroke="currentColor"
            strokeWidth="8"
            strokeLinecap="round"
          />
        </svg>
      </div>

      {showText && (
        <div className="flex items-center gap-1.5 leading-none">
          <div className="flex flex-col">
            <span
              className={`font-bold tracking-tight text-slate-900 dark:text-white ${dimensions.text} font-sans`}
            >
              SkillBridge
            </span>
          </div>
          {badge && (
            <span className="text-[10px] font-semibold text-indigo-700 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-800 px-1.5 py-0.5 rounded-md font-mono">
              {badge}
            </span>
          )}
        </div>
      )}
    </div>
  );
}
