export type Language = "en" | "hi";

const LANG_KEY = "skillbridge_lang";

export function getStoredLanguage(): Language {
  try {
    const saved = localStorage.getItem(LANG_KEY);
    if (saved === "en" || saved === "hi") return saved;
  } catch {
    /* ignore */
  }
  return "en";
}

export function setStoredLanguage(lang: Language) {
  try {
    localStorage.setItem(LANG_KEY, lang);
  } catch {
    /* ignore */
  }
}

export const TRANSLATIONS: Record<Language, Record<string, string>> = {
  en: {
    // Nav
    overview: "Overview",
    career: "Career",
    skills: "My Skills",
    gap: "Skill Gap",
    roadmap: "Roadmap",
    opportunities: "Opportunities",
    projects: "Projects",
    progress: "Progress",
    companies: "Companies",
    technologies: "Technologies",
    trends: "Industry Trends",
    insights: "Employability Insights",
    resources: "Learning Resources",
    college: "College",
    collegePortal: "College Analytics Portal",
    industryPortal: "Industry Portal",
    studentPortal: "Student Portal",
    companyDashboard: "Company Dashboard",

    // Header & Actions
    searchPlaceholder: "Search skills, roles, companies...",
    takeAssessment: "15-Min Assessment",
    student: "Student",
    industry: "Industry",
    editProfile: "Edit profile",
    resetData: "Reset data",
    saveChanges: "Save Changes",
    saved: "Saved!",
    cancel: "Cancel",
    confirm: "Confirm",
    back: "Back",
    next: "Next",
    submit: "Submit",
    close: "Close",

    // Profile Menu
    myProfile: "My Profile",
    instructions: "Instructions",
    settings: "Settings",
    appearance: "Appearance",
    language: "Language",
    getHelp: "Get Help",
    learnMore: "Learn More",
    signOut: "Sign Out",
    darkMode: "Dark Mode",
    lightMode: "Light Mode",
    systemDefault: "System Default",
    english: "English",
    hindi: "हिन्दी (Hindi)",

    // Assessment
    assessmentTitle: "15-Minute Comprehensive Technical Assessment",
    assessmentSubtitle: "Evaluate your practical and conceptual understanding across 9 core engineering domains.",
    startAssessment: "Start Assessment",
    timeRemaining: "Time Remaining",
    question: "Question",
    of: "of",
    markForReview: "Mark for Review",
    markedForReview: "Marked for Review",
    submitAssessment: "Submit Assessment",
    answered: "Answered",
    unanswered: "Unanswered",
    score: "Score",
    accuracy: "Accuracy",
    strongestAreas: "Strongest Areas",
    weakestAreas: "Areas Needing Improvement",
    recommendedNextSteps: "Recommended Next Steps",
    retakeAssessment: "Retake Assessment",
    applyToProfile: "Apply to Assessed Skills Profile",
    reviewAnswers: "Review Question Explanations",

    // Common
    selfReported: "Self-reported",
    assessed: "Assessed",
    verified: "Verified",
    readiness: "Career Readiness",
    gaps: "Skill Gaps",
    highPriority: "High Priority",
  },
  hi: {
    // Nav
    overview: "अवलोकन (Overview)",
    career: "करियर (Career)",
    skills: "मेरे कौशल (My Skills)",
    gap: "स्किल गैप (Skill Gap)",
    roadmap: "रोडमैप (Roadmap)",
    opportunities: "अवसर (Opportunities)",
    projects: "प्रोजेक्ट्स (Projects)",
    progress: "प्रगति (Progress)",
    companies: "कंपनियां (Companies)",
    technologies: "तकनीकें (Technologies)",
    trends: "उद्योग रुझान (Trends)",
    insights: "रोजगार अंतर्दृष्टि (Insights)",
    resources: "सीखने के संसाधन (Resources)",
    college: "कॉलेज (College)",
    collegePortal: "कॉलेज एनालिटिक्स पोर्टल",
    industryPortal: "इंडस्ट्री पोर्टल",
    studentPortal: "विद्यार्थी पोर्टल",
    companyDashboard: "कंपनी डैशबोर्ड",

    // Header & Actions
    searchPlaceholder: "कौशल, भूमिकाएँ, कंपनियाँ खोजें...",
    takeAssessment: "15-मिनट मूल्यांकन",
    student: "विद्यार्थी",
    industry: "उद्योग",
    editProfile: "प्रोफ़ाइल संपादित करें",
    resetData: "डेटा रीसेट करें",
    saveChanges: "बदलाव सहेजें",
    saved: "सहेजा गया!",
    cancel: "रद्द करें",
    confirm: "पुष्टि करें",
    back: "पीछे जाएं",
    next: "आगे बढ़ें",
    submit: "जमा करें",
    close: "बंद करें",

    // Profile Menu
    myProfile: "मेरी प्रोफ़ाइल",
    instructions: "निर्देश (Instructions)",
    settings: "सेटिंग्स (Settings)",
    appearance: "दिखावट (Appearance)",
    language: "भाषा (Language)",
    getHelp: "सहायता प्राप्त करें (Get Help)",
    learnMore: "और जानें (Learn More)",
    signOut: "साइन आउट (Sign Out)",
    darkMode: "डार्क मोड",
    lightMode: "लाइट मोड",
    systemDefault: "सिस्टम डिफ़ॉल्ट",
    english: "English",
    hindi: "हिन्दी (Hindi)",

    // Assessment
    assessmentTitle: "15-मिनट व्यापक तकनीकी मूल्यांकन",
    assessmentSubtitle: "9 मुख्य इंजीनियरिंग क्षेत्रों में अपने व्यावहारिक और वैचारिक ज्ञान का मूल्यांकन करें।",
    startAssessment: "मूल्यांकन प्रारंभ करें",
    timeRemaining: "शेष समय",
    question: "प्रश्न",
    of: "का",
    markForReview: "समीक्षा के लिए चिह्नित करें",
    markedForReview: "समीक्षा के लिए चिह्नित",
    submitAssessment: "मूल्यांकन जमा करें",
    answered: "उत्तर दिया गया",
    unanswered: "अनुत्तरित",
    score: "प्राप्तांक",
    accuracy: "सटीकता",
    strongestAreas: "मजबूत क्षेत्र",
    weakestAreas: "सुधार की आवश्यकता वाले क्षेत्र",
    recommendedNextSteps: "अनुशंसित अगले कदम",
    retakeAssessment: "पुनः मूल्यांकन लें",
    applyToProfile: "कौशल प्रोफ़ाइल में लागू करें",
    reviewAnswers: "प्रश्नों और उत्तरों की व्याख्या देखें",

    // Common
    selfReported: "स्वयं-रिपोर्ट किया गया",
    assessed: "मूल्यांकित (Assessed)",
    verified: "सत्यापित (Verified)",
    readiness: "करियर तत्परता",
    gaps: "कौशल अंतराल (Skill Gaps)",
    highPriority: "उच्च प्राथमिकता",
  },
};

export function t(key: string, lang: Language = getStoredLanguage()): string {
  if (TRANSLATIONS[lang] && TRANSLATIONS[lang][key]) {
    return TRANSLATIONS[lang][key];
  }
  return TRANSLATIONS.en[key] ?? key;
}
