export interface MetricMetadata {
  dataSource: string;
  reportingPeriod: string;
  sampleSize: string;
  lastUpdated: string;
  explanation: string;
  category: "Official College Placement" | "Public Industry Survey" | "Self-Reported" | "Assessed Benchmark" | "Demo Cohort";
}

export interface InDemandSkill {
  skill: string;
  demandPercentage: number; // % of tech job descriptions requiring this skill
  growthRate: string; // YoY growth
  category: string;
}

export interface PlacementCorrelation {
  skill: string;
  placementRateProficient: number; // % placed when proficient (>= 70%)
  placementRateBaseline: number; // overall cohort baseline
  samplePlacedCount: number;
}

export interface SkillCombination {
  combination: string[];
  frequency: number; // % of placed tech profiles with this bundle
  roleMatch: string;
  avgPackageLPA: number;
}

export interface RoleSkillRequirement {
  role: string;
  primarySkills: { name: string; target: number }[];
  emergingSkills: string[];
  hiringPrevalence: number;
}

export interface CommonMissingSkill {
  skill: string;
  gapPercentage: number; // % of candidates who fail benchmark
  curriculumGapReason: string;
}

// 1. In-Demand Skills in Job Postings
export const IN_DEMAND_SKILLS: InDemandSkill[] = [
  { skill: "Python", demandPercentage: 74, growthRate: "+18% YoY", category: "Programming" },
  { skill: "SQL & Relational DBs", demandPercentage: 68, growthRate: "+12% YoY", category: "Data & Systems" },
  { skill: "Data Structures & Algos", demandPercentage: 66, growthRate: "Stable Core", category: "Foundations" },
  { skill: "JavaScript / TypeScript", demandPercentage: 62, growthRate: "+15% YoY", category: "Web" },
  { skill: "Cloud Platforms (AWS/GCP)", demandPercentage: 58, growthRate: "+28% YoY", category: "Cloud" },
  { skill: "Docker & Containers", demandPercentage: 54, growthRate: "+31% YoY", category: "DevOps" },
  { skill: "System Design", demandPercentage: 49, growthRate: "+22% YoY", category: "Architecture" },
  { skill: "Machine Learning / PyTorch", demandPercentage: 42, growthRate: "+45% YoY", category: "AI/ML" },
];

export const IN_DEMAND_META: MetricMetadata = {
  dataSource: "LinkedIn Economic Graph & Stack Overflow Annual Developer Survey",
  reportingPeriod: "CY 2024 (January - December 2024)",
  sampleSize: "N = 65,437 professional tech developer respondents & 1.2M job listings",
  lastUpdated: "October 2024",
  explanation: "Reflects the proportion of software engineering, cloud, and data postings explicitly requesting competency in each technical skill or technology stack.",
  category: "Public Industry Survey",
};

// 2. Placement Correlation vs Skill Proficiency
export const PLACEMENT_CORRELATIONS: PlacementCorrelation[] = [
  { skill: "System Design & Caching", placementRateProficient: 91, placementRateBaseline: 64, samplePlacedCount: 38 },
  { skill: "Cloud (AWS / GCP / Docker)", placementRateProficient: 88, placementRateBaseline: 64, samplePlacedCount: 42 },
  { skill: "Data Structures & Algorithms", placementRateProficient: 86, placementRateBaseline: 64, samplePlacedCount: 56 },
  { skill: "SQL & Complex Querying", placementRateProficient: 82, placementRateBaseline: 64, samplePlacedCount: 49 },
  { skill: "React / Modern Frontend", placementRateProficient: 79, placementRateBaseline: 64, samplePlacedCount: 45 },
  { skill: "Machine Learning & PyTorch", placementRateProficient: 84, placementRateBaseline: 64, samplePlacedCount: 29 },
];

export const PLACEMENT_CORRELATION_META: MetricMetadata = {
  dataSource: "Institutional Placement Cell Database (Aggregated Campus Benchmark)",
  reportingPeriod: "Academic Year 2023–2024",
  sampleSize: "N = 480 engineering candidates surveyed post-recruitment drive",
  lastUpdated: "September 2024",
  explanation: "Compares the on-campus placement clearance rate of candidates who demonstrated benchmark proficiency (>= 70%) in a skill against the general student body baseline (64%).",
  category: "Demo Cohort",
};

// 3. Winning Skill Bundles / Combinations
export const SKILL_COMBINATIONS: SkillCombination[] = [
  {
    combination: ["Python", "SQL", "Docker", "FastAPI"],
    frequency: 34,
    roleMatch: "Backend / API Engineer",
    avgPackageLPA: 14.5,
  },
  {
    combination: ["React", "TypeScript", "Node.js", "PostgreSQL"],
    frequency: 28,
    roleMatch: "Full Stack Engineer",
    avgPackageLPA: 13.8,
  },
  {
    combination: ["Python", "PyTorch", "NumPy/Pandas", "SQL"],
    frequency: 22,
    roleMatch: "AI / Data Science Engineer",
    avgPackageLPA: 16.2,
  },
  {
    combination: ["C++", "Data Structures", "Linux/Shell", "Networking"],
    frequency: 18,
    roleMatch: "Systems & Embedded Engineer",
    avgPackageLPA: 15.0,
  },
  {
    combination: ["Cloud Platforms", "Terraform", "Docker", "CI/CD"],
    frequency: 16,
    roleMatch: "DevOps & Cloud Engineer",
    avgPackageLPA: 15.8,
  },
];

export const SKILL_COMBINATIONS_META: MetricMetadata = {
  dataSource: "Campus Hiring Offer Letter Disclosures & Candidate Skill Matrices",
  reportingPeriod: "Placement Season 2023–2024",
  sampleSize: "N = 312 placed engineering offers across Tier-1/Tier-2 recruiting partners",
  lastUpdated: "November 2024",
  explanation: "Identifies multi-skill clusters that most frequently co-occurred in candidate resumes that secured verified employment offers, along with mean starting CTC.",
  category: "Demo Cohort",
};

// 4. Role-wise Skill Requirements Matrix
export const ROLE_REQUIREMENTS: RoleSkillRequirement[] = [
  {
    role: "Full Stack Engineer",
    primarySkills: [
      { name: "React", target: 80 },
      { name: "Node.js / Express", target: 75 },
      { name: "SQL", target: 70 },
      { name: "Git", target: 75 },
    ],
    emergingSkills: ["Next.js", "Docker", "Tailwind CSS"],
    hiringPrevalence: 38,
  },
  {
    role: "AI / ML Engineer",
    primarySkills: [
      { name: "Python", target: 85 },
      { name: "Machine Learning", target: 80 },
      { name: "PyTorch", target: 70 },
      { name: "Statistics", target: 75 },
    ],
    emergingSkills: ["LLMs", "RAG", "Vector Databases", "MLflow"],
    hiringPrevalence: 24,
  },
  {
    role: "Backend & Systems",
    primarySkills: [
      { name: "Data Structures", target: 85 },
      { name: "System Design", target: 75 },
      { name: "SQL", target: 75 },
      { name: "Linux/Shell", target: 70 },
    ],
    emergingSkills: ["Go", "Kafka", "Redis", "Distributed Caching"],
    hiringPrevalence: 26,
  },
  {
    role: "Cloud & DevOps",
    primarySkills: [
      { name: "Cloud Platforms", target: 80 },
      { name: "Docker", target: 75 },
      { name: "CI/CD", target: 70 },
      { name: "Networking", target: 70 },
    ],
    emergingSkills: ["Kubernetes", "Terraform", "Prometheus"],
    hiringPrevalence: 18,
  },
];

export const ROLE_REQUIREMENTS_META: MetricMetadata = {
  dataSource: "NASSCOM FutureSkills Talent Architecture & Technical Hiring Guidelines",
  reportingPeriod: "CY 2024",
  sampleSize: "Synthesized from 42 enterprise hiring partners",
  lastUpdated: "August 2024",
  explanation: "Standardized target proficiency requirements benchmarked across corporate technical screening ladders.",
  category: "Public Industry Survey",
};

// 5. Most Commonly Missing Skills (Curriculum Gaps)
export const MOST_MISSING_SKILLS: CommonMissingSkill[] = [
  {
    skill: "System Design & Scalability",
    gapPercentage: 68,
    curriculumGapReason: "University CS syllabi emphasize single-machine OS and DBMS theory rather than distributed systems, load balancing, or horizontal partitioning.",
  },
  {
    skill: "Docker & Container Workflows",
    gapPercentage: 61,
    curriculumGapReason: "Students learn local code compilation; practical multi-tier orchestration and container isolation are rarely required in semester coursework.",
  },
  {
    skill: "Production SQL Query Tuning",
    gapPercentage: 54,
    curriculumGapReason: "Exams focus on relational algebra and basic 3NF schema design without practical EXPLAIN ANALYZE index profiling or high-volume load simulation.",
  },
  {
    skill: "CI/CD & Git Collaboration",
    gapPercentage: 47,
    curriculumGapReason: "Academic assignments are submitted individually via LMS rather than branch-protected GitHub pull requests with automated test suites.",
  },
  {
    skill: "Cloud Infrastructure Setup",
    gapPercentage: 43,
    curriculumGapReason: "Lack of institutional cloud credit allocations leaves students practicing on localhost rather than live VPCs, IAM roles, and S3/CDN endpoints.",
  },
];

export const MISSING_SKILLS_META: MetricMetadata = {
  dataSource: "SkillBridge Pre-Placement Assessment Engine Diagnostic Datasets",
  reportingPeriod: "AY 2024 (Semester 5 & 7 cohorts)",
  sampleSize: "N = 820 undergraduate engineering candidates",
  lastUpdated: "October 2024",
  explanation: "Percentage of evaluated students scoring below acceptable baseline proficiency (< 50%) in diagnostic technical interviews prior to remedial training.",
  category: "Assessed Benchmark",
};
