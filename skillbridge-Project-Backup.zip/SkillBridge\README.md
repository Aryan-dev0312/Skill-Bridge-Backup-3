# SkillBridge — AI Career & Technical Skill Navigator

SkillBridge is an autonomous career navigation, technical skill benchmarking, and institutional placement analytics platform engineered to align student proficiencies with current tech industry expectations.

It bridges the gap between academic curricula and real-world hiring standards through objective multi-domain assessments, weighted skill-gap analytics, personalized milestone-driven learning roadmaps, and verified educational resources.

---

## Key Features

1. **Official Brand Logo & Startup Splash Animation:**
   * Official brand identity featuring the stylized graduation cap with ribbon monogram.
   * Smooth Instagram-style logo splash screen on session launch with scale-up and radiant atmospheric glow.
   * Respects `prefers-reduced-motion` accessibility settings and session caching.
2. **Student Performance Dashboard:**
   * Codility-inspired analytics with a Gaussian normal distribution bell curve, 4-metric readiness strip, notification stream, featured quick-action cards, and candidate screening results.
3. **15-Minute Comprehensive Technical Assessment & Integrity Suite:**
   * 30 conceptual, practical, and scenario-based questions across 9 engineering domains.
   * Real-time 15-minute countdown timer with automatic submission upon timeout.
   * **Strict Tab-Switch & Window Focus Integrity:** Powered by the browser Page Visibility API; automatically submits if the candidate leaves the window or switches tabs (`submissionReason: "tab_switch_auto_submit"`).
   * Question navigation palette (1–30), "Mark for Review" flagging, and answered/unanswered counters.
   * Full assessment scorecard report with domain breakdowns, percentile rankings, in-depth question review with technical explanations, and past attempt verification logs.
4. **Skills & Employment Insights:**
   * Market analytics covering skills requested in job descriptions, placement clearance correlations, winning multi-skill combinations with starting CTC benchmarks, and curriculum blind spots.
   * Strict data source standards: every statistic includes explicit data sources, reporting periods, sample sizes ($N$), and definitions.
5. **College Placement & Skill Analytics Portal:**
   * University-wide skill distribution and department performance comparisons (CSE, IT, ECE, AI&DS).
   * Interactive CSV / Excel upload & column-mapping wizard with client-side validation, error/warning diagnostics, and data preview.
   * Student cohort roster with real-time search, department filtering, and placement status tracking.
6. **Smart Learning Resource Recommendations:**
   * Curated, verified educational resources across 11 technical domains (Web, Cloud, DSA, System Design, AI/ML, Security, DevOps, Mobile, Databases, Git, and Interview Prep).
   * Full-text search, domain filters, difficulty filters, bookmarking ("Save for later"), and completion tracking ("Mark as Completed").
7. **Authentic Official Company Logos:** High-resolution transparent vector logos for top technology firms including NVIDIA, Google, Microsoft, Amazon, Qualcomm, Adobe, Intel, OpenAI, Salesforce, and Cisco.
8. **Skill Gap Analyzer & Roadmap:** Weighted requirement calculations classifying gaps into High, Medium, and Low severity tiers, with phase-by-phase task roadmaps automatically scaled to the student's target role and weekly study hours.
9. **Projects & 3-Tier Verification:** Strict distinction between *Self-Reported*, *Assessed*, and *Verified* skills with project code evidence tracking.
10. **Appearance System & Bilingual i18n:** Full Dark Mode, Light Mode, and System Default support with WCAG 2.2 AA compliant contrast ratios, plus complete English and हिन्दी (Hindi) localization.

---

## Tech Stack

* **Frontend:** React 19, TypeScript 5.7
* **Build Tooling:** Vite 8, Rolldown
* **Styling:** Tailwind CSS v4 (`@tailwindcss/vite`), CSS Variables
* **Charts & Visualizations:** Recharts, Custom SVGs
* **State Management:** React Context + LocalStorage persistence

---

## Prerequisites

* **Node.js:** v20.0.0 or higher (v24 LTS recommended)
* **npm:** v10.0.0 or higher

Check your installed versions:
```bash
node -v
npm -v
```

---

## Installation & Setup

1. **Extract or navigate to the project directory:**
   ```bash
   cd SkillBridge
   ```

2. **Install dependencies:**
   ```bash
   npm install --legacy-peer-deps
   ```

3. **Configure environment variables (Optional):**
   ```bash
   cp .env.example .env
   ```
   *(Defaults to port `8443` on `0.0.0.0`)*

4. **Start the local development server:**
   ```bash
   npm run dev
   ```

5. **Open in your browser:**
   Navigate to [http://localhost:8443](http://localhost:8443)

   *To access on mobile / other devices on the same Wi-Fi network:*
   Open `http://<your-local-ip>:8443` (e.g. `http://172.20.52.177:8443`)

   *If port 8443 is busy, run with a custom port:*
   * **PowerShell:** `$env:PORT=3000; npm run dev`
   * **Bash:** `PORT=3000 npm run dev`

---

## Production Build

To create an optimized production build:
```bash
npm run build
```

To locally preview the production build:
```bash
npm run preview
```

---

## Project Structure

```text
SkillBridge/
├── .env.example                 # Template environment variables
├── .figma/                      # Figma Make preview and kit configurations
├── index.html                   # HTML entry point shell with favicon
├── package.json                 # Project dependencies & npm scripts
├── tsconfig.json                # TypeScript compiler configuration
├── vite.config.ts               # Vite build & plugin setup
├── README.md                    # Installation and architectural documentation
├── RUN.md                       # Quick run instructions
└── src/
    ├── main.tsx                 # React DOM mount & early theme initializer
    ├── App.tsx                  # Root layout shell, 3-portal routing, header, and modals
    ├── index.css                # Global Tailwind CSS v4 & WCAG contrast styles
    ├── assets/
    │   └── logo.png             # Official SkillBridge brand logo image
    ├── components/
    │   ├── BrandLogo.tsx        # Official brand logo component with dark mode support
    │   ├── CompanyLogo.tsx      # Vector SVGs for official company marks
    │   ├── ProgressBar.tsx      # High-contrast 4-tier progress indicator
    │   ├── ProfileMenu.tsx      # Avatar dropdown panel (Settings, Theme, Lang, SignOut)
    │   ├── SignOutModal.tsx     # Confirmation dialog with session clearing
    │   └── SplashScreen.tsx     # Startup Instagram-style brand logo animation
    ├── lib/
    │   ├── assessmentData.ts    # 30-question bank across 9 engineering domains
    │   ├── catalog.ts           # Career targets, competencies, resources, companies
    │   ├── i18n.ts              # Centralized translations (English & Hindi)
    │   ├── insightsData.ts      # Labor market demand, placement correlations, sample sizes
    │   ├── progressColors.ts    # 4-tier color system (Red, Blue, Yellow, Green)
    │   ├── resourcesData.ts     # Curated educational resources across 11 domains
    │   ├── roadmap.ts           # Algorithm generating phase-by-phase learning paths
    │   ├── skillGap.ts          # Matrix comparing student capabilities vs role targets
    │   ├── store.tsx            # Global state context with LocalStorage sync
    │   └── theme.ts             # Theme manager (Dark / Light / System)
    └── screens/
        ├── Career.tsx           # Role explorer & target requirement breakdown
        ├── CollegePortal.tsx    # University analytics portal & CSV upload wizard
        ├── Companies.tsx        # Company directory with official brand logos
        ├── ComprehensiveAssessment.tsx # 15-minute timed test with tab-switch detection
        ├── Dashboard.tsx        # Student performance dashboard & bell curve
        ├── EmployabilityInsights.tsx # Employment analytics & market intelligence
        ├── Help.tsx             # Searchable FAQs & in-app feedback
        ├── IndustryPortal.tsx   # Recruiter / company candidate search view
        ├── Instructions.tsx     # Step-by-step user manual & guidelines
        ├── LearnMore.tsx        # Platform mission & 3-tier verification model
        ├── MySkills.tsx         # Skill inventory (Self-reported, Assessed, Verified)
        ├── Onboarding.tsx       # 8-step baseline diagnostic & profile wizard
        ├── Opportunities.tsx    # Internship & job matching board
        ├── Progress.tsx         # Timeline metrics, readiness history, achievements
        ├── Projects.tsx         # Portfolio project manager with GitHub/demo links
        ├── Resources.tsx        # 11-domain smart learning resources catalog
        ├── Roadmap.tsx          # Weekly milestones & task checklist
        ├── Settings.tsx         # Account, academic, notifications & privacy controls
        ├── Technologies.tsx     # Technical ecosystem & stack directory
        └── Trends.tsx           # Industry skilling trends & market research
```

---

## License

This project is private and proprietary. All company trademarks and logos (NVIDIA, Google, Microsoft, Amazon, Qualcomm, Adobe, Intel, OpenAI, Salesforce, Cisco) are property of their respective owners and used solely for educational demonstration purposes.
