import { useState } from "react";

interface InstructionsProps {
  onNavigate?: (screen: string) => void;
}

export default function Instructions({ onNavigate }: InstructionsProps) {
  const [activeTab, setActiveTab] = useState<
    "all" | "gettingStarted" | "assessment" | "gap" | "roadmap" | "projects" | "career"
  >("all");

  const tabs = [
    { id: "all", label: "All Guidelines" },
    { id: "gettingStarted", label: "1. Getting Started" },
    { id: "assessment", label: "2. Skill Assessment" },
    { id: "gap", label: "3. Skill Gap Analyzer" },
    { id: "roadmap", label: "4. Learning Roadmap" },
    { id: "projects", label: "5. Projects & Evidence" },
    { id: "career", label: "6. Career Explorer" },
  ] as const;

  return (
    <div className="p-5 max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="text-[11px] font-semibold bg-indigo-50 text-indigo-700 px-2.5 py-0.5 rounded-full uppercase tracking-wider">
              Documentation & Manual
            </span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            How to Use SkillBridge
          </h1>
          <p className="text-sm text-slate-500 mt-1 max-w-2xl">
            A comprehensive guide to understanding your skill benchmark, closing industry gaps, and building verifiable technical readiness.
          </p>
        </div>

        {onNavigate && (
          <button
            onClick={() => onNavigate("overview")}
            className="self-start sm:self-auto text-xs text-slate-500 hover:text-slate-800 border border-slate-200 px-3 py-1.5 rounded-lg font-medium transition-colors"
          >
            ← Return to Dashboard
          </button>
        )}
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`text-xs px-3.5 py-2 rounded-xl font-medium whitespace-nowrap transition-all ${
              activeTab === tab.id
                ? "bg-indigo-600 text-white shadow-xs font-semibold"
                : "bg-white border border-slate-200 text-slate-600 hover:border-slate-300 hover:bg-slate-50"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Content Sections */}
      <div className="space-y-6">
        {/* Section 1: Getting Started */}
        {(activeTab === "all" || activeTab === "gettingStarted") && (
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
              <span className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-700 font-bold flex items-center justify-center text-sm">
                01
              </span>
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  Getting Started with SkillBridge
                </h2>
                <p className="text-xs text-slate-500">
                  Setting up your profile, academic credentials, and target career
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-600">
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-1.5">
                <h4 className="font-semibold text-slate-800">1. Account & Storage</h4>
                <p>
                  SkillBridge stores your academic details, completed assessments, and roadmap progress in your browser&apos;s persistent local storage. Your progress is maintained across sessions.
                </p>
              </div>
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-1.5">
                <h4 className="font-semibold text-slate-800">2. Academic Profile</h4>
                <p>
                  Input your college, degree, graduation year, and study availability. Recruiters use these details when evaluating candidates in the Industry Portal.
                </p>
              </div>
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-1.5">
                <h4 className="font-semibold text-slate-800">3. Initial Skill Ratings</h4>
                <p>
                  Select technologies you have worked with and rate yourself honestly (Beginner, Intermediate, Advanced). These serve as baseline self-reported ratings.
                </p>
              </div>
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-1.5">
                <h4 className="font-semibold text-slate-800">4. Target Career Role</h4>
                <p>
                  Choose a career target (e.g. AI/ML Engineer, Cloud Engineer, Backend SWE). SkillBridge calibrates your entire roadmap against that specific role&apos;s expectations.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Section 2: Skill Assessment */}
        {(activeTab === "all" || activeTab === "assessment") && (
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
              <span className="w-8 h-8 rounded-xl bg-sky-50 text-sky-700 font-bold flex items-center justify-center text-sm">
                02
              </span>
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  Technical Skill Assessments
                </h2>
                <p className="text-xs text-slate-500">
                  Diagnostic quiz and the 15-Minute Comprehensive Technical Assessment
                </p>
              </div>
            </div>

            <div className="space-y-3 text-xs text-slate-600">
              <div className="p-4 rounded-xl bg-indigo-50/60 border border-indigo-100">
                <h4 className="font-bold text-indigo-950 mb-1">
                  15-Minute Comprehensive Technical Assessment
                </h4>
                <p className="text-indigo-900/90 leading-relaxed">
                  A 30-question, timed test covering 9 distinct engineering categories. The 15-minute countdown starts only after you click &quot;Start Assessment&quot; and will automatically submit when time expires.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100">
                  <h5 className="font-semibold text-slate-800 mb-1">Navigation Palette</h5>
                  <p>
                    Jump freely between questions 1 through 30. Indigo represents answered questions, while slate indicates unanswered ones.
                  </p>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100">
                  <h5 className="font-semibold text-slate-800 mb-1">Mark for Review</h5>
                  <p>
                    Flag challenging questions with the star icon to review them before final submission. Flags are highlighted on your question palette.
                  </p>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100">
                  <h5 className="font-semibold text-slate-800 mb-1">Assessed Skill Profile</h5>
                  <p>
                    Upon submission, your test results immediately update your assessed skill levels. Every attempt is logged in your assessment history.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Section 3: Skill Gap Analyzer */}
        {(activeTab === "all" || activeTab === "gap") && (
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
              <span className="w-8 h-8 rounded-xl bg-rose-50 text-rose-700 font-bold flex items-center justify-center text-sm">
                03
              </span>
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  Skill Gap Analyzer
                </h2>
                <p className="text-xs text-slate-500">
                  Comparing current capability vs. market role expectations
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-slate-600">
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
                <span className="inline-block px-2 py-0.5 rounded-full font-medium bg-rose-100 text-rose-700 text-[10px] mb-2">
                  High Severity Gaps
                </span>
                <p>
                  High-weight foundational skills with a proficiency gap of 25+ points. These are prioritized in Phase 1 of your roadmap.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
                <span className="inline-block px-2 py-0.5 rounded-full font-medium bg-amber-100 text-amber-700 text-[10px] mb-2">
                  Medium Severity Gaps
                </span>
                <p>
                  Skills where you have foundational knowledge but need deeper practical application (gap between 10 and 24 points).
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
                <span className="inline-block px-2 py-0.5 rounded-full font-medium bg-emerald-100 text-emerald-700 text-[10px] mb-2">
                  Met Proficiency
                </span>
                <p>
                  Skills where your current rating meets or exceeds target expectations. No further urgent remediation required.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Section 4: Learning Roadmap */}
        {(activeTab === "all" || activeTab === "roadmap") && (
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
              <span className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-700 font-bold flex items-center justify-center text-sm">
                04
              </span>
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  Personalized Learning Roadmap
                </h2>
                <p className="text-xs text-slate-500">
                  Weekly milestone execution and task tracking
                </p>
              </div>
            </div>

            <div className="text-xs text-slate-600 space-y-3">
              <p>
                Your roadmap automatically generates phases based on your target role and identified gaps:
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100">
                  <h5 className="font-semibold text-slate-800 mb-1">Phase 1: Foundations</h5>
                  <p className="text-slate-500">Core languages, algorithms, and high-severity requirements.</p>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100">
                  <h5 className="font-semibold text-slate-800 mb-1">Phase 2: Core Engineering</h5>
                  <p className="text-slate-500">Frameworks, database design, API architectures, and tooling.</p>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100">
                  <h5 className="font-semibold text-slate-800 mb-1">Phase 3: Real Projects</h5>
                  <p className="text-slate-500">Full-stack builds, deployment, testing, and portfolio evidence.</p>
                </div>
              </div>
              <p className="text-slate-500 pt-1">
                Check off completed tasks to increment your completion percentage. Your weekly activity graph on the Dashboard reflects tasks closed in the last 7 days.
              </p>
            </div>
          </div>
        )}

        {/* Section 5: Projects & Verification */}
        {(activeTab === "all" || activeTab === "projects") && (
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
              <span className="w-8 h-8 rounded-xl bg-violet-50 text-violet-700 font-bold flex items-center justify-center text-sm">
                05
              </span>
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  Projects & Skill Verification Tiers
                </h2>
                <p className="text-xs text-slate-500">
                  Understanding Self-Reported vs. Assessed vs. Verified skills
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                <span className="px-2 py-0.5 rounded-full font-medium bg-slate-200 text-slate-700 text-[10px]">
                  Self-Reported
                </span>
                <h4 className="font-semibold text-slate-800 mt-2 mb-1">Unverified Claim</h4>
                <p className="text-slate-500">
                  Skills rated by you during onboarding or manual editing. Indicated in gray across your profile.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-sky-50 border border-sky-100">
                <span className="px-2 py-0.5 rounded-full font-medium bg-sky-100 text-sky-700 text-[10px]">
                  Assessed
                </span>
                <h4 className="font-semibold text-sky-950 mt-2 mb-1">Objective Testing</h4>
                <p className="text-sky-800">
                  Skills verified via the 15-Minute Technical Assessment or Diagnostic Quiz. Indicated in sky blue.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-100">
                <span className="px-2 py-0.5 rounded-full font-medium bg-emerald-100 text-emerald-700 text-[10px]">
                  ✓ Verified
                </span>
                <h4 className="font-semibold text-emerald-950 mt-2 mb-1">Portfolio & Mentor Proof</h4>
                <p className="text-emerald-800">
                  Requires concrete project evidence (working GitHub repo, live URL) reviewed by an external mentor or recruiter.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Section 6: Career Explorer */}
        {(activeTab === "all" || activeTab === "career") && (
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
              <span className="w-8 h-8 rounded-xl bg-amber-50 text-amber-700 font-bold flex items-center justify-center text-sm">
                06
              </span>
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  Career Explorer & Industry Matching
                </h2>
                <p className="text-xs text-slate-500">
                  Comparing technical roles, top companies, and emerging industry trends
                </p>
              </div>
            </div>

            <div className="text-xs text-slate-600 space-y-2">
              <p>
                • <strong>Compare Roles:</strong> Use the Career tab to compare required skill weights, expected tools, and target projects across 8 engineering disciplines.
              </p>
              <p>
                • <strong>Explore Companies:</strong> See technology stacks utilized at leading technology companies (NVIDIA, Google, Microsoft, Qualcomm, OpenAI).
              </p>
              <p>
                • <strong>Industry Trends:</strong> Read verified findings from publications such as the World Economic Forum Future of Jobs Report.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
