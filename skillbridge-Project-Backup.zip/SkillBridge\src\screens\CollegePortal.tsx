import { useState, useMemo } from "react";
import { useStore, type CollegeStudentRecord } from "../lib/store";

export default function CollegePortal() {
  const { state, saveCollegeCohort, resetCollegeCohort } = useStore();

  const cohort = state.collegeCohort ?? [];

  // Filter & Search state for cohort table
  const [selectedDept, setSelectedDept] = useState<string>("All");
  const [selectedStatus, setSelectedStatus] = useState<string>("All");
  const [searchQuery, setSearchQuery] = useState<string>("");

  // Upload Wizard state
  const [wizardOpen, setWizardOpen] = useState(false);
  const [wizardStep, setWizardStep] = useState<1 | 2 | 3 | 4>(1);
  const [parsedHeaders, setParsedHeaders] = useState<string[]>([]);
  const [rawRows, setRawRows] = useState<Record<string, string>[]>([]);
  const [columnMap, setColumnMap] = useState<Record<string, string>>({
    id: "",
    name: "",
    department: "",
    batch: "",
    cgpa: "",
    topSkills: "",
    status: "",
    company: "",
    packageLPA: "",
    assessmentScore: "",
  });
  const [selectedUploadDept, setSelectedUploadDept] = useState("Computer Science");
  const [selectedUploadBatch, setSelectedUploadBatch] = useState("2025");
  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const [validationWarnings, setValidationWarnings] = useState<string[]>([]);
  const [validatedRecords, setValidatedRecords] = useState<CollegeStudentRecord[]>([]);

  // Unique departments in cohort
  const departments = useMemo(() => {
    const set = new Set<string>();
    cohort.forEach((s) => set.add(s.department));
    return Array.from(set);
  }, [cohort]);

  // Aggregate metrics
  const totalStudents = cohort.length;
  const placedStudents = cohort.filter((s) => s.status === "Placed").length;
  const inProcessStudents = cohort.filter((s) => s.status === "In Process").length;
  const unplacedStudents = cohort.filter((s) => s.status === "Unplaced").length;
  const placementRate = totalStudents ? Math.round((placedStudents / totalStudents) * 100) : 0;

  const placedWithPackages = cohort.filter((s) => s.status === "Placed" && s.packageLPA && s.packageLPA > 0);
  const avgPackage = placedWithPackages.length
    ? (placedWithPackages.reduce((acc, s) => acc + (s.packageLPA || 0), 0) / placedWithPackages.length).toFixed(1)
    : "0.0";
  const highestPackage = placedWithPackages.length
    ? Math.max(...placedWithPackages.map((s) => s.packageLPA || 0)).toFixed(1)
    : "0.0";

  const scores = cohort.filter((s) => typeof s.assessmentScore === "number");
  const avgAssessmentScore = scores.length
    ? Math.round(scores.reduce((acc, s) => acc + (s.assessmentScore || 0), 0) / scores.length)
    : 0;

  // Department metrics breakdown
  const deptBreakdown = useMemo(() => {
    return departments.map((dept) => {
      const deptStudents = cohort.filter((s) => s.department === dept);
      const placed = deptStudents.filter((s) => s.status === "Placed").length;
      const deptPlaced = deptStudents.filter((s) => s.status === "Placed" && s.packageLPA);
      const avgPkg = deptPlaced.length
        ? (deptPlaced.reduce((acc, s) => acc + (s.packageLPA || 0), 0) / deptPlaced.length).toFixed(1)
        : "—";
      const deptScores = deptStudents.filter((s) => typeof s.assessmentScore === "number");
      const avgScore = deptScores.length
        ? Math.round(deptScores.reduce((acc, s) => acc + (s.assessmentScore || 0), 0) / deptScores.length)
        : 0;

      return {
        dept,
        total: deptStudents.length,
        placed,
        rate: deptStudents.length ? Math.round((placed / deptStudents.length) * 100) : 0,
        avgPkg,
        avgScore,
      };
    });
  }, [cohort, departments]);

  // Filtered student roster
  const filteredStudents = useMemo(() => {
    return cohort.filter((s) => {
      if (selectedDept !== "All" && s.department !== selectedDept) return false;
      if (selectedStatus !== "All" && s.status !== selectedStatus) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesName = s.name.toLowerCase().includes(q);
        const matchesId = s.id.toLowerCase().includes(q);
        const matchesCompany = (s.company ?? "").toLowerCase().includes(q);
        const matchesSkills = s.topSkills.some((sk) => sk.toLowerCase().includes(q));
        if (!matchesName && !matchesId && !matchesCompany && !matchesSkills) return false;
      }
      return true;
    });
  }, [cohort, selectedDept, selectedStatus, searchQuery]);

  // CSV Template download
  const handleDownloadTemplate = () => {
    const sampleCsv = `Student ID,Full Name,Department,Batch,CGPA,Top Skills,Placement Status,Company,Package LPA,Assessment Score
STU-2025-101,Aarush Gupta,Computer Science,2025,8.8,"Python, Docker, SQL",Placed,Microsoft,24.0,90
STU-2025-102,Bhavna Patel,Information Technology,2025,7.9,"React, Node.js",In Process,,0,74
STU-2025-103,Chirag Sen,Electronics & Comm,2025,8.4,"C++, Embedded C, Git",Placed,Qualcomm,21.5,85
STU-2025-104,Deepika Rao,Data Science,2025,9.1,"PyTorch, ML, Statistics",Placed,NVIDIA,30.0,94
STU-2025-105,Eshwar Nair,Computer Science,2025,6.8,"HTML, CSS",Unplaced,,0,54`;

    const blob = new Blob([sampleCsv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", "skillbridge_cohort_template.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Handle File Upload & Parse
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (!text) return;

      const lines = text.split(/\r?\n/).filter((l) => l.trim().length > 0);
      if (lines.length < 2) {
        alert("The uploaded file must contain a header row and at least one student record.");
        return;
      }

      // Simple CSV parser supporting quotes
      const parseCsvLine = (line: string): string[] => {
        const result: string[] = [];
        let cur = "";
        let inQuotes = false;
        for (let i = 0; i < line.length; i++) {
          const char = line[i];
          if (char === '"') {
            inQuotes = !inQuotes;
          } else if (char === "," && !inQuotes) {
            result.push(cur.trim());
            cur = "";
          } else {
            cur += char;
          }
        }
        result.push(cur.trim());
        return result;
      };

      const headers = parseCsvLine(lines[0]);
      const rows: Record<string, string>[] = [];

      for (let i = 1; i < lines.length; i++) {
        const values = parseCsvLine(lines[i]);
        const row: Record<string, string> = {};
        headers.forEach((h, idx) => {
          row[h] = values[idx] ?? "";
        });
        rows.push(row);
      }

      setParsedHeaders(headers);
      setRawRows(rows);

      // Auto-guess column mapping
      const initialMap: Record<string, string> = {
        id: headers.find((h) => /id|roll|reg/i.test(h)) || headers[0] || "",
        name: headers.find((h) => /name|student/i.test(h)) || headers[1] || "",
        department: headers.find((h) => /dept|department|branch/i.test(h)) || "",
        batch: headers.find((h) => /batch|year|grad/i.test(h)) || "",
        cgpa: headers.find((h) => /cgpa|gpa|marks/i.test(h)) || "",
        topSkills: headers.find((h) => /skill/i.test(h)) || "",
        status: headers.find((h) => /status|placement/i.test(h)) || "",
        company: headers.find((h) => /company|employer/i.test(h)) || "",
        packageLPA: headers.find((h) => /package|ctc|lpa|salary/i.test(h)) || "",
        assessmentScore: headers.find((h) => /score|assessment|test/i.test(h)) || "",
      };

      setColumnMap(initialMap);
      setWizardStep(2);
    };

    reader.readAsText(file);
  };

  // Run validation on raw rows using columnMap
  const handleValidateMapping = () => {
    const errors: string[] = [];
    const warnings: string[] = [];
    const validRecords: CollegeStudentRecord[] = [];

    if (!columnMap.id) {
      errors.push("Missing mapping for required field: Student ID.");
    }
    if (!columnMap.name) {
      errors.push("Missing mapping for required field: Student Name.");
    }

    if (errors.length > 0) {
      setValidationErrors(errors);
      return;
    }

    rawRows.forEach((row, idx) => {
      const rowNum = idx + 2;
      const idVal = row[columnMap.id]?.trim();
      const nameVal = row[columnMap.name]?.trim();

      if (!idVal) {
        errors.push(`Row ${rowNum}: Student ID is empty.`);
        return;
      }
      if (!nameVal) {
        errors.push(`Row ${rowNum}: Student Name is empty.`);
        return;
      }

      const deptVal = (columnMap.department ? row[columnMap.department]?.trim() : "") || selectedUploadDept;
      const batchVal = (columnMap.batch ? row[columnMap.batch]?.trim() : "") || selectedUploadBatch;

      let cgpaNum = 7.5;
      if (columnMap.cgpa && row[columnMap.cgpa]) {
        const parsedCgpa = parseFloat(row[columnMap.cgpa]);
        if (isNaN(parsedCgpa) || parsedCgpa < 0 || parsedCgpa > 10) {
          warnings.push(`Row ${rowNum}: CGPA "${row[columnMap.cgpa]}" invalid, defaulted to 7.5.`);
        } else {
          cgpaNum = parsedCgpa;
        }
      }

      const skillsRaw = columnMap.topSkills ? row[columnMap.topSkills] : "";
      const skillsArray = skillsRaw
        ? skillsRaw.split(/[,;|]/).map((s) => s.trim()).filter(Boolean)
        : ["Engineering Foundations"];

      let statusVal: "Placed" | "Unplaced" | "In Process" = "In Process";
      if (columnMap.status && row[columnMap.status]) {
        const sRaw = row[columnMap.status].toLowerCase();
        if (sRaw.includes("place") && !sRaw.includes("un")) statusVal = "Placed";
        else if (sRaw.includes("unplace") || sRaw.includes("not")) statusVal = "Unplaced";
        else statusVal = "In Process";
      }

      const compVal = columnMap.company ? row[columnMap.company]?.trim() : undefined;

      let pkgNum: number | undefined = undefined;
      if (columnMap.packageLPA && row[columnMap.packageLPA]) {
        const p = parseFloat(row[columnMap.packageLPA]);
        if (!isNaN(p) && p > 0) pkgNum = p;
      }

      let scoreNum: number | undefined = undefined;
      if (columnMap.assessmentScore && row[columnMap.assessmentScore]) {
        const sc = parseFloat(row[columnMap.assessmentScore]);
        if (!isNaN(sc) && sc >= 0 && sc <= 100) scoreNum = sc;
      }

      validRecords.push({
        id: idVal,
        name: nameVal,
        department: deptVal,
        batch: batchVal,
        cgpa: cgpaNum,
        topSkills: skillsArray,
        status: statusVal,
        company: compVal || undefined,
        packageLPA: pkgNum,
        assessmentScore: scoreNum,
        isDemo: false,
      });
    });

    setValidationErrors(errors);
    setValidationWarnings(warnings);
    setValidatedRecords(validRecords);
    setWizardStep(3);
  };

  // Final Commit of imported records
  const handleCommitUpload = (replace: boolean) => {
    if (replace) {
      saveCollegeCohort(validatedRecords);
    } else {
      // Merge unique by ID
      const existingMap = new Map(cohort.map((s) => [s.id, s]));
      validatedRecords.forEach((s) => existingMap.set(s.id, s));
      saveCollegeCohort(Array.from(existingMap.values()));
    }

    setWizardOpen(false);
    setWizardStep(1);
    setRawRows([]);
    setValidatedRecords([]);
    alert(`Successfully imported ${validatedRecords.length} student records into the College Analytics Portal!`);
  };

  return (
    <div className="p-4 sm:p-6 max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2 mb-1 flex-wrap">
            <span className="text-xs font-semibold bg-indigo-50 text-indigo-700 px-2.5 py-0.5 rounded-full border border-indigo-200 font-mono">
              University Administrator Portal
            </span>
            <span className="text-[11px] font-semibold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200">
              DEMO DATA INITIALIZED
            </span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            College Placement & Skill Analytics Portal
          </h1>
          <p className="text-xs text-slate-500 mt-1 max-w-3xl">
            Institutional overview of university skill distribution, department-wise placement clearance, assessment correlations, and batch progress.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setWizardOpen(true)}
            className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5"
          >
            <span>📥</span>
            <span>Upload Student Cohort Data (CSV/Excel)</span>
          </button>
          <button
            onClick={resetCollegeCohort}
            title="Restore sample demo records"
            className="p-2 rounded-xl border border-slate-200 text-slate-500 hover:bg-slate-50 text-xs font-medium"
          >
            ↻ Reset
          </button>
        </div>
      </div>

      {/* 5 Core Top Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
          <p className="text-xs text-slate-400 font-medium">Total Cohort</p>
          <p className="text-2xl font-bold text-slate-900 font-mono mt-0.5">{totalStudents}</p>
          <p className="text-[11px] text-slate-500 mt-1">Students tracked</p>
        </div>
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
          <p className="text-xs text-slate-400 font-medium">Placement Rate</p>
          <p className="text-2xl font-bold text-emerald-600 font-mono mt-0.5">{placementRate}%</p>
          <p className="text-[11px] text-emerald-600 font-medium mt-1">{placedStudents} placed</p>
        </div>
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
          <p className="text-xs text-slate-400 font-medium">Average Package</p>
          <p className="text-2xl font-bold text-indigo-600 font-mono mt-0.5">{avgPackage} LPA</p>
          <p className="text-[11px] text-slate-500 mt-1">Mean starting CTC</p>
        </div>
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
          <p className="text-xs text-slate-400 font-medium">Highest Package</p>
          <p className="text-2xl font-bold text-blue-600 font-mono mt-0.5">{highestPackage} LPA</p>
          <p className="text-[11px] text-slate-500 mt-1">Top offer recorded</p>
        </div>
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
          <p className="text-xs text-slate-400 font-medium">Avg Assessment</p>
          <p className="text-2xl font-bold text-purple-600 font-mono mt-0.5">{avgAssessmentScore}%</p>
          <p className="text-[11px] text-slate-500 mt-1">Skill benchmark</p>
        </div>
      </div>

      {/* Department Breakdown Table */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Department Performance & Placement Outcomes
            </h2>
            <p className="text-xs text-slate-500">
              Departmental comparisons of placement rates, mean CTC, and standardized technical benchmark scores.
            </p>
          </div>
          <span className="text-xs font-mono text-slate-400">
            {departments.length} Academic Departments
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-100 text-slate-400 font-medium">
                <th className="py-2.5 px-3">Department</th>
                <th className="py-2.5 px-3">Students</th>
                <th className="py-2.5 px-3">Placed Count</th>
                <th className="py-2.5 px-3">Placement Rate</th>
                <th className="py-2.5 px-3">Average CTC</th>
                <th className="py-2.5 px-3">Avg Assessment</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {deptBreakdown.map((row) => (
                <tr key={row.dept} className="hover:bg-slate-50 transition-colors">
                  <td className="py-3 px-3 font-bold text-slate-800">{row.dept}</td>
                  <td className="py-3 px-3 font-mono text-slate-600">{row.total}</td>
                  <td className="py-3 px-3 font-mono text-emerald-600 font-semibold">{row.placed}</td>
                  <td className="py-3 px-3">
                    <div className="flex items-center gap-2">
                      <div className="w-20 h-2 rounded-full bg-slate-100 overflow-hidden">
                        <div
                          className="h-full bg-emerald-500 rounded-full"
                          style={{ width: `${row.rate}%` }}
                        />
                      </div>
                      <span className="font-mono font-bold text-slate-700">{row.rate}%</span>
                    </div>
                  </td>
                  <td className="py-3 px-3 font-mono text-indigo-600 font-bold">{row.avgPkg} LPA</td>
                  <td className="py-3 px-3 font-mono text-purple-600 font-semibold">{row.avgScore}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Cohort Student Roster with Filters */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-slate-900">Student Cohort Roster</h2>
            <p className="text-xs text-slate-500">Individual candidate skill records, offers, and assessment results</p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Search Input */}
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search candidate, ID, skill..."
              className="text-xs border border-slate-200 rounded-xl px-3 py-1.5 bg-white text-slate-800 placeholder-slate-400 outline-none focus:ring-2 focus:ring-indigo-300"
            />

            {/* Department Filter */}
            <select
              value={selectedDept}
              onChange={(e) => setSelectedDept(e.target.value)}
              className="text-xs border border-slate-200 rounded-xl px-2.5 py-1.5 bg-white text-slate-700 outline-none"
            >
              <option value="All">All Departments</option>
              {departments.map((d) => (
                <option key={d} value={d}>{d}</option>
              ))}
            </select>

            {/* Placement Filter */}
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="text-xs border border-slate-200 rounded-xl px-2.5 py-1.5 bg-white text-slate-700 outline-none"
            >
              <option value="All">All Statuses</option>
              <option value="Placed">Placed</option>
              <option value="In Process">In Process</option>
              <option value="Unplaced">Unplaced</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-100 text-slate-400 font-medium">
                <th className="py-2.5 px-3">Student ID</th>
                <th className="py-2.5 px-3">Candidate</th>
                <th className="py-2.5 px-3">Dept & Batch</th>
                <th className="py-2.5 px-3">CGPA</th>
                <th className="py-2.5 px-3">Top Competencies</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3">Company & CTC</th>
                <th className="py-2.5 px-3">Assessment</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredStudents.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-400 text-xs">
                    No student records match the selected filters.
                  </td>
                </tr>
              ) : (
                filteredStudents.map((s) => (
                  <tr key={s.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-2.5 px-3 font-mono text-slate-500 text-[11px]">{s.id}</td>
                    <td className="py-2.5 px-3 font-semibold text-slate-800">{s.name}</td>
                    <td className="py-2.5 px-3 text-slate-600">
                      {s.department} ({s.batch})
                    </td>
                    <td className="py-2.5 px-3 font-mono text-slate-700">{s.cgpa.toFixed(1)}</td>
                    <td className="py-2.5 px-3">
                      <div className="flex flex-wrap gap-1">
                        {s.topSkills.map((sk) => (
                          <span
                            key={sk}
                            className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-700"
                          >
                            {sk}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td className="py-2.5 px-3">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          s.status === "Placed"
                            ? "bg-emerald-50 text-emerald-700 border border-emerald-200"
                            : s.status === "In Process"
                            ? "bg-blue-50 text-blue-700 border border-blue-200"
                            : "bg-slate-100 text-slate-600"
                        }`}
                      >
                        {s.status}
                      </span>
                    </td>
                    <td className="py-2.5 px-3">
                      {s.company ? (
                        <div>
                          <span className="font-semibold text-slate-800">{s.company}</span>
                          {s.packageLPA && (
                            <span className="text-[11px] font-mono font-bold text-indigo-600 block">
                              {s.packageLPA} LPA
                            </span>
                          )}
                        </div>
                      ) : (
                        <span className="text-slate-400">—</span>
                      )}
                    </td>
                    <td className="py-2.5 px-3 font-mono font-bold text-purple-600">
                      {s.assessmentScore ? `${s.assessmentScore}%` : "—"}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* CSV / Excel Data Upload & Column-Mapping Wizard Modal */}
      {wizardOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-7 max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl space-y-5">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Cohort Data Upload & Column Mapping Wizard
                </h3>
                <p className="text-xs text-slate-500">
                  Step {wizardStep} of 3: {wizardStep === 1 ? "Select File" : wizardStep === 2 ? "Configure Column Mapping" : "Validation & Import"}
                </p>
              </div>
              <button
                onClick={() => setWizardOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-sm p-1.5 rounded-lg"
              >
                ✕
              </button>
            </div>

            {/* STEP 1: Upload File */}
            {wizardStep === 1 && (
              <div className="space-y-4">
                <div className="p-6 rounded-2xl border-2 border-dashed border-slate-200 text-center space-y-3 bg-slate-50/50 hover:bg-slate-50 transition-colors">
                  <span className="text-3xl block">📄</span>
                  <div>
                    <p className="text-sm font-bold text-slate-800">
                      Choose CSV / Excel Export File (.csv, .tsv)
                    </p>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Upload student records from your institutional placement or LMS export
                    </p>
                  </div>

                  <input
                    type="file"
                    accept=".csv,.tsv,.txt"
                    onChange={handleFileUpload}
                    className="text-xs text-slate-500 file:mr-3 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-indigo-600 file:text-white hover:file:bg-indigo-700 cursor-pointer"
                  />
                </div>

                <div className="flex items-center justify-between pt-2">
                  <button
                    type="button"
                    onClick={handleDownloadTemplate}
                    className="text-xs text-indigo-600 hover:underline font-semibold flex items-center gap-1"
                  >
                    <span>📥</span>
                    <span>Download Sample CSV Template</span>
                  </button>
                  <p className="text-[11px] text-slate-400">Standard UTF-8 format supported</p>
                </div>
              </div>
            )}

            {/* STEP 2: Column Mapping & Batch Config */}
            {wizardStep === 2 && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3 p-3 rounded-2xl bg-slate-50 border border-slate-200 text-xs">
                  <div>
                    <label className="text-slate-500 font-medium block mb-1">Fallback Department:</label>
                    <input
                      type="text"
                      value={selectedUploadDept}
                      onChange={(e) => setSelectedUploadDept(e.target.value)}
                      className="w-full border border-slate-200 rounded-lg px-2.5 py-1.5 bg-white text-slate-800"
                    />
                  </div>
                  <div>
                    <label className="text-slate-500 font-medium block mb-1">Batch / Graduation Year:</label>
                    <input
                      type="text"
                      value={selectedUploadBatch}
                      onChange={(e) => setSelectedUploadBatch(e.target.value)}
                      className="w-full border border-slate-200 rounded-lg px-2.5 py-1.5 bg-white text-slate-800"
                    />
                  </div>
                </div>

                <div className="space-y-2 text-xs">
                  <p className="font-bold text-slate-800 uppercase tracking-wider text-[11px]">
                    Map CSV Columns to SkillBridge Data Fields:
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {[
                      { key: "id", label: "Student ID *", required: true },
                      { key: "name", label: "Full Name *", required: true },
                      { key: "department", label: "Department", required: false },
                      { key: "batch", label: "Batch / Year", required: false },
                      { key: "cgpa", label: "CGPA", required: false },
                      { key: "topSkills", label: "Top Skills", required: false },
                      { key: "status", label: "Placement Status", required: false },
                      { key: "company", label: "Company", required: false },
                      { key: "packageLPA", label: "Package (LPA)", required: false },
                      { key: "assessmentScore", label: "Assessment Score (%)", required: false },
                    ].map(({ key, label, required }) => (
                      <div key={key} className="flex items-center justify-between gap-2 p-2 rounded-xl bg-slate-50 border border-slate-100">
                        <span className={`text-[11px] font-medium ${required ? "text-slate-900 font-bold" : "text-slate-600"}`}>
                          {label}
                        </span>
                        <select
                          value={columnMap[key] || ""}
                          onChange={(e) => setColumnMap((prev) => ({ ...prev, [key]: e.target.value }))}
                          className="text-xs border border-slate-200 rounded-lg px-2 py-1 bg-white text-slate-700 max-w-[140px]"
                        >
                          <option value="">-- Ignore --</option>
                          {parsedHeaders.map((h) => (
                            <option key={h} value={h}>{h}</option>
                          ))}
                        </select>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex justify-between items-center pt-3 border-t border-slate-100">
                  <button
                    onClick={() => setWizardStep(1)}
                    className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50"
                  >
                    ← Back
                  </button>
                  <button
                    onClick={handleValidateMapping}
                    className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs"
                  >
                    Validate & Preview ({rawRows.length} Rows) →
                  </button>
                </div>
              </div>
            )}

            {/* STEP 3: Validation Summary & Import Preview */}
            {wizardStep === 3 && (
              <div className="space-y-4">
                {validationErrors.length > 0 ? (
                  <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-900 text-xs space-y-1">
                    <p className="font-bold text-sm">Validation Errors Detected ({validationErrors.length})</p>
                    <ul className="list-disc pl-4 space-y-0.5">
                      {validationErrors.slice(0, 5).map((err, i) => (
                        <li key={i}>{err}</li>
                      ))}
                    </ul>
                  </div>
                ) : (
                  <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex items-center justify-between">
                    <div>
                      <p className="font-bold">Validation Successful</p>
                      <p className="text-[11px] text-emerald-700">
                        {validatedRecords.length} records ready to import ({validationWarnings.length} minor warnings)
                      </p>
                    </div>
                    <span className="text-xl">✓</span>
                  </div>
                )}

                {/* Preview Table */}
                <div className="space-y-2">
                  <p className="font-bold text-slate-800 text-xs uppercase tracking-wider">
                    Data Preview (First 5 Rows):
                  </p>
                  <div className="overflow-x-auto border border-slate-200 rounded-xl">
                    <table className="w-full text-left text-[11px]">
                      <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
                        <tr>
                          <th className="p-2">ID</th>
                          <th className="p-2">Name</th>
                          <th className="p-2">Dept</th>
                          <th className="p-2">CGPA</th>
                          <th className="p-2">Status</th>
                          <th className="p-2">Package</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {validatedRecords.slice(0, 5).map((r) => (
                          <tr key={r.id}>
                            <td className="p-2 font-mono text-slate-500">{r.id}</td>
                            <td className="p-2 font-semibold text-slate-800">{r.name}</td>
                            <td className="p-2 text-slate-600">{r.department}</td>
                            <td className="p-2 font-mono">{r.cgpa}</td>
                            <td className="p-2">
                              <span className="font-semibold text-emerald-700">{r.status}</span>
                            </td>
                            <td className="p-2 font-mono text-indigo-600">
                              {r.packageLPA ? `${r.packageLPA} LPA` : "—"}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Commit Actions */}
                <div className="flex flex-wrap items-center justify-between gap-2 pt-3 border-t border-slate-100">
                  <button
                    onClick={() => setWizardStep(2)}
                    className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50"
                  >
                    ← Edit Mapping
                  </button>

                  <div className="flex gap-2">
                    <button
                      onClick={() => handleCommitUpload(false)}
                      disabled={validationErrors.length > 0}
                      className="px-4 py-2 rounded-xl border border-indigo-200 text-xs font-bold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 disabled:opacity-50"
                    >
                      Merge with Existing
                    </button>
                    <button
                      onClick={() => handleCommitUpload(true)}
                      disabled={validationErrors.length > 0}
                      className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs disabled:opacity-50"
                    >
                      Replace All Records
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
