import { useEffect, useState, type ReactNode } from "react";
import logoPng from "../assets/logo.png";

interface SplashScreenProps {
  children: ReactNode;
}

export default function SplashScreen({ children }: SplashScreenProps) {
  const [showSplash, setShowSplash] = useState(() => {
    // Respect reduced-motion accessibility preference
    if (
      typeof window !== "undefined" &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches
    ) {
      return false;
    }
    // Check if already displayed in this browser session
    try {
      const seen = sessionStorage.getItem("skillbridge_splash_shown");
      if (seen) return false;
    } catch {
      /* ignore */
    }
    return true;
  });

  const [fadingOut, setFadingOut] = useState(false);

  useEffect(() => {
    if (!showSplash) return;

    try {
      sessionStorage.setItem("skillbridge_splash_shown", "1");
    } catch {
      /* ignore */
    }

    // Begin fade-out at 1350ms, completely remove at 1750ms
    const fadeTimer = setTimeout(() => {
      setFadingOut(true);
    }, 1350);

    const removeTimer = setTimeout(() => {
      setShowSplash(false);
    }, 1750);

    return () => {
      clearTimeout(fadeTimer);
      clearTimeout(removeTimer);
    };
  }, [showSplash]);

  if (!showSplash) {
    return <>{children}</>;
  }

  return (
    <>
      <div
        className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-slate-950 transition-opacity duration-400 ease-out select-none ${
          fadingOut ? "opacity-0 pointer-events-none" : "opacity-100"
        }`}
        style={{ willChange: "opacity" }}
        role="presentation"
        aria-hidden="true"
      >
        {/* Ambient atmospheric glow background */}
        <div className="absolute w-80 h-80 rounded-full bg-indigo-600/25 blur-3xl pointer-events-none animate-pulse" />
        <div className="absolute w-48 h-48 rounded-full bg-blue-500/15 blur-2xl pointer-events-none translate-y-12" />

        {/* Central Logo Container with smooth scale & glow effect */}
        <div className="relative flex flex-col items-center text-center px-4 animate-in fade-in zoom-in-95 duration-700 ease-out">
          <div className="relative mb-6 group">
            {/* Radiant ambient aura */}
            <div className="absolute -inset-3 bg-gradient-to-tr from-indigo-500/40 via-blue-500/30 to-violet-500/40 rounded-3xl blur-xl opacity-75 animate-pulse" />

            {/* Official Brand Logo Card */}
            <div className="relative p-5 rounded-2xl bg-white/95 backdrop-blur-md shadow-2xl border border-white/20 transform transition-transform duration-700 ease-out hover:scale-105 flex items-center justify-center">
              <img
                src={logoPng}
                alt="SkillBridge Official Logo"
                className="w-48 sm:w-56 h-auto object-contain drop-shadow-sm"
              />
            </div>
          </div>

          <p className="text-xs sm:text-sm text-indigo-300/90 font-medium tracking-widest uppercase mt-1">
            Career & Skill Intelligence Platform
          </p>

          {/* Minimalist animated progress loader bar */}
          <div className="w-32 h-1 bg-slate-800/80 rounded-full mt-7 overflow-hidden border border-slate-700/50">
            <div className="h-full bg-gradient-to-r from-indigo-500 via-sky-400 to-indigo-400 rounded-full animate-[progress_1.3s_ease-in-out_infinite]" />
          </div>
        </div>

        {/* Skip button for user convenience */}
        <button
          onClick={() => setShowSplash(false)}
          className="absolute bottom-6 text-[11px] text-slate-500 hover:text-slate-300 transition-colors cursor-pointer py-1 px-2.5 rounded-full hover:bg-slate-900/60"
        >
          Skip animation →
        </button>
      </div>
      <div className={showSplash ? "opacity-0" : "opacity-100 transition-opacity duration-300"}>
        {children}
      </div>
    </>
  );
}
