import { useState } from "react";
import { TECHNOLOGIES, TECH_CATEGORIES, careerById } from "../lib/catalog";
import { useStore } from "../lib/store";

export default function Technologies() {
  const { state } = useStore();
  const [cat, setCat] = useState("All");
  const list = TECHNOLOGIES.filter((t) => cat === "All" || t.category === cat);

  return (
    <div className="p-5 max-w-6xl mx-auto">
      <div className="mb-6">
        <h1 className="text-xl font-semibold text-slate-800">Technology Explorer</h1>
        <p className="text-sm text-slate-500 mt-0.5">Browse technologies by category and see which SkillBridge career profiles use them.</p>
      </div>

      <div className="flex gap-2 flex-wrap mb-5">
        {["All", ...TECH_CATEGORIES].map((f) => (
          <button key={f} onClick={() => setCat(f)}
            className={`text-xs px-3 py-1.5 rounded-lg font-medium transition-all ${cat === f ? "bg-indigo-600 text-white" : "bg-white border border-slate-200 text-slate-600 hover:border-indigo-300"}`}>{f}</button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {list.map((t) => (
          <div key={t.name} className="bg-white rounded-2xl border border-slate-200 p-4">
            <div className="flex items-start justify-between gap-2 mb-1.5">
              <p className="text-sm font-semibold text-slate-800">{t.name}</p>
              <span className="text-[10px] bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-full shrink-0">{t.category}</span>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed mb-3">{t.description}</p>
            <p className="text-[11px] font-medium text-slate-600 mb-1.5">Related career roles</p>
            <div className="flex flex-wrap gap-1.5">
              {t.careers.map((id) => <span key={id} className={`text-[10px] px-2 py-0.5 rounded-full ${id === state.careerId ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-600"}`}>{careerById(id)?.title}</span>)}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
