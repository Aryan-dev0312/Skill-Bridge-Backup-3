import { useMemo, useState } from "react";
import { ALL_SKILLS } from "../lib/catalog";
import { useStore, levelLabel, type PostedOpp } from "../lib/store";

type Tab = "dashboard" | "post" | "candidates";
type Status = "self" | "assessed" | "verified";
interface Candidate {
  id: string; name: string; college: string; demo: boolean;
  skills: Record<string, { level: number; status: Status }>;
  projects: { title: string; github: string; evidence: string }[];
  assessment: { score: number; total: number } | null;
}

// Fictional sample candidates, clearly labelled DEMO DATA. None carry a "verified" status.
const DEMO: Candidate[] = [
  { id: "d1", name: "Demo Candidate A", college: "Demo University · CS, 3rd year", demo: true, skills: { Python: { level: 70, status: "assessed" }, "Machine Learning": { level: 55, status: "self" }, SQL: { level: 55, status: "self" }, Git: { level: 70, status: "assessed" } }, projects: [{ title: "Sample: sentiment classifier", github: "", evidence: "Sample evidence text" }], assessment: { score: 4, total: 5 } },
  { id: "d2", name: "Demo Candidate B", college: "Demo Institute · ECE, 4th year", demo: true, skills: { "Verilog/SystemVerilog": { level: 55, status: "self" }, "Digital Logic": { level: 70, status: "assessed" }, "Embedded C": { level: 55, status: "self" } }, projects: [{ title: "Sample: UART in Verilog", github: "", evidence: "Sample evidence text" }], assessment: { score: 3, total: 5 } },
  { id: "d3", name: "Demo Candidate C", college: "Demo University · IT, 3rd year", demo: true, skills: { Docker: { level: 55, status: "self" }, "CI/CD": { level: 30, status: "self" }, "Linux/Shell": { level: 55, status: "self" }, Python: { level: 55, status: "self" } }, projects: [], assessment: null },
  { id: "d4", name: "Demo Candidate D", college: "Demo College · CS, 4th year", demo: true, skills: { React: { level: 70, status: "self" }, "REST APIs": { level: 55, status: "self" }, SQL: { level: 70, status: "assessed" }, Git: { level: 55, status: "assessed" } }, projects: [{ title: "Sample: event app", github: "", evidence: "Sample evidence text" }, { title: "Sample: chat app", github: "", evidence: "" }], assessment: { score: 3, total: 5 } },
];

const statusColors: Record<string, string> = { new: "bg-sky-100 text-sky-700", shortlisted: "bg-emerald-100 text-emerald-700" };
const chip: Record<Status, string> = { self: "bg-slate-100 text-slate-600", assessed: "bg-sky-100 text-sky-700", verified: "bg-emerald-100 text-emerald-700" };
const chipLabel: Record<Status, string> = { self: "self-reported", assessed: "assessed", verified: "verified" };
const inputCls = "w-full text-sm border border-slate-200 rounded-xl px-3 py-2.5 outline-none focus:ring-2 focus:ring-indigo-300 bg-white";

export default function IndustryPortal() {
  const { state, patch, skills, assessment } = useStore();
  const [tab, setTab] = useState<Tab>("dashboard");
  const [form, setForm] = useState({ title: "", type: "Internship", location: "", description: "", skills: [] as string[], extra: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saved, setSaved] = useState(false);
  const [filterSkills, setFilterSkills] = useState<string[]>([]);
  const [minLevel, setMinLevel] = useState(55);
  const [statusFilter, setStatusFilter] = useState("all");
  const [open, setOpen] = useState<string | null>(null);

  const me: Candidate = {
    id: "me", name: `${state.account?.name ?? "Student"} (this browser)`, college: `${state.academic.college} · ${state.academic.degree}`, demo: state.demo,
    skills: Object.fromEntries(Object.entries(skills).map(([k, v]) => [k, { level: v.level, status: v.status }])),
    projects: state.projects.map((p) => ({ title: p.title, github: p.github, evidence: p.evidence })),
    assessment: assessment ? { score: assessment.score, total: assessment.total } : null,
  };
  const pool = [me, ...DEMO];
  const status = (id: string) => state.candidateStatus[id] ?? "new";

  const matchOf = (c: Candidate) =>
    filterSkills.length ? Math.round((filterSkills.reduce((s, k) => s + Math.min((c.skills[k]?.level ?? 0) / minLevel, 1), 0) / filterSkills.length) * 100) : null;

  const results = useMemo(() => {
    return pool
      .filter((c) => statusFilter === "all" || status(c.id) === statusFilter)
      .map((c) => ({ c, match: matchOf(c) }))
      .sort((a, b) => (b.match ?? Object.keys(b.c.skills).length) - (a.match ?? Object.keys(a.c.skills).length));
  }, [pool.length, filterSkills, minLevel, statusFilter, state.candidateStatus, skills, state.projects, assessment]); // eslint-disable-line react-hooks/exhaustive-deps

  function post(e: React.FormEvent) {
    e.preventDefault();
    const er: Record<string, string> = {};
    if (form.title.trim().length < 3) er.title = "Enter a role title.";
    if (!form.location.trim()) er.location = "Enter a location or Remote.";
    if (form.description.trim().length < 20) er.description = "Describe the role (20+ characters).";
    if (form.skills.length === 0) er.skills = "Choose at least one required skill.";
    setErrors(er);
    if (Object.keys(er).length) return;
    const opp: PostedOpp = { id: `o${Date.now()}`, title: form.title.trim(), type: form.type, location: form.location.trim(), description: form.description.trim(), skills: form.skills, createdAt: new Date().toISOString() };
    patch((s) => ({ postedOpps: [opp, ...s.postedOpps] }));
    setForm({ title: "", type: "Internship", location: "", description: "", skills: [], extra: "" });
    setSaved(true); setTimeout(() => setSaved(false), 4000);
  }

  const shortlisted = pool.filter((c) => status(c.id) === "shortlisted").length;

  return (
    <div className="p-5 max-w-6xl mx-auto">
      <div className="mb-5 flex items-center justify-between flex-wrap gap-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h1 className="text-xl font-semibold text-slate-800">Industry Portal</h1>
            <span className="text-xs bg-violet-100 text-violet-700 px-2 py-0.5 rounded-full font-medium">Company View</span>
            <span className="text-xs bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full font-medium">DEMO DATA</span>
          </div>
          <p className="text-sm text-slate-500">Prototype recruiter view. Sample candidates are fictional; nothing is posted publicly or shared with real companies.</p>
        </div>
      </div>

      <div className="flex gap-1 bg-slate-100 rounded-xl p-1 mb-5 w-fit">
        {(["dashboard", "post", "candidates"] as Tab[]).map((t) => (
          <button key={t} onClick={() => setTab(t)}
            className={`text-sm px-4 py-2 rounded-lg font-medium transition-all ${tab === t ? "bg-white text-slate-800 shadow-sm" : "text-slate-500 hover:text-slate-700"}`}>
            {t === "post" ? "Post Opportunity" : t === "candidates" ? "Candidate Discovery" : "Dashboard"}
          </button>
        ))}
      </div>

      {tab === "dashboard" && (
        <div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
            {[
              { label: "Opportunities Posted", value: String(state.postedOpps.length), color: "text-indigo-600" },
              { label: "Candidates in Pool", value: String(pool.length), color: "text-slate-800" },
              { label: "Shortlisted", value: String(shortlisted), color: "text-emerald-600" },
              { label: "With Assessment", value: String(pool.filter((c) => c.assessment).length), color: "text-sky-600" },
            ].map((m) => (
              <div key={m.label} className="bg-white rounded-2xl border border-slate-200 p-4">
                <p className="text-xs text-slate-500 mb-1">{m.label}</p>
                <p className={`text-2xl font-bold font-mono ${m.color}`}>{m.value}</p>
              </div>
            ))}
          </div>
          <div className="bg-white rounded-2xl border border-slate-200 p-5">
            <p className="text-sm font-semibold text-slate-700 mb-4">Your Posted Opportunities</p>
            {state.postedOpps.length === 0 ? (
              <p className="text-sm text-slate-500">Nothing posted yet. Use “Post Opportunity” to add one.</p>
            ) : (
              <div className="space-y-3">
                {state.postedOpps.map((o) => (
                  <div key={o.id} className="flex items-center gap-4 p-4 border border-slate-100 rounded-xl flex-wrap">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-slate-800">{o.title} <span className="text-[9px] bg-amber-100 text-amber-700 px-1.5 py-0.5 rounded-full ml-1">DEMO DATA</span></p>
                      <p className="text-xs text-slate-500 mt-0.5">{o.type} · {o.location} · {o.skills.join(", ")}</p>
                    </div>
                    <button onClick={() => { setFilterSkills(o.skills); setTab("candidates"); }} className="text-xs text-indigo-600 hover:underline font-medium">Find candidates →</button>
                    <button onClick={() => patch((s) => ({ postedOpps: s.postedOpps.filter((x) => x.id !== o.id) }))} className="text-xs text-slate-400 hover:text-rose-600">Remove</button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {tab === "post" && (
        <div className="max-w-2xl">
          {saved && <div className="mb-4 p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-sm text-emerald-700 font-medium">✅ Saved to this browser as demo data. It is not published anywhere.</div>}
          <div className="bg-white rounded-2xl border border-slate-200 p-6">
            <p className="text-sm font-semibold text-slate-700 mb-5">Post a New Opportunity</p>
            <form onSubmit={post} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div><label className="text-xs font-medium text-slate-600 block mb-1">Role Title *</label><input className={inputCls} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="e.g. Backend Intern" />{errors.title && <p className="text-[11px] text-rose-600 mt-1">{errors.title}</p>}</div>
                <div><label className="text-xs font-medium text-slate-600 block mb-1">Type *</label>
                  <select className={inputCls} value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>{["Internship", "Full-time", "Research", "Contract"].map((o) => <option key={o}>{o}</option>)}</select></div>
              </div>
              <div><label className="text-xs font-medium text-slate-600 block mb-1">Location *</label><input className={inputCls} value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} placeholder="City or Remote" />{errors.location && <p className="text-[11px] text-rose-600 mt-1">{errors.location}</p>}</div>
              <div><label className="text-xs font-medium text-slate-600 block mb-1">Description *</label><textarea rows={3} className={`${inputCls} resize-none`} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Describe the role, responsibilities and ideal candidate…" />{errors.description && <p className="text-[11px] text-rose-600 mt-1">{errors.description}</p>}</div>
              <div>
                <label className="text-xs font-medium text-slate-600 block mb-2">Required Skills * ({form.skills.length} selected)</label>
                <div className="flex flex-wrap gap-1.5 max-h-32 overflow-y-auto p-2 bg-slate-50 rounded-xl">
                  {ALL_SKILLS.map((s) => { const on = form.skills.includes(s); return <button type="button" key={s} onClick={() => setForm({ ...form, skills: on ? form.skills.filter((x) => x !== s) : [...form.skills, s] })} className={`text-[11px] px-2 py-1 rounded-full ${on ? "bg-indigo-600 text-white" : "bg-white border border-slate-200 text-slate-600"}`}>{s}</button>; })}
                </div>
                {errors.skills && <p className="text-[11px] text-rose-600 mt-1">{errors.skills}</p>}
              </div>
              <button type="submit" className="w-full bg-indigo-600 text-white py-3 rounded-xl font-medium text-sm hover:bg-indigo-700 transition-colors">Save Opportunity (demo)</button>
            </form>
          </div>
        </div>
      )}

      {tab === "candidates" && (
        <div>
          <div className="bg-white rounded-2xl border border-slate-200 p-4 mb-4">
            <div className="flex items-center justify-between flex-wrap gap-2 mb-3">
              <div>
                <p className="text-sm font-semibold text-slate-700">Candidate Discovery</p>
                <p className="text-xs text-slate-500">Filter by skills. Match = how closely candidates reach the minimum level on every selected skill.</p>
              </div>
              <div className="flex gap-2">
                <select value={minLevel} onChange={(e) => setMinLevel(Number(e.target.value))} className="text-xs border border-slate-200 rounded-lg px-2 py-1.5 bg-white text-slate-700 outline-none">
                  <option value={30}>Min: Beginner</option><option value={55}>Min: Intermediate</option><option value={70}>Min: Advanced</option>
                </select>
                <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="text-xs border border-slate-200 rounded-lg px-2 py-1.5 bg-white text-slate-700 outline-none">
                  <option value="all">All status</option><option value="new">New</option><option value="shortlisted">Shortlisted</option>
                </select>
              </div>
            </div>
            <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto">
              {ALL_SKILLS.map((s) => { const on = filterSkills.includes(s); return <button key={s} onClick={() => setFilterSkills(on ? filterSkills.filter((x) => x !== s) : [...filterSkills, s])} className={`text-[11px] px-2 py-1 rounded-full ${on ? "bg-indigo-600 text-white" : "bg-slate-50 border border-slate-200 text-slate-600"}`}>{s}</button>; })}
            </div>
            {filterSkills.length > 0 && <button onClick={() => setFilterSkills([])} className="text-[11px] text-slate-400 hover:text-slate-600 mt-2">Clear skill filter</button>}
          </div>

          <div className="space-y-3">
            {results.map(({ c, match }) => {
              const st = status(c.id);
              const isOpen = open === c.id;
              return (
                <div key={c.id} className="bg-white rounded-2xl border border-slate-200 p-4">
                  <div className="flex items-center gap-4 flex-wrap">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-400 to-violet-500 flex items-center justify-center text-xs font-bold text-white shrink-0">{c.name.split(" ").map((w) => w[0]).slice(0, 2).join("")}</div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="text-sm font-semibold text-slate-800">{c.name}</p>
                        <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${statusColors[st]}`}>{st === "new" ? "New" : "Shortlisted"}</span>
                        {c.demo && <span className="text-[9px] bg-amber-100 text-amber-700 px-1.5 py-0.5 rounded-full">DEMO DATA</span>}
                      </div>
                      <p className="text-xs text-slate-500">{c.college}</p>
                      <div className="flex gap-3 mt-1 text-[11px] text-slate-500">
                        <span>Projects: <strong className="text-slate-700">{c.projects.length}</strong></span>
                        <span>Diagnostic: <strong className="text-slate-700">{c.assessment ? `${c.assessment.score}/${c.assessment.total}` : "not taken"}</strong></span>
                      </div>
                    </div>
                    <div className="flex gap-2 items-center">
                      {match !== null && (
                        <div className="text-right mr-2">
                          <div className="text-xl font-bold font-mono" style={{ color: match >= 85 ? "#10B981" : match >= 60 ? "#4F46E5" : "#F59E0B" }}>{match}%</div>
                          <div className="text-[10px] text-slate-400">skill match</div>
                        </div>
                      )}
                      <button onClick={() => setOpen(isOpen ? null : c.id)} className="text-xs px-3 py-2 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50">{isOpen ? "Hide Profile" : "View Profile"}</button>
                      <button onClick={() => patch((s) => ({ candidateStatus: { ...s.candidateStatus, [c.id]: st === "shortlisted" ? "new" : "shortlisted" } }))}
                        className={`text-xs px-3 py-2 rounded-xl font-medium transition-colors ${st === "shortlisted" ? "bg-emerald-500 text-white hover:bg-emerald-600" : "bg-indigo-600 text-white hover:bg-indigo-700"}`}>
                        {st === "shortlisted" ? "✓ Shortlisted" : "Shortlist"}
                      </button>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-1.5 mt-3 pl-14">
                    {Object.entries(c.skills).map(([n, s]) => (
                      <span key={n} className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${chip[s.status]}`}>{n} · {levelLabel(s.level)} · {chipLabel[s.status]}</span>
                    ))}
                  </div>
                  {isOpen && (
                    <div className="mt-4 pl-14 grid grid-cols-1 sm:grid-cols-2 gap-4 border-t border-slate-100 pt-4">
                      <div>
                        <p className="text-xs font-semibold text-slate-700 mb-2">Project evidence</p>
                        {c.projects.length === 0 ? <p className="text-xs text-slate-500">No projects added.</p> : c.projects.map((p) => (
                          <div key={p.title} className="mb-2 p-2 bg-slate-50 rounded-lg">
                            <p className="text-xs font-medium text-slate-800">{p.title}</p>
                            <p className="text-[11px] text-slate-500">{p.evidence || "No evidence provided"}</p>
                            {p.github && <a className="text-[11px] text-indigo-600 hover:underline" href={p.github} target="_blank" rel="noopener noreferrer">GitHub ↗</a>}
                          </div>
                        ))}
                      </div>
                      <div>
                        <p className="text-xs font-semibold text-slate-700 mb-2">Assessment information</p>
                        <p className="text-xs text-slate-600">{c.assessment ? `Diagnostic: ${c.assessment.score} of ${c.assessment.total} correct. This is a short self-check, not a certification.` : "No diagnostic taken."}</p>
                        <p className="text-[11px] text-slate-400 mt-2">No skills in this prototype are third-party verified.</p>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
