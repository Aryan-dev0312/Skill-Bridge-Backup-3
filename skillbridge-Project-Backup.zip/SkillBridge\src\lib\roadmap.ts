import { CAREERS, RESOURCES, type Career, type Resource } from "./catalog.ts";
import type { SkillResult } from "./skillGap.ts";

export type TaskKind = "Learn" | "Practice" | "Project" | "Mock Assessment";
export interface RoadTask {
  id: string; skill: string; kind: TaskKind; title: string; why: string; doneWhen: string; hours: number; resource?: Resource;
}
export interface RoadPhase {
  phase: number; title: string; weeks: string; startWeek: number; endWeek: number; skills: string[]; tasks: RoadTask[]; hours: number;
}
export interface Roadmap { phases: RoadPhase[]; totalWeeks: number; totalHours: number }

const clamp = (n: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, n));
const PRIORITY = (r: SkillResult) => r.gap * r.weight;

/** Estimated study hours to close a gap. A rough planning heuristic, not a measured value. */
export const hoursToClose = (gap: number) => Math.max(2, Math.round(gap * 0.6));

export function generateRoadmap(rows: SkillResult[], career: Career | null, weeklyHours: number): Roadmap {
  const perWeek = clamp(Math.round(weeklyHours) || 6, 1, 40);
  const gaps = rows.filter((r) => r.gap > 0).sort((a, b) => PRIORITY(b) - PRIORITY(a)).slice(0, 6);
  if (gaps.length === 0) return { phases: [], totalWeeks: 0, totalHours: 0 };

  const phases: RoadPhase[] = [];
  let week = 1;
  for (let i = 0; i < gaps.length; i += 2) {
    const group = gaps.slice(i, i + 2);
    const names = group.map((g) => g.name);
    const idx = phases.length;
    const tasks: RoadTask[] = [];
    for (const g of group) {
      const learnH = clamp(Math.round(hoursToClose(g.gap) * 0.5), 2, 12);
      const practH = clamp(Math.round(hoursToClose(g.gap) * 0.5), 2, 10);
      tasks.push({
        id: `${g.name}:learn`, skill: g.name, kind: "Learn", hours: learnH, resource: RESOURCES[g.name],
        title: `Study ${g.name} fundamentals`,
        why: `${g.name} is ${g.current}% today vs ${g.target}% expected for ${career?.title ?? "your target role"} (gap ${g.gap}).`,
        doneWhen: RESOURCES[g.name] ? `You have worked through the core sections of "${RESOURCES[g.name].title}" and can explain the main ideas in your own words.` : `You have completed a structured beginner course or official documentation for ${g.name}.`,
      });
      tasks.push({
        id: `${g.name}:practice`, skill: g.name, kind: "Practice", hours: practH,
        title: `Practice assignment: 3 hands-on ${g.name} exercises`,
        why: `Applying ${g.name} is what moves your rating; reading alone rarely closes a gap.`,
        doneWhen: `You have written or built 3 small ${g.name} exercises from scratch and saved them (for example in a GitHub repo).`,
      });
    }
    const proj = career?.projects[idx % (career.projects.length || 1)] ?? `Build a small project using ${names.join(" and ")}`;
    tasks.push({
      id: `phase${idx + 1}:project`, skill: names[0], kind: "Project", hours: 6, title: `Project: ${proj}`,
      why: `A finished project is evidence recruiters can inspect and combines ${names.join(" + ")}.`,
      doneWhen: "The project runs, has a README, and its code is published with a link you can share.",
    });
    tasks.push({
      id: `phase${idx + 1}:mock`, skill: names[0], kind: "Mock Assessment", hours: 1, title: `Self-check: explain ${names.join(" and ")} without notes`,
      why: "Testing yourself reveals what you only recognise versus what you can recall.",
      doneWhen: "You answered 10 questions you wrote yourself on these topics and reviewed every miss.",
    });
    const hours = tasks.reduce((s, t) => s + t.hours, 0);
    const span = Math.max(1, Math.ceil(hours / perWeek));
    phases.push({ phase: idx + 1, title: `Close gaps: ${names.join(" & ")}`, weeks: span === 1 ? `Week ${week}` : `Weeks ${week}–${week + span - 1}`, startWeek: week, endWeek: week + span - 1, skills: names, tasks, hours });
    week += span;
  }
  phases.push({
    phase: phases.length + 1, title: "Reassess & update your profile", weeks: `Week ${week}`, startWeek: week, endWeek: week, skills: [], hours: 1,
    tasks: [{ id: "reassess", skill: "", kind: "Mock Assessment", hours: 1, title: "Update your skill ratings and review the new gap analysis", why: "New ratings recalculate your gaps and refresh this roadmap.", doneWhen: "You re-rated the skills you practised on My Skills and checked the Skill Gap screen." }],
  });
  return { phases, totalWeeks: week, totalHours: phases.reduce((s, p) => s + p.hours, 0) };
}
export { CAREERS };
