import { useState, useMemo } from "react";
import {
  LEARNING_RESOURCES,
  RESOURCE_DOMAINS,
  type LearningResource,
  type ResourceDomain,
} from "../lib/resourcesData";
import { useStore } from "../lib/store";

interface ResourcesProps {
  initialSkill?: string;
  onNavigate?: (screen: string) => void;
}

export default function Resources({ initialSkill, onNavigate }: ResourcesProps) {
  const { state, rows, career, toggleResourceBookmark, toggleResourceCompleted } = useStore();

  const [selectedDomain, setSelectedDomain] = useState<string>("All");
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>("All");
  const [searchQuery, setSearchQuery] = useState<string>(initialSkill ?? "");
  const [activeTab, setActiveTab] = useState<"all" | "recommended" | "saved" | "completed">("all");

  const bookmarked = state.bookmarkedResources ?? [];
  const completed = state.completedResources ?? [];

  // Skills where student has an active gap (high or medium severity)
  const gapSkillNames = useMemo(() => {
    return new Set(
      rows
        .filter((r) => r.severity === "high" || r.severity === "medium")
        .map((r) => r.skill.toLowerCase()),
    );
  }, [rows]);

  // Target career required skill names
  const careerSkillNames = useMemo(() => {
    if (!career) return new Set<string>();
    return new Set(career.required.map((req) => req.name.toLowerCase()));
  }, [career]);

  // Filtered resources
  const filteredResources = useMemo(() => {
    return LEARNING_RESOURCES.filter((res) => {
      // Tab filter
      if (activeTab === "saved" && !bookmarked.includes(res.id)) return false;
      if (activeTab === "completed" && !completed.includes(res.id)) return false;
      if (activeTab === "recommended") {
        const matchesGapOrCareer = res.relatedSkills.some(
          (s) => gapSkillNames.has(s.toLowerCase()) || careerSkillNames.has(s.toLowerCase()),
        );
        if (!matchesGapOrCareer) return false;
      }

      // Domain filter
      if (selectedDomain !== "All" && res.domain !== selectedDomain) return false;

      // Difficulty filter
      if (selectedDifficulty !== "All" && res.difficulty !== selectedDifficulty) return false;

      // Search query filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesTitle = res.title.toLowerCase().includes(q);
        const matchesProvider = res.provider.toLowerCase().includes(q);
        const matchesDesc = res.description.toLowerCase().includes(q);
        const matchesSkills = res.relatedSkills.some((s) => s.toLowerCase().includes(q));
        const matchesDomain = res.domain.toLowerCase().includes(q);
        if (!matchesTitle && !matchesProvider && !matchesDesc && !matchesSkills && !matchesDomain) {
          return false;
        }
      }

      return true;
    });
  }, [
    activeTab,
    selectedDomain,
    selectedDifficulty,
    searchQuery,
    bookmarked,
    completed,
    gapSkillNames,
    careerSkillNames,
  ]);

  // Count of recommended resources
  const recommendedCount = useMemo(() => {
    return LEARNING_RESOURCES.filter((res) =>
      res.relatedSkills.some(
        (s) => gapSkillNames.has(s.toLowerCase()) || careerSkillNames.has(s.toLowerCase()),
      ),
    ).length;
  }, [gapSkillNames, careerSkillNames]);

  return (
    <div className="p-4 sm:p-6 max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold bg-indigo-50 text-indigo-700 px-2.5 py-0.5 rounded-full border border-indigo-200 font-mono">
              Verified Educational Index
            </span>
            <span className="text-xs text-slate-500">11 Technical Domains</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            Smart Learning Resource Recommendations
          </h1>
          <p className="text-xs text-slate-500 mt-1 max-w-2xl">
            Authentic, high-yield tutorials, courseware, and reference systems mapped to your target career role ({career?.title || "Engineering"}) and high-priority skill gaps.
          </p>
        </div>

        {onNavigate && (
          <button
            onClick={() => onNavigate("roadmap")}
            className="self-start sm:self-auto text-xs text-indigo-600 hover:text-indigo-800 font-semibold border border-indigo-200 px-3.5 py-2 rounded-xl bg-indigo-50/50 hover:bg-indigo-50 transition-colors"
          >
            View Your Roadmap →
          </button>
        )}
      </div>

      {/* Quick Stats Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
          <p className="text-xs text-slate-400 font-medium">Catalog Resources</p>
          <p className="text-2xl font-bold text-slate-900 font-mono mt-0.5">
            {LEARNING_RESOURCES.length}
          </p>
          <p className="text-[11px] text-slate-500 mt-1">Across 11 technical tracks</p>
        </div>
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
          <p className="text-xs text-slate-400 font-medium">Recommended for You</p>
          <p className="text-2xl font-bold text-indigo-600 font-mono mt-0.5">
            {recommendedCount}
          </p>
          <p className="text-[11px] text-indigo-600 font-medium mt-1">
            Targeted to your {rows.filter((r) => r.severity === "high").length} high gaps
          </p>
        </div>
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
          <p className="text-xs text-slate-400 font-medium">Saved Bookmarks</p>
          <p className="text-2xl font-bold text-amber-600 font-mono mt-0.5">
            {bookmarked.length}
          </p>
          <p className="text-[11px] text-slate-500 mt-1">Pinned to your reading list</p>
        </div>
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
          <p className="text-xs text-slate-400 font-medium">Completed</p>
          <p className="text-2xl font-bold text-emerald-600 font-mono mt-0.5">
            {completed.length}
          </p>
          <p className="text-[11px] text-emerald-600 font-medium mt-1">
            {Math.round((completed.length / Math.max(1, LEARNING_RESOURCES.length)) * 100)}% of catalog
          </p>
        </div>
      </div>

      {/* Tabs & Search Controls */}
      <div className="space-y-3">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          {/* Main Tabs */}
          <div className="flex rounded-xl bg-slate-100 p-1">
            <button
              onClick={() => setActiveTab("all")}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === "all" ? "bg-white text-slate-900 shadow-xs" : "text-slate-600 hover:text-slate-900"
              }`}
            >
              All Resources ({LEARNING_RESOURCES.length})
            </button>
            <button
              onClick={() => setActiveTab("recommended")}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === "recommended"
                  ? "bg-indigo-600 text-white shadow-xs"
                  : "text-slate-600 hover:text-indigo-600"
              }`}
            >
              Recommended for You ({recommendedCount})
            </button>
            <button
              onClick={() => setActiveTab("saved")}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === "saved" ? "bg-white text-slate-900 shadow-xs" : "text-slate-600 hover:text-slate-900"
              }`}
            >
              Saved ({bookmarked.length})
            </button>
            <button
              onClick={() => setActiveTab("completed")}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === "completed" ? "bg-white text-slate-900 shadow-xs" : "text-slate-600 hover:text-slate-900"
              }`}
            >
              Completed ({completed.length})
            </button>
          </div>

          {/* Search bar */}
          <div className="relative flex-1 sm:max-w-xs">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by skill, topic, provider..."
              className="w-full text-xs border border-slate-200 rounded-xl pl-8 pr-3 py-2 bg-white text-slate-800 placeholder-slate-400 outline-none focus:ring-2 focus:ring-indigo-300"
            />
            <span className="absolute left-2.5 top-2.5 text-slate-400 text-xs">🔍</span>
            {searchQuery && (
              <button
                onClick={() => setSearchQuery("")}
                className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600 text-xs"
              >
                ✕
              </button>
            )}
          </div>
        </div>

        {/* Domain Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs scrollbar-hide">
          <button
            onClick={() => setSelectedDomain("All")}
            className={`px-3 py-1.5 rounded-xl font-medium shrink-0 transition-all ${
              selectedDomain === "All"
                ? "bg-slate-900 text-white shadow-xs"
                : "bg-white border border-slate-200 text-slate-600 hover:bg-slate-50"
            }`}
          >
            All Tracks
          </button>
          {RESOURCE_DOMAINS.map((domain) => (
            <button
              key={domain}
              onClick={() => setSelectedDomain(domain)}
              className={`px-3 py-1.5 rounded-xl font-medium shrink-0 transition-all ${
                selectedDomain === domain
                  ? "bg-slate-900 text-white shadow-xs"
                  : "bg-white border border-slate-200 text-slate-600 hover:bg-slate-50"
              }`}
            >
              {domain}
            </button>
          ))}
        </div>

        {/* Secondary Difficulty Filter */}
        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-400 font-medium">Difficulty:</span>
          {["All", "Beginner", "Intermediate", "Advanced"].map((diff) => (
            <button
              key={diff}
              onClick={() => setSelectedDifficulty(diff)}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors ${
                selectedDifficulty === diff
                  ? "bg-indigo-100 text-indigo-700 font-bold"
                  : "text-slate-500 hover:text-slate-800"
              }`}
            >
              {diff}
            </button>
          ))}
        </div>
      </div>

      {/* Resource Cards Grid */}
      {filteredResources.length === 0 ? (
        <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center space-y-3">
          <span className="text-3xl">📚</span>
          <h3 className="text-base font-bold text-slate-800">No matching learning resources found</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Try adjusting your search keywords, switching to "All Tracks", or clearing your filters.
          </p>
          <button
            onClick={() => {
              setSelectedDomain("All");
              setSelectedDifficulty("All");
              setSearchQuery("");
              setActiveTab("all");
            }}
            className="text-xs font-semibold text-indigo-600 hover:underline pt-2"
          >
            Reset all filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredResources.map((res) => {
            const isBookmarked = bookmarked.includes(res.id);
            const isCompleted = completed.includes(res.id);
            const matchesGap = res.relatedSkills.some((s) => gapSkillNames.has(s.toLowerCase()));

            return (
              <div
                key={res.id}
                className={`p-5 rounded-3xl border bg-white shadow-xs flex flex-col justify-between transition-all hover:shadow-md ${
                  matchesGap ? "border-indigo-200/80 ring-1 ring-indigo-100" : "border-slate-200"
                }`}
              >
                <div className="space-y-3">
                  {/* Top Badge Row */}
                  <div className="flex items-center justify-between gap-2 flex-wrap text-[11px]">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="px-2.5 py-0.5 rounded-full font-medium bg-slate-100 text-slate-700">
                        {res.domain}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded-full font-bold ${
                          res.difficulty === "Beginner"
                            ? "bg-emerald-50 text-emerald-700"
                            : res.difficulty === "Intermediate"
                            ? "bg-blue-50 text-blue-700"
                            : "bg-purple-50 text-purple-700"
                        }`}
                      >
                        {res.difficulty}
                      </span>
                      {matchesGap && (
                        <span className="px-2 py-0.5 rounded-full font-semibold bg-rose-50 text-rose-700 border border-rose-200">
                          🎯 Targets Skill Gap
                        </span>
                      )}
                    </div>

                    <span className="font-mono text-slate-400 text-[10px]">
                      ~{res.estimatedHours}h · {res.cost}
                    </span>
                  </div>

                  {/* Provider & Title */}
                  <div>
                    <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                      {res.provider}
                    </p>
                    <h3 className="text-base font-bold text-slate-900 mt-0.5 leading-snug">
                      {res.title}
                    </h3>
                  </div>

                  {/* Description */}
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {res.description}
                  </p>

                  {/* Practical Project / Hands-on Exercise */}
                  <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 text-xs space-y-1">
                    <div className="flex items-center gap-1.5 text-slate-700 font-bold text-[11px]">
                      <span>⚡ Hands-on Challenge:</span>
                    </div>
                    <p className="text-[11px] text-slate-600 leading-normal">
                      {res.exercise}
                    </p>
                  </div>

                  {/* Related Skills Pills */}
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {res.relatedSkills.map((skill) => {
                      const isGap = gapSkillNames.has(skill.toLowerCase());
                      return (
                        <button
                          key={skill}
                          type="button"
                          onClick={() => setSearchQuery(skill)}
                          className={`text-[10px] px-2 py-0.5 rounded-md font-medium transition-colors ${
                            isGap
                              ? "bg-indigo-50 text-indigo-700 font-bold border border-indigo-200"
                              : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                          }`}
                        >
                          {skill} {isGap && "★"}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Footer Actions */}
                <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    {/* Bookmark Toggle */}
                    <button
                      type="button"
                      onClick={() => toggleResourceBookmark(res.id)}
                      className={`p-2 rounded-xl text-xs font-semibold transition-colors flex items-center gap-1 border ${
                        isBookmarked
                          ? "bg-amber-50 text-amber-700 border-amber-300"
                          : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50"
                      }`}
                      title={isBookmarked ? "Remove from bookmarks" : "Save for later"}
                    >
                      <span>{isBookmarked ? "★" : "☆"}</span>
                      <span className="hidden sm:inline">{isBookmarked ? "Saved" : "Save"}</span>
                    </button>

                    {/* Completion Toggle */}
                    <button
                      type="button"
                      onClick={() => toggleResourceCompleted(res.id)}
                      className={`p-2 rounded-xl text-xs font-semibold transition-colors flex items-center gap-1 border ${
                        isCompleted
                          ? "bg-emerald-50 text-emerald-700 border-emerald-300"
                          : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50"
                      }`}
                      title={isCompleted ? "Mark as uncompleted" : "Mark as completed"}
                    >
                      <span>{isCompleted ? "✓" : "○"}</span>
                      <span className="hidden sm:inline">{isCompleted ? "Done" : "Complete"}</span>
                    </button>
                  </div>

                  {/* External Resource Link */}
                  <a
                    href={res.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs transition-colors flex items-center gap-1.5 shadow-xs"
                  >
                    <span>Open Resource</span>
                    <span>↗</span>
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
