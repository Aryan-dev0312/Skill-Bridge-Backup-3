import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { CAREERS, QUESTIONS, careerById, type Career } from "./catalog.ts";
import { analyze, type SkillInput, type SkillResult, type Severity } from "./skillGap.ts";
import { generateRoadmap, type Roadmap } from "./roadmap.ts";

export const LEVELS = { Beginner: 30, Intermediate: 55, Advanced: 80 } as const;
export const levelLabel = (n: number) => (n >= 70 ? "Advanced" : n >= 45 ? "Intermediate" : "Beginner");

export interface Project {
  id: string;
  title: string;
  description: string;
  techStack: string[];
  github: string;
  demoUrl: string;
  skills: string[];
  evidence: string;
  status: "planned" | "in_progress" | "completed";
  reviewRequested: boolean;
  createdAt: string;
  demo?: boolean;
}

export interface PostedOpp {
  id: string;
  title: string;
  type: string;
  location: string;
  description: string;
  skills: string[];
  createdAt: string;
}

export interface ComprehensiveAssessmentResult {
  id: string;
  timestamp: string;
  durationSeconds: number;
  totalQuestions: number;
  score: number;
  accuracy: number;
  domainBreakdown: Record<string, { total: number; score: number; pct: number }>;
  userAnswers: Record<string, number>;
  assessedSkills: Record<string, { level: number; passed: boolean }>;
  submissionReason?: "normal" | "tab_switch_auto_submit" | "timeout";
}

export interface CollegeStudentRecord {
  id: string;
  name: string;
  department: string;
  batch: string;
  cgpa: number;
  topSkills: string[];
  status: "Placed" | "Unplaced" | "In Process";
  company?: string;
  packageLPA?: number;
  assessmentScore?: number;
  isDemo?: boolean;
}

export interface State {
  step: number;
  maxStep: number;
  onboarded: boolean;
  account: { name: string; email: string } | null;
  academic: { college: string; degree: string; year: string; gradYear: string; cgpa: string };
  position: { stage: string; experience: string; weeklyHours: number; focus: string };
  selected: Record<string, number>;
  initialLevels: Record<string, number>;
  answers: Record<string, number>;
  careerId: string | null;
  profileGenerated: boolean;
  completedTasks: Record<string, string>;
  projects: Project[];
  history: { t: string; readiness: number }[];
  postedOpps: PostedOpp[];
  candidateStatus: Record<string, "new" | "shortlisted">;
  demo: boolean;
  theme?: "dark" | "light" | "system";
  language?: "en" | "hi";
  settings?: {
    notifications: { weeklyDigest: boolean; roadmapReminders: boolean; opportunityAlerts: boolean };
    privacy: { visibility: "public" | "anonymous" | "private"; recruiterMessages: boolean; shareBenchmarks: boolean };
    assessmentPolicy?: { strictTabSwitch: boolean };
  };
  comprehensiveAssessments?: ComprehensiveAssessmentResult[];
  bookmarkedResources?: string[];
  completedResources?: string[];
  collegeCohort?: CollegeStudentRecord[];
}

export const INITIAL_DEMO_COHORT: CollegeStudentRecord[] = [
  { id: "STU-2024-001", name: "Aarav Sharma", department: "Computer Science", batch: "2025", cgpa: 8.9, topSkills: ["Python", "Data Structures", "Docker", "System Design"], status: "Placed", company: "Microsoft", packageLPA: 24.5, assessmentScore: 92, isDemo: true },
  { id: "STU-2024-002", name: "Priya Nair", department: "Computer Science", batch: "2025", cgpa: 9.2, topSkills: ["React", "TypeScript", "Node.js", "REST APIs"], status: "Placed", company: "Amazon", packageLPA: 28.0, assessmentScore: 88, isDemo: true },
  { id: "STU-2024-003", name: "Rohan Verma", department: "Information Technology", batch: "2025", cgpa: 7.8, topSkills: ["Java", "Spring Boot", "SQL", "Git"], status: "Placed", company: "Cisco", packageLPA: 16.0, assessmentScore: 78, isDemo: true },
  { id: "STU-2024-004", name: "Ananya Iyer", department: "Computer Science", batch: "2025", cgpa: 9.4, topSkills: ["Machine Learning", "PyTorch", "Python", "Statistics"], status: "Placed", company: "NVIDIA", packageLPA: 32.0, assessmentScore: 95, isDemo: true },
  { id: "STU-2024-005", name: "Vikram Malhotra", department: "Electronics & Comm", batch: "2025", cgpa: 8.1, topSkills: ["C++", "Embedded C", "Digital Logic", "Linux/Shell"], status: "Placed", company: "Qualcomm", packageLPA: 22.0, assessmentScore: 84, isDemo: true },
  { id: "STU-2024-006", name: "Sneha Reddy", department: "Information Technology", batch: "2025", cgpa: 8.5, topSkills: ["Cloud Platforms", "Docker", "Terraform", "CI/CD"], status: "Placed", company: "Salesforce", packageLPA: 19.5, assessmentScore: 81, isDemo: true },
  { id: "STU-2024-007", name: "Aditya Patil", department: "Computer Science", batch: "2025", cgpa: 7.4, topSkills: ["Python", "SQL", "Data Visualization"], status: "In Process", company: undefined, packageLPA: undefined, assessmentScore: 68, isDemo: true },
  { id: "STU-2024-008", name: "Meera Menon", department: "Data Science", batch: "2025", cgpa: 8.7, topSkills: ["LLMs", "RAG", "Python", "Vector Databases"], status: "Placed", company: "Adobe", packageLPA: 26.0, assessmentScore: 90, isDemo: true },
  { id: "STU-2024-009", name: "Kunal Gupta", department: "Computer Science", batch: "2025", cgpa: 6.9, topSkills: ["JavaScript", "HTML/CSS"], status: "Unplaced", company: undefined, packageLPA: undefined, assessmentScore: 52, isDemo: true },
  { id: "STU-2024-010", name: "Ishaan Mukherjee", department: "Information Technology", batch: "2025", cgpa: 8.2, topSkills: ["Security Fundamentals", "OWASP", "Networking"], status: "Placed", company: "Cisco", packageLPA: 15.0, assessmentScore: 76, isDemo: true },
  { id: "STU-2024-011", name: "Divya Joshi", department: "Electronics & Comm", batch: "2025", cgpa: 7.9, topSkills: ["Python", "Algorithms", "Git"], status: "In Process", company: undefined, packageLPA: undefined, assessmentScore: 65, isDemo: true },
  { id: "STU-2024-012", name: "Arjun Rao", department: "Computer Science", batch: "2025", cgpa: 9.1, topSkills: ["System Design", "Go", "Docker", "Kubernetes"], status: "Placed", company: "Google", packageLPA: 35.0, assessmentScore: 96, isDemo: true },
  { id: "STU-2024-013", name: "Tanvi Saxena", department: "Data Science", batch: "2025", cgpa: 8.3, topSkills: ["NumPy/Pandas", "Statistics", "SQL", "Tableau"], status: "Placed", company: "Intel", packageLPA: 18.0, assessmentScore: 79, isDemo: true },
  { id: "STU-2024-014", name: "Siddharth Deshmukh", department: "Computer Science", batch: "2025", cgpa: 7.1, topSkills: ["C++", "Data Structures"], status: "Unplaced", company: undefined, packageLPA: undefined, assessmentScore: 58, isDemo: true },
  { id: "STU-2024-015", name: "Kavya Pillai", department: "Information Technology", batch: "2025", cgpa: 8.6, topSkills: ["React", "Node.js", "Docker", "PostgreSQL"], status: "Placed", company: "Amazon", packageLPA: 26.5, assessmentScore: 87, isDemo: true },
];

const initial: State = {
  step: 1,
  maxStep: 1,
  onboarded: false,
  account: null,
  academic: { college: "", degree: "", year: "", gradYear: "", cgpa: "" },
  position: { stage: "", experience: "", weeklyHours: 6, focus: "" },
  selected: {},
  initialLevels: {},
  answers: {},
  careerId: null,
  profileGenerated: false,
  completedTasks: {},
  projects: [],
  history: [],
  postedOpps: [],
  candidateStatus: {},
  demo: false,
  theme: "system",
  language: "en",
  settings: {
    notifications: { weeklyDigest: true, roadmapReminders: true, opportunityAlerts: true },
    privacy: { visibility: "public", recruiterMessages: true, shareBenchmarks: true },
    assessmentPolicy: { strictTabSwitch: true },
  },
  comprehensiveAssessments: [],
  bookmarkedResources: ["res_react_01", "res_dsa_01", "res_sys_01"],
  completedResources: ["res_git_01"],
  collegeCohort: INITIAL_DEMO_COHORT,
};

const KEY = "skillbridge:v1";
function load(): State {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        ...initial,
        ...parsed,
        settings: {
          ...initial.settings,
          ...(parsed.settings ?? {}),
          assessmentPolicy: {
            ...initial.settings?.assessmentPolicy,
            ...(parsed.settings?.assessmentPolicy ?? {}),
          },
        },
        bookmarkedResources: parsed.bookmarkedResources ?? initial.bookmarkedResources,
        completedResources: parsed.completedResources ?? initial.completedResources,
        collegeCohort: parsed.collegeCohort && parsed.collegeCohort.length > 0 ? parsed.collegeCohort : INITIAL_DEMO_COHORT,
      };
    }
  } catch {
    /* storage unavailable or corrupt: start fresh */
  }
  return initial;
}

export function demoState(): State {
  const now = new Date().toISOString();
  return {
    ...initial,
    step: 8,
    maxStep: 8,
    onboarded: true,
    demo: true,
    profileGenerated: true,
    account: { name: "Demo Student", email: "demo@example.com" },
    academic: { college: "Demo University", degree: "B.Tech Computer Science", year: "3rd", gradYear: "2027", cgpa: "8.8" },
    position: { stage: "Learning on my own", experience: "1-2 years", weeklyHours: 8, focus: "Machine learning" },
    selected: { Python: 70, "Data Structures": 65, SQL: 55, Git: 55, "NumPy/Pandas": 55, "Machine Learning": 40, Statistics: 40, Docker: 30 },
    initialLevels: { Python: 70, "Data Structures": 65, SQL: 55, Git: 55, "NumPy/Pandas": 55, "Machine Learning": 40, Statistics: 40, Docker: 30 },
    answers: { q1: 1, q2: 2, q3: 0, q4: 2, q5: 0 },
    careerId: "ml",
    projects: [
      { id: "demo1", title: "Leaf Disease Classifier", description: "Sample project: small CNN that classifies leaf images.", techStack: ["Python", "PyTorch"], github: "", demoUrl: "", skills: ["Python", "Deep Learning"], evidence: "", status: "completed", reviewRequested: false, createdAt: now, demo: true },
      { id: "demo2", title: "SQL Sales Dashboard", description: "Sample project: dashboard built from SQL queries.", techStack: ["SQL"], github: "", demoUrl: "", skills: ["SQL"], evidence: "", status: "in_progress", reviewRequested: false, createdAt: now, demo: true },
    ],
    comprehensiveAssessments: [],
    bookmarkedResources: ["res_dsa_01", "res_ml_01", "res_sys_01"],
    completedResources: ["res_git_01"],
    collegeCohort: INITIAL_DEMO_COHORT,
  };
}

export interface Assessment {
  score: number;
  total: number;
  results: Record<string, boolean>;
}

interface Ctx {
  state: State;
  patch: (p: Partial<State> | ((s: State) => Partial<State>)) => void;
  reset: () => void;
  loadDemo: () => void;
  skills: Record<string, SkillInput & { assessed?: boolean }>;
  assessment: Assessment | null;
  career: Career | null;
  rows: SkillResult[];
  counts: Record<Severity, number>;
  readiness: number | null;
  roadmap: Roadmap;
  taskStats: { done: number; total: number; pct: number };
  toggleTask: (id: string) => void;
  nextTask: { id: string; title: string; phase: string } | null;
  saveComprehensiveAssessment: (result: ComprehensiveAssessmentResult) => void;
  toggleResourceBookmark: (resourceId: string) => void;
  toggleResourceCompleted: (resourceId: string) => void;
  saveCollegeCohort: (records: CollegeStudentRecord[]) => void;
  resetCollegeCohort: () => void;
  setStrictTabSwitch: (enabled: boolean) => void;
}

const StoreCtx = createContext<Ctx | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<State>(load);

  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(state));
    } catch {
      /* ignore quota/privacy errors */
    }
  }, [state]);

  const patch = useCallback((p: Partial<State> | ((s: State) => Partial<State>)) => {
    setState((s) => ({ ...s, ...(typeof p === "function" ? p(s) : p) }));
  }, []);

  const reset = useCallback(() => {
    try {
      localStorage.removeItem(KEY);
    } catch {
      /* ignore */
    }
    setState(initial);
  }, []);

  const loadDemo = useCallback(() => setState(demoState()), []);

  const assessment = useMemo<Assessment | null>(() => {
    if (!QUESTIONS.every((q) => state.answers[q.id] !== undefined)) return null;
    const results: Record<string, boolean> = {};
    QUESTIONS.forEach((q) => (results[q.skill] = state.answers[q.id] === q.answer));
    return { score: Object.values(results).filter(Boolean).length, total: QUESTIONS.length, results };
  }, [state.answers]);

  // Effective skills: self-reported ratings, overridden by diagnostic assessment AND comprehensive assessments.
  const skills = useMemo(() => {
    const out: Record<string, SkillInput & { assessed?: boolean }> = {};
    Object.entries(state.selected).forEach(([n, level]) => (out[n] = { level, status: "self" }));
    if (assessment) {
      Object.entries(assessment.results).forEach(([n, ok]) => {
        out[n] = { level: ok ? Math.max(out[n]?.level ?? 0, 70) : (out[n]?.level ?? 35), status: "assessed", assessed: true };
      });
    }
    if (state.comprehensiveAssessments && state.comprehensiveAssessments.length > 0) {
      state.comprehensiveAssessments.forEach((attempt) => {
        Object.entries(attempt.assessedSkills).forEach(([skillName, data]) => {
          out[skillName] = {
            level: data.level,
            status: "assessed",
            assessed: true,
          };
        });
      });
    }
    return out;
  }, [state.selected, assessment, state.comprehensiveAssessments]);

  const saveComprehensiveAssessment = useCallback((result: ComprehensiveAssessmentResult) => {
    setState((s) => ({
      ...s,
      comprehensiveAssessments: [...(s.comprehensiveAssessments ?? []), result],
    }));
  }, []);

  const toggleResourceBookmark = useCallback((resourceId: string) => {
    setState((s) => {
      const current = s.bookmarkedResources ?? [];
      const exists = current.includes(resourceId);
      const next = exists ? current.filter((id) => id !== resourceId) : [...current, resourceId];
      return { ...s, bookmarkedResources: next };
    });
  }, []);

  const toggleResourceCompleted = useCallback((resourceId: string) => {
    setState((s) => {
      const current = s.completedResources ?? [];
      const exists = current.includes(resourceId);
      const next = exists ? current.filter((id) => id !== resourceId) : [...current, resourceId];
      return { ...s, completedResources: next };
    });
  }, []);

  const saveCollegeCohort = useCallback((records: CollegeStudentRecord[]) => {
    setState((s) => ({ ...s, collegeCohort: records }));
  }, []);

  const resetCollegeCohort = useCallback(() => {
    setState((s) => ({ ...s, collegeCohort: INITIAL_DEMO_COHORT }));
  }, []);

  const setStrictTabSwitch = useCallback((enabled: boolean) => {
    setState((s) => ({
      ...s,
      settings: {
        notifications: s.settings?.notifications ?? { weeklyDigest: true, roadmapReminders: true, opportunityAlerts: true },
        privacy: s.settings?.privacy ?? { visibility: "public", recruiterMessages: true, shareBenchmarks: true },
        assessmentPolicy: { strictTabSwitch: enabled },
      },
    }));
  }, []);

  const career = careerById(state.careerId);
  const { rows, readiness, counts } = useMemo(
    () => (career ? analyze(career.required, skills) : { rows: [] as SkillResult[], readiness: null, counts: { high: 0, medium: 0, low: 0, met: 0 } as Record<Severity, number> }),
    [career, skills],
  );
  const roadmap = useMemo(() => generateRoadmap(rows, career, state.position.weeklyHours), [rows, career, state.position.weeklyHours]);

  const taskStats = useMemo(() => {
    const all = roadmap.phases.flatMap((p) => p.tasks);
    const done = all.filter((t) => state.completedTasks[t.id]).length;
    return { done, total: all.length, pct: all.length ? Math.round((done / all.length) * 100) : 0 };
  }, [roadmap, state.completedTasks]);

  const nextTask = useMemo(() => {
    for (const p of roadmap.phases) for (const t of p.tasks) if (!state.completedTasks[t.id]) return { id: t.id, title: t.title, phase: p.title };
    return null;
  }, [roadmap, state.completedTasks]);

  const toggleTask = useCallback((id: string) => {
    setState((s) => {
      const next = { ...s.completedTasks };
      if (next[id]) delete next[id]; else next[id] = new Date().toISOString();
      return { ...s, completedTasks: next };
    });
  }, []);

  // Record a readiness snapshot whenever the estimate changes after onboarding.
  useEffect(() => {
    if (!state.onboarded || readiness === null) return;
    const last = state.history[state.history.length - 1];
    if (!last || last.readiness !== readiness) {
      setState((s) => ({ ...s, history: [...s.history, { t: new Date().toISOString(), readiness }].slice(-60) }));
    }
  }, [readiness, state.onboarded]); // eslint-disable-line react-hooks/exhaustive-deps

  const value: Ctx = {
    state,
    patch,
    reset,
    loadDemo,
    skills,
    assessment,
    career,
    rows,
    counts,
    readiness,
    roadmap,
    taskStats,
    toggleTask,
    nextTask,
    saveComprehensiveAssessment,
    toggleResourceBookmark,
    toggleResourceCompleted,
    saveCollegeCohort,
    resetCollegeCohort,
    setStrictTabSwitch,
  };
  return <StoreCtx.Provider value={value}>{children}</StoreCtx.Provider>;
}

export function useStore() {
  const c = useContext(StoreCtx) as Ctx | null;
  if (!c) throw new Error("useStore must be used inside StoreProvider");
  return c;
}
export { CAREERS };
