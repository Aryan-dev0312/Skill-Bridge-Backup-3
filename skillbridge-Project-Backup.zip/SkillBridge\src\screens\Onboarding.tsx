import { useState } from "react";
import BrandLogo from "../components/BrandLogo";
import { CAREERS, QUESTIONS, SKILL_CATEGORIES, careerById } from "../lib/catalog";
import { analyze } from "../lib/skillGap";
import { LEVELS, useStore, levelLabel } from "../lib/store";

const STEPS = ["Account", "Academic", "Position", "Skills", "Diagnostic", "Career goal", "Profile", "Dashboard"];
const inputCls = "w-full text-sm border border-slate-200 rounded-xl px-3 py-2.5 bg-white text-slate-800 outline-none focus:ring-2 focus:ring-indigo-300";
const labelCls = "text-xs font-medium text-slate-600 block mb-1";
const emailOk = (e: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);

function Field({ label, error, children }: { label: string; error?: string; children: React.ReactNode }) {
  return (
    <div>
      <label className={labelCls}>{label}</label>
      {children}
      {error && <p className="text-[11px] text-rose-600 mt-1">{error}</p>}
    </div>
  );
}

function Choice({ options, value, onChange }: { options: string[]; value: string; onChange: (v: string) => void }) {
  return (
    <div className="flex flex-wrap gap-2">
      {options.map((o) => (
        <button key={o} type="button" onClick={() => onChange(o)}
          className={`text-xs px-3 py-2 rounded-lg font-medium transition-all ${value === o ? "bg-indigo-600 text-white" : "bg-white border border-slate-200 text-slate-600 hover:border-indigo-300"}`}>
          {o}
        </button>
      ))}
    </div>
  );
}

export default function Onboarding() {
  const { state, patch, loadDemo, skills, assessment, rows, readiness } = useStore();
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [mode, setMode] = useState<"signup" | "login">("signup");
  const [name, setName] = useState(state.account?.name ?? "");
  const [email, setEmail] = useState(state.account?.email ?? "");
  const step = state.step;

  const go = (n: number) => patch((s) => ({ step: n, maxStep: Math.max(s.maxStep, n) }));
  const back = () => { setErrors({}); go(Math.max(1, step - 1)); };

  function validate(): Record<string, string> {
    const e: Record<string, string> = {};
    const { academic: a, position: p } = state;
    if (step === 1) {
      if (mode === "signup" && name.trim().length < 2) e.name = "Enter your name (at least 2 characters).";
      if (!emailOk(email.trim())) e.email = "Enter a valid email address.";
      if (mode === "login" && state.account && state.account.email.toLowerCase() !== email.trim().toLowerCase()) e.email = "No account with this email exists in this browser.";
      if (mode === "login" && !state.account) e.email = "No account exists in this browser yet. Choose Sign up.";
    }
    if (step === 2) {
      if (!a.college.trim()) e.college = "Enter your college or university.";
      if (!a.degree.trim()) e.degree = "Enter your degree and branch.";
      if (!a.year) e.year = "Select your current year.";
      const gy = Number(a.gradYear);
      if (!a.gradYear || !Number.isInteger(gy) || gy < 2024 || gy > 2035) e.gradYear = "Enter a graduation year between 2024 and 2035.";
      if (a.cgpa && (isNaN(Number(a.cgpa)) || Number(a.cgpa) < 0 || Number(a.cgpa) > 10)) e.cgpa = "CGPA must be a number from 0 to 10 (or leave blank).";
    }
    if (step === 3) {
      if (!p.stage) e.stage = "Select where you are right now.";
      if (!p.experience) e.experience = "Select your hands-on experience.";
      if (!Number.isFinite(p.weeklyHours) || p.weeklyHours < 1 || p.weeklyHours > 40) e.weeklyHours = "Enter between 1 and 40 hours per week.";
    }
    if (step === 4 && Object.keys(state.selected).length < 3) e.skills = "Select at least 3 skills you already use.";
    if (step === 5 && !assessment) e.answers = `Answer all ${QUESTIONS.length} questions to continue.`;
    if (step === 6 && !state.careerId) e.career = "Choose a career goal.";
    if (step === 7 && !state.profileGenerated) e.profile = "Generate your profile to continue.";
    return e;
  }

  function next() {
    const e = validate();
    setErrors(e);
    if (Object.keys(e).length) return;
    if (step === 1 && mode === "login" && state.profileGenerated && state.careerId) { patch({ onboarded: true }); return; }
    if (step === 1) patch({ account: { name: name.trim() || state.account?.name || "Student", email: email.trim() } });
    if (step < 8) { go(step + 1); return; }
    patch((s) => ({
      onboarded: true,
      initialLevels: Object.keys(s.initialLevels).length ? s.initialLevels : Object.fromEntries(Object.entries(skills).map(([k, v]) => [k, v.level])),
    }));
  }

  const setAcademic = (k: keyof typeof state.academic, v: string) => patch((s) => ({ academic: { ...s.academic, [k]: v } }));
  const setPosition = <K extends keyof typeof state.position>(k: K, v: (typeof state.position)[K]) => patch((s) => ({ position: { ...s.position, [k]: v } }));
  const toggleSkill = (n: string) => patch((s) => {
    const sel = { ...s.selected };
    if (sel[n] !== undefined) delete sel[n]; else sel[n] = LEVELS.Beginner;
    return { selected: sel };
  });

  const career = careerById(state.careerId);
  const fitOf = (id: string) => { const c = careerById(id)!; return analyze(c.required, skills).readiness ?? 0; };

  return (
    <div className="min-h-full bg-slate-100 overflow-y-auto">
      <div className="max-w-3xl mx-auto p-5">
        {/* Brand */}
        <div className="flex items-center gap-2.5 mb-5">
          <BrandLogo size="sm" showText={true} />
          {state.demo && <span className="ml-auto text-[10px] bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full font-medium">DEMO DATA</span>}
        </div>

        {/* Progress indicator */}
        <div className="bg-white rounded-2xl border border-slate-200 p-4 mb-4">
          <div className="flex justify-between mb-2">
            <span className="text-sm font-medium text-slate-700">Step {step} of {STEPS.length}: {STEPS[step - 1]}</span>
            <span className="text-sm font-mono font-semibold text-indigo-600">{Math.round(((step - 1) / (STEPS.length - 1)) * 100)}%</span>
          </div>
          <div className="h-2 rounded-full bg-slate-100 overflow-hidden mb-3">
            <div className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-violet-500 transition-all duration-300" style={{ width: `${((step - 1) / (STEPS.length - 1)) * 100}%` }} />
          </div>
          <div className="flex gap-1 flex-wrap">
            {STEPS.map((s, i) => {
              const n = i + 1;
              const reachable = n <= state.maxStep;
              return (
                <button key={s} disabled={!reachable} onClick={() => { setErrors({}); go(n); }}
                  className={`text-[10px] px-2 py-1 rounded-full font-medium ${n === step ? "bg-indigo-100 text-indigo-700" : reachable ? "bg-emerald-50 text-emerald-700 hover:bg-emerald-100" : "bg-slate-100 text-slate-400 cursor-not-allowed"}`}>
                  {reachable && n < step ? "✓ " : `${n}. `}{s}
                </button>
              );
            })}
          </div>
        </div>

        {/* Step body */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6">
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <h1 className="text-xl font-semibold text-slate-800">Welcome to SkillBridge</h1>
                <p className="text-sm text-slate-500 mt-0.5">Compare your skills with a target role, then follow a personalised roadmap.</p>
              </div>
              <div className="flex gap-1 bg-slate-100 rounded-xl p-1 w-fit">
                {(["signup", "login"] as const).map((m) => (
                  <button key={m} onClick={() => { setMode(m); setErrors({}); }}
                    className={`text-sm px-4 py-2 rounded-lg font-medium ${mode === m ? "bg-white text-slate-800 shadow-sm" : "text-slate-500"}`}>
                    {m === "signup" ? "Sign up" : "Log in"}
                  </button>
                ))}
              </div>
              {mode === "signup" && (
                <Field label="Full name *" error={errors.name}>
                  <input className={inputCls} value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" />
                </Field>
              )}
              <Field label="Email *" error={errors.email}>
                <input className={inputCls} type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@college.edu" />
              </Field>
              <p className="text-[11px] text-slate-500 bg-slate-50 border border-slate-100 rounded-xl p-3">
                Prototype mode: your account and progress are stored only in this browser. There is no password yet; real authentication arrives with the backend.
              </p>
              <button onClick={loadDemo} className="text-xs text-indigo-600 hover:underline font-medium">Or explore with a clearly labelled demo profile →</button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <div><h1 className="text-xl font-semibold text-slate-800">Academic profile</h1><p className="text-sm text-slate-500 mt-0.5">Used on your dashboard and recruiter-facing profile.</p></div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Field label="College / University *" error={errors.college}><input className={inputCls} value={state.academic.college} onChange={(e) => setAcademic("college", e.target.value)} /></Field>
                <Field label="Degree & branch *" error={errors.degree}><input className={inputCls} placeholder="B.Tech Computer Science" value={state.academic.degree} onChange={(e) => setAcademic("degree", e.target.value)} /></Field>
                <Field label="Current year *" error={errors.year}>
                  <select className={inputCls} value={state.academic.year} onChange={(e) => setAcademic("year", e.target.value)}>
                    <option value="">Select…</option>{["1st", "2nd", "3rd", "4th", "Postgraduate"].map((y) => <option key={y}>{y}</option>)}
                  </select>
                </Field>
                <Field label="Graduation year *" error={errors.gradYear}><input className={inputCls} inputMode="numeric" placeholder="2027" value={state.academic.gradYear} onChange={(e) => setAcademic("gradYear", e.target.value)} /></Field>
                <Field label="CGPA (optional, 0–10)" error={errors.cgpa}><input className={inputCls} inputMode="decimal" value={state.academic.cgpa} onChange={(e) => setAcademic("cgpa", e.target.value)} /></Field>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-5">
              <div><h1 className="text-xl font-semibold text-slate-800">Current technical position</h1><p className="text-sm text-slate-500 mt-0.5">Tells us how much time you have and where you are starting from.</p></div>
              <Field label="Where are you right now? *" error={errors.stage}>
                <Choice value={state.position.stage} onChange={(v) => setPosition("stage", v)} options={["Just starting out", "Learning on my own", "Building projects", "Had an internship"]} />
              </Field>
              <Field label="Hands-on coding experience *" error={errors.experience}>
                <Choice value={state.position.experience} onChange={(v) => setPosition("experience", v)} options={["Under 6 months", "6-12 months", "1-2 years", "2+ years"]} />
              </Field>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Field label="Hours per week you can study *" error={errors.weeklyHours}>
                  <input className={inputCls} type="number" min={1} max={40} value={state.position.weeklyHours} onChange={(e) => setPosition("weeklyHours", Number(e.target.value))} />
                </Field>
                <Field label="Current focus (optional)"><input className={inputCls} placeholder="e.g. web development" value={state.position.focus} onChange={(e) => setPosition("focus", e.target.value)} /></Field>
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="space-y-4">
              <div><h1 className="text-xl font-semibold text-slate-800">Select your skills</h1><p className="text-sm text-slate-500 mt-0.5">Choose at least 3, then rate yourself honestly. These are self-reported until assessed.</p></div>
              {SKILL_CATEGORIES.map((c) => (
                <div key={c.category}>
                  <p className="text-xs font-semibold text-slate-600 mb-2">{c.category}</p>
                  <div className="flex flex-wrap gap-2">
                    {c.skills.map((s) => (
                      <button key={s} onClick={() => toggleSkill(s)}
                        className={`text-xs px-3 py-1.5 rounded-lg font-medium transition-all ${state.selected[s] !== undefined ? "bg-indigo-600 text-white" : "bg-white border border-slate-200 text-slate-600 hover:border-indigo-300"}`}>
                        {s}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
              {errors.skills && <p className="text-[11px] text-rose-600">{errors.skills}</p>}
              {Object.keys(state.selected).length > 0 && (
                <div className="border-t border-slate-100 pt-4 space-y-2">
                  <p className="text-xs font-semibold text-slate-700">Rate each skill ({Object.keys(state.selected).length} selected)</p>
                  {Object.entries(state.selected).map(([n, lvl]) => (
                    <div key={n} className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl flex-wrap">
                      <span className="text-sm font-medium text-slate-800 w-40">{n}</span>
                      <div className="flex gap-1.5">
                        {(Object.entries(LEVELS) as [string, number][]).map(([label, val]) => (
                          <button key={label} onClick={() => patch((s) => ({ selected: { ...s.selected, [n]: val } }))}
                            className={`text-[11px] px-2.5 py-1 rounded-full font-medium ${levelLabel(lvl) === label ? "bg-indigo-100 text-indigo-700" : "bg-white border border-slate-200 text-slate-500"}`}>
                            {label}
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {step === 5 && (
            <div className="space-y-5">
              <div><h1 className="text-xl font-semibold text-slate-800">Diagnostic assessment</h1><p className="text-sm text-slate-500 mt-0.5">Five quick questions. Correct answers mark that skill as <strong>assessed</strong>; this is a short check, not a certification.</p></div>
              {QUESTIONS.map((q, i) => (
                <div key={q.id} className="p-4 border border-slate-100 rounded-xl">
                  <p className="text-sm font-medium text-slate-800 mb-3">{i + 1}. {q.prompt} <span className="text-[10px] bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-full ml-1">{q.skill}</span></p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {q.options.map((o, oi) => (
                      <button key={o} onClick={() => patch((s) => ({ answers: { ...s.answers, [q.id]: oi } }))}
                        className={`text-left text-sm px-3 py-2 rounded-xl border transition-all ${state.answers[q.id] === oi ? "border-indigo-400 bg-indigo-50 text-indigo-800 ring-2 ring-indigo-100" : "border-slate-200 text-slate-700 hover:border-indigo-300"}`}>
                        {o}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
              {errors.answers && <p className="text-[11px] text-rose-600">{errors.answers}</p>}
            </div>
          )}

          {step === 6 && (
            <div className="space-y-4">
              <div><h1 className="text-xl font-semibold text-slate-800">Choose your career goal</h1><p className="text-sm text-slate-500 mt-0.5">“Current fit” is an estimate from your skill ratings vs SkillBridge's expected proficiency for the role.</p></div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {CAREERS.map((c) => (
                  <button key={c.id} onClick={() => patch({ careerId: c.id })}
                    className={`text-left p-4 rounded-2xl border transition-all ${state.careerId === c.id ? "border-indigo-400 ring-2 ring-indigo-100 bg-indigo-50/40" : "border-slate-200 hover:border-indigo-300"}`}>
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <p className="text-sm font-semibold text-slate-800">{c.title}</p>
                      <span className="text-xs font-mono font-semibold text-indigo-600">{fitOf(c.id)}%</span>
                    </div>
                    <p className="text-[10px] text-indigo-700 bg-indigo-50 inline-block px-2 py-0.5 rounded-full mb-2">{c.domain}</p>
                    <p className="text-xs text-slate-500 leading-relaxed">{c.description}</p>
                  </button>
                ))}
              </div>
              {errors.career && <p className="text-[11px] text-rose-600">{errors.career}</p>}
            </div>
          )}

          {step === 7 && (
            <div className="space-y-4">
              <div><h1 className="text-xl font-semibold text-slate-800">Generate your profile</h1><p className="text-sm text-slate-500 mt-0.5">Review what SkillBridge will use. Use the step buttons above to edit any answer.</p></div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="bg-slate-50 rounded-xl p-4"><p className="text-xs text-slate-500">Student</p><p className="text-sm font-semibold text-slate-800">{state.account?.name}</p><p className="text-[11px] text-slate-500">{state.academic.degree} · {state.academic.year} year · {state.academic.college}</p></div>
                <div className="bg-slate-50 rounded-xl p-4"><p className="text-xs text-slate-500">Target career</p><p className="text-sm font-semibold text-slate-800">{career?.title}</p><p className="text-[11px] text-slate-500">{state.position.weeklyHours} h/week available</p></div>
                <div className="bg-slate-50 rounded-xl p-4"><p className="text-xs text-slate-500">Diagnostic</p><p className="text-sm font-semibold text-slate-800">{assessment?.score}/{assessment?.total} correct</p><p className="text-[11px] text-slate-500">{Object.keys(skills).length} skills tracked</p></div>
              </div>
              {state.profileGenerated && (
                <div className="p-4 border border-emerald-200 bg-emerald-50 rounded-2xl">
                  <p className="text-sm font-semibold text-emerald-800">Profile generated</p>
                  <p className="text-xs text-emerald-700 mt-1">Estimated readiness for {career?.title}: <strong>{readiness ?? 0}%</strong> (an estimate, not a hiring probability). Top gaps: {rows.filter((r) => r.gap > 0).slice(0, 3).map((r) => r.name).join(", ") || "none"}.</p>
                </div>
              )}
              {errors.profile && <p className="text-[11px] text-rose-600">{errors.profile}</p>}
              {!state.profileGenerated && <button onClick={() => patch({ profileGenerated: true })} className="bg-indigo-600 text-white text-sm px-4 py-2.5 rounded-xl font-medium hover:bg-indigo-700">Generate my profile</button>}
            </div>
          )}

          {step === 8 && (
            <div className="text-center py-6">
              <div className="w-12 h-12 mx-auto rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center text-xl mb-3">✓</div>
              <h1 className="text-xl font-semibold text-slate-800">Your personalised dashboard is ready</h1>
              <p className="text-sm text-slate-500 mt-1 max-w-md mx-auto">Your skill gaps and roadmap were generated from your answers. Your progress is saved in this browser and survives a refresh.</p>
            </div>
          )}
        </div>

        {/* Back / Next */}
        <div className="flex justify-between mt-4">
          <button onClick={back} disabled={step === 1} className="text-sm px-4 py-2.5 border border-slate-200 bg-white rounded-xl text-slate-600 hover:bg-slate-50 disabled:opacity-40">Back</button>
          <button onClick={next} className="text-sm px-5 py-2.5 bg-indigo-600 text-white rounded-xl font-medium hover:bg-indigo-700">
            {step === 8 ? "Open dashboard" : step === 1 && mode === "login" ? "Log in" : "Next"}
          </button>
        </div>
      </div>
    </div>
  );
}
