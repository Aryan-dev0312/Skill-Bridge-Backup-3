import { useState } from "react";
import {
  IN_DEMAND_SKILLS,
  IN_DEMAND_META,
  PLACEMENT_CORRELATIONS,
  PLACEMENT_CORRELATION_META,
  SKILL_COMBINATIONS,
  SKILL_COMBINATIONS_META,
  ROLE_REQUIREMENTS,
  ROLE_REQUIREMENTS_META,
  MOST_MISSING_SKILLS,
  MISSING_SKILLS_META,
  type MetricMetadata,
} from "../lib/insightsData";
import { useStore } from "../lib/store";

interface EmployabilityInsightsProps {
  onNavigate?: (screen: string) => void;
}

export default function EmployabilityInsights({ onNavigate }: EmployabilityInsightsProps) {
  const { state, skills, career } = useStore();
  const [selectedRoleIndex, setSelectedRoleIndex] = useState(0);
  const [activeSection, setActiveSection] = useState<"demand" | "placement" | "bundles" | "roles" | "gaps">("demand");

  const currentRole = ROLE_REQUIREMENTS[selectedRoleIndex];

  return (
    <div className="p-4 sm:p-6 max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2 mb-1 flex-wrap">
            <span className="text-xs font-semibold bg-blue-50 text-blue-700 px-2.5 py-0.5 rounded-full border border-blue-200 font-mono">
              Employment Analytics & Market Intelligence
            </span>
            <span className="text-[11px] font-semibold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200">
              DEMO DATA BENCHMARKS INCLUDED
            </span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            Skills & Employment Insights
          </h1>
          <p className="text-xs text-slate-500 mt-1 max-w-3xl">
            Empirical labor market demand, campus hiring correlations, and curriculum gap analysis. All statistics include explicit sources, reporting periods, sample sizes, and definitions.
          </p>
        </div>

        {onNavigate && (
          <button
            onClick={() => onNavigate("resources")}
            className="self-start sm:self-auto text-xs text-indigo-600 hover:text-indigo-800 font-semibold border border-indigo-200 px-3.5 py-2 rounded-xl bg-indigo-50/50 hover:bg-indigo-50 transition-colors"
          >
            Explore Learning Resources →
          </button>
        )}
      </div>

      {/* Transparent Data Standards Banner */}
      <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-2">
        <div className="flex items-center gap-2 text-xs font-bold text-slate-800 uppercase tracking-wider">
          <span>🔍</span>
          <span>Transparency & Source Integrity Standards</span>
        </div>
        <p className="text-xs text-slate-600 leading-relaxed">
          SkillBridge does not extrapolate, fabricate, or guarantee placement outcomes. Every insight displays its underlying dataset origin, survey bounds, and sample size ($N$). Data sources are segmented into:
        </p>
        <div className="flex flex-wrap gap-2 pt-1 text-[11px]">
          <span className="px-2.5 py-1 rounded-lg font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
            [OFFICIAL PLACEMENT DATA]
          </span>
          <span className="px-2.5 py-1 rounded-lg font-semibold bg-blue-50 text-blue-800 border border-blue-200">
            [PUBLIC INDUSTRY REPORT]
          </span>
          <span className="px-2.5 py-1 rounded-lg font-semibold bg-purple-50 text-purple-800 border border-purple-200">
            [ASSESSED BENCHMARK]
          </span>
          <span className="px-2.5 py-1 rounded-lg font-semibold bg-slate-100 text-slate-800 border border-slate-200">
            [SELF-REPORTED]
          </span>
          <span className="px-2.5 py-1 rounded-lg font-semibold bg-amber-50 text-amber-800 border border-amber-200">
            [DEMO DATA COHORT]
          </span>
        </div>
      </div>

      {/* Section Navigation Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs scrollbar-hide">
        {[
          { id: "demand", label: "Job Description Demand" },
          { id: "placement", label: "Placement Correlations" },
          { id: "bundles", label: "Winning Skill Bundles" },
          { id: "roles", label: "Role Requirements vs You" },
          { id: "gaps", label: "Most Common Gaps" },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveSection(tab.id as any)}
            className={`px-3.5 py-2 rounded-xl font-semibold shrink-0 transition-all ${
              activeSection === tab.id
                ? "bg-slate-900 text-white shadow-xs"
                : "bg-white border border-slate-200 text-slate-600 hover:bg-slate-50"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* SECTION 1: IN-DEMAND SKILLS IN JOB DESCRIPTIONS */}
      {activeSection === "demand" && (
        <div className="space-y-4">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  Skills Most Frequently Requested in Job Descriptions
                </h2>
                <p className="text-xs text-slate-500">
                  Percentage of software, cloud, and data engineering postings mandating each competency.
                </p>
              </div>
              <SourceBadge category={IN_DEMAND_META.category} />
            </div>

            {/* Bar Chart Visualization */}
            <div className="space-y-3 pt-2">
              {IN_DEMAND_SKILLS.map((item) => {
                const userSkillObj = skills[item.skill];
                const userLevel = userSkillObj ? userSkillObj.level : 0;
                const isUserMet = userLevel >= 60;

                return (
                  <div key={item.skill} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-slate-800">{item.skill}</span>
                        <span className="text-[10px] text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded">
                          {item.category}
                        </span>
                        {isUserMet && (
                          <span className="text-[10px] text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded font-medium">
                            ✓ Your profile ready ({userLevel}%)
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 font-mono text-xs">
                        <span className="text-emerald-600 font-bold">{item.growthRate}</span>
                        <span className="font-bold text-slate-800">{item.demandPercentage}%</span>
                      </div>
                    </div>

                    <div className="h-2.5 rounded-full bg-slate-100 overflow-hidden flex">
                      <div
                        className="h-full bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full transition-all"
                        style={{ width: `${item.demandPercentage}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Metadata Footer */}
            <MetadataCard meta={IN_DEMAND_META} />
          </div>
        </div>
      )}

      {/* SECTION 2: PLACEMENT CORRELATIONS */}
      {activeSection === "placement" && (
        <div className="space-y-4">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  Skills Strongly Correlated with Campus Placement Clearance
                </h2>
                <p className="text-xs text-slate-500">
                  Placement success rate among students demonstrating benchmark proficiency (≥ 70%) vs 64% campus average.
                </p>
              </div>
              <SourceBadge category={PLACEMENT_CORRELATION_META.category} />
            </div>

            {/* Comparison Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {PLACEMENT_CORRELATIONS.map((c) => {
                const uplift = c.placementRateProficient - c.placementRateBaseline;
                return (
                  <div
                    key={c.skill}
                    className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <h3 className="font-bold text-sm text-slate-900">{c.skill}</h3>
                      <span className="text-xs font-mono font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                        +{uplift}% Placement Rate Uplift
                      </span>
                    </div>

                    {/* Dual comparison bars */}
                    <div className="space-y-2 text-xs">
                      <div>
                        <div className="flex justify-between text-[11px] mb-1">
                          <span className="text-slate-600 font-medium">Proficient Candidates (≥70%)</span>
                          <span className="font-mono font-bold text-indigo-700">{c.placementRateProficient}%</span>
                        </div>
                        <div className="h-2 rounded-full bg-slate-200 overflow-hidden">
                          <div
                            className="h-full bg-indigo-600 rounded-full"
                            style={{ width: `${c.placementRateProficient}%` }}
                          />
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between text-[11px] mb-1">
                          <span className="text-slate-500">Campus Cohort Baseline</span>
                          <span className="font-mono text-slate-500">{c.placementRateBaseline}%</span>
                        </div>
                        <div className="h-2 rounded-full bg-slate-200 overflow-hidden">
                          <div
                            className="h-full bg-slate-400 rounded-full"
                            style={{ width: `${c.placementRateBaseline}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <MetadataCard meta={PLACEMENT_CORRELATION_META} />
          </div>
        </div>
      )}

      {/* SECTION 3: WINNING SKILL BUNDLES */}
      {activeSection === "bundles" && (
        <div className="space-y-4">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  Most Frequent Skill Combinations Among Placed Students
                </h2>
                <p className="text-xs text-slate-500">
                  Multi-disciplinary clusters identified in candidate profiles that secured campus offers.
                </p>
              </div>
              <SourceBadge category={SKILL_COMBINATIONS_META.category} />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {SKILL_COMBINATIONS.map((bundle, idx) => (
                <div
                  key={idx}
                  className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">
                        {bundle.roleMatch}
                      </span>
                    </div>
                    <div className="text-right">
                      <span className="text-xs font-mono font-bold text-slate-900">
                        {bundle.avgPackageLPA} LPA
                      </span>
                      <span className="text-[10px] text-slate-400 block">Mean Starting CTC</span>
                    </div>
                  </div>

                  {/* Skills in bundle */}
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {bundle.combination.map((skill) => (
                      <span
                        key={skill}
                        className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-slate-100 text-slate-800"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>

                  {/* Frequency meter */}
                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                    <span className="text-slate-500 text-[11px]">Placed Profile Prevalence:</span>
                    <span className="font-mono font-bold text-slate-800">{bundle.frequency}% of offers</span>
                  </div>
                </div>
              ))}
            </div>

            <MetadataCard meta={SKILL_COMBINATIONS_META} />
          </div>
        </div>
      )}

      {/* SECTION 4: ROLE REQUIREMENTS VS STUDENT */}
      {activeSection === "roles" && (
        <div className="space-y-4">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  Role-Wise Skill Requirements vs Your Assessed Level
                </h2>
                <p className="text-xs text-slate-500">
                  Target proficiency thresholds required across premier engineering roles.
                </p>
              </div>
              <SourceBadge category={ROLE_REQUIREMENTS_META.category} />
            </div>

            {/* Role selector tabs */}
            <div className="flex gap-2 overflow-x-auto pb-1">
              {ROLE_REQUIREMENTS.map((r, i) => (
                <button
                  key={r.role}
                  onClick={() => setSelectedRoleIndex(i)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                    selectedRoleIndex === i
                      ? "bg-indigo-600 text-white shadow-xs"
                      : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                  }`}
                >
                  {r.role}
                </button>
              ))}
            </div>

            {/* Current Role Skill Gap Breakdown */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-sm text-slate-900">{currentRole.role}</h3>
                <span className="text-xs text-slate-500">
                  Represents {currentRole.hiringPrevalence}% of college recruitment volume
                </span>
              </div>

              <div className="space-y-3">
                {currentRole.primarySkills.map((ps) => {
                  const userSkill = skills[ps.name];
                  const userLevel = userSkill ? userSkill.level : 0;
                  const gap = Math.max(0, ps.target - userLevel);

                  return (
                    <div key={ps.name} className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-semibold text-slate-800">{ps.name}</span>
                        <div className="flex items-center gap-3 font-mono text-[11px]">
                          <span className="text-slate-500">Your Level: {userLevel}%</span>
                          <span className="text-indigo-700 font-bold">Target: {ps.target}%</span>
                          {gap > 0 ? (
                            <span className="text-rose-600 font-bold">(-{gap}% gap)</span>
                          ) : (
                            <span className="text-emerald-600 font-bold">✓ Target Met</span>
                          )}
                        </div>
                      </div>

                      <div className="h-2 rounded-full bg-slate-200 overflow-hidden flex">
                        <div
                          className={`h-full rounded-full transition-all ${
                            userLevel >= ps.target ? "bg-emerald-500" : "bg-indigo-600"
                          }`}
                          style={{ width: `${Math.min(100, userLevel)}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Emerging bonus skills */}
              <div className="pt-3 border-t border-slate-200">
                <span className="text-[11px] font-bold text-slate-600 block mb-1.5 uppercase tracking-wider">
                  Differentiating Emerging Competencies:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {currentRole.emergingSkills.map((es) => (
                    <span
                      key={es}
                      className="px-2.5 py-0.5 rounded-md text-[11px] font-semibold bg-white border border-slate-200 text-slate-700"
                    >
                      + {es}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <MetadataCard meta={ROLE_REQUIREMENTS_META} />
          </div>
        </div>
      )}

      {/* SECTION 5: MOST COMMONLY MISSING SKILLS */}
      {activeSection === "gaps" && (
        <div className="space-y-4">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  Most Commonly Missing Skills Across Student Cohorts
                </h2>
                <p className="text-xs text-slate-500">
                  Diagnostic evaluation of systematic curriculum blind spots in undergraduate engineering syllabi.
                </p>
              </div>
              <SourceBadge category={MISSING_SKILLS_META.category} />
            </div>

            <div className="space-y-3 pt-2">
              {MOST_MISSING_SKILLS.map((gap) => (
                <div
                  key={gap.skill}
                  className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-sm text-slate-900">{gap.skill}</h3>
                    <span className="text-xs font-mono font-bold text-rose-600 bg-rose-50 px-2 py-0.5 rounded-full border border-rose-200">
                      {gap.gapPercentage}% of candidates show deficit
                    </span>
                  </div>

                  <div className="h-2 rounded-full bg-slate-200 overflow-hidden">
                    <div
                      className="h-full bg-rose-500 rounded-full"
                      style={{ width: `${gap.gapPercentage}%` }}
                    />
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed pt-1">
                    <strong>Curriculum Root Cause:</strong> {gap.curriculumGapReason}
                  </p>
                </div>
              ))}
            </div>

            <MetadataCard meta={MISSING_SKILLS_META} />
          </div>
        </div>
      )}
    </div>
  );
}

function SourceBadge({ category }: { category: MetricMetadata["category"] }) {
  const styles: Record<MetricMetadata["category"], string> = {
    "Official College Placement": "bg-emerald-50 text-emerald-800 border-emerald-300",
    "Public Industry Survey": "bg-blue-50 text-blue-800 border-blue-300",
    "Assessed Benchmark": "bg-purple-50 text-purple-800 border-purple-300",
    "Self-Reported": "bg-slate-100 text-slate-800 border-slate-300",
    "Demo Cohort": "bg-amber-50 text-amber-800 border-amber-300",
  };

  return (
    <span
      className={`text-[10px] font-bold px-2.5 py-1 rounded-full border uppercase tracking-wide font-mono ${styles[category]}`}
    >
      [{category}]
    </span>
  );
}

function MetadataCard({ meta }: { meta: MetricMetadata }) {
  return (
    <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-1.5">
      <div className="flex items-center gap-1.5 font-bold text-slate-800 text-[11px] uppercase tracking-wider">
        <span>📋</span>
        <span>Statistical Source Disclosure</span>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 text-[11px] text-slate-600">
        <div>
          <span className="text-slate-400 block">Data Source:</span>
          <span className="font-semibold text-slate-700">{meta.dataSource}</span>
        </div>
        <div>
          <span className="text-slate-400 block">Reporting Period:</span>
          <span className="font-semibold text-slate-700">{meta.reportingPeriod}</span>
        </div>
        <div>
          <span className="text-slate-400 block">Sample Size:</span>
          <span className="font-semibold text-slate-700">{meta.sampleSize}</span>
        </div>
        <div>
          <span className="text-slate-400 block">Last Updated:</span>
          <span className="font-semibold text-slate-700">{meta.lastUpdated}</span>
        </div>
      </div>
      <p className="text-[11px] text-slate-500 italic pt-1 border-t border-slate-200/80">
        {meta.explanation}
      </p>
    </div>
  );
}
