import { useState } from "react";
import { COMPANIES, careerById } from "../lib/catalog";
import { useStore } from "../lib/store";
import CompanyLogo from "../components/CompanyLogo";

export default function Companies() {
  const { state } = useStore();
  const [selected, setSelected] = useState<string>(COMPANIES[0].id);
  const [query, setQuery] = useState("");
  const list = COMPANIES.filter((c) => (c.name + c.domains.join(" ") + c.technologies.join(" ")).toLowerCase().includes(query.toLowerCase()));
  const sel = COMPANIES.find((c) => c.id === selected);

  return (
    <div className="p-5 max-w-6xl mx-auto">
      <div className="mb-6">
        <h1 className="text-xl font-semibold text-slate-800">Company Directory</h1>
        <p className="text-sm text-slate-500 mt-0.5">General public information to help you explore. Technologies and roles shown are associations, not hiring requirements, and SkillBridge has no partnership with these companies.</p>
      </div>

      <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search by company, domain or technology…"
        className="w-full max-w-sm text-sm border border-slate-200 rounded-xl px-3 py-2 bg-white text-slate-800 outline-none focus:ring-2 focus:ring-indigo-300 mb-4" />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-1 space-y-2">
          {list.map((c) => (
            <button key={c.id} onClick={() => setSelected(c.id)}
              className={`w-full flex items-center gap-3 text-left bg-white rounded-2xl border p-3 transition-all ${selected === c.id ? "border-indigo-400 ring-2 ring-indigo-100" : "border-slate-200 hover:border-indigo-200"}`}>
              <CompanyLogo id={c.id} name={c.name} size="sm" />
              <div className="min-w-0">
                <p className="text-sm font-medium text-slate-800">{c.name}</p>
                <p className="text-[11px] text-slate-500 truncate">{c.domains.join(" · ")}</p>
              </div>
              {c.careers.includes(state.careerId ?? "") && <span className="ml-auto text-[9px] bg-indigo-50 text-indigo-700 px-1.5 py-0.5 rounded-full shrink-0">Relevant to you</span>}
            </button>
          ))}
          {list.length === 0 && <p className="text-sm text-slate-500 p-3">No companies match “{query}”.</p>}
        </div>

        <div className="lg:col-span-2">
          {sel ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-5">
              <div className="flex items-center gap-3 mb-4 pb-4 border-b border-slate-100">
                <CompanyLogo id={sel.id} name={sel.name} size="lg" />
                <div><p className="text-base font-semibold text-slate-800">{sel.name}</p><p className="text-xs text-slate-500">Company overview</p></div>
              </div>
              <p className="text-sm text-slate-600 leading-relaxed mb-4">{sel.overview}</p>
              <p className="text-xs font-semibold text-slate-700 mb-2">Technology domains</p>
              <div className="flex flex-wrap gap-1.5 mb-4">{sel.domains.map((d) => <span key={d} className="text-[11px] bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-full">{d}</span>)}</div>
              <p className="text-xs font-semibold text-slate-700 mb-2">Related technologies</p>
              <div className="flex flex-wrap gap-1.5 mb-4">{sel.technologies.map((t) => <span key={t} className="text-[11px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full">{t}</span>)}</div>
              <p className="text-xs font-semibold text-slate-700 mb-2">Relevant role families on SkillBridge</p>
              <div className="flex flex-wrap gap-1.5 mb-5">
                {sel.careers.map((id) => <span key={id} className={`text-[11px] px-2 py-0.5 rounded-full ${id === state.careerId ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-600"}`}>{careerById(id)?.title}</span>)}
              </div>
              <a href={sel.careersUrl} target="_blank" rel="noopener noreferrer" className="inline-block bg-indigo-600 text-white text-sm px-4 py-2.5 rounded-xl font-medium hover:bg-indigo-700">
                Official careers page ↗
              </a>
              <p className="text-[11px] text-slate-400 mt-3">Check the company's own site for current openings and the actual requirements for each role.</p>
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}
