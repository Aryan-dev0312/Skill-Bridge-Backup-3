import { useState, useEffect } from "react";
import Dashboard from "./screens/Dashboard";
import Career from "./screens/Career";
import MySkills from "./screens/MySkills";
import SkillGap from "./screens/SkillGap";
import Roadmap from "./screens/Roadmap";
import Opportunities from "./screens/Opportunities";
import Projects from "./screens/Projects";
import Progress from "./screens/Progress";
import IndustryPortal from "./screens/IndustryPortal";
import Onboarding from "./screens/Onboarding";
import Companies from "./screens/Companies";
import Technologies from "./screens/Technologies";
import Trends from "./screens/Trends";
import ComprehensiveAssessment from "./screens/ComprehensiveAssessment";
import Instructions from "./screens/Instructions";
import Settings from "./screens/Settings";
import Help from "./screens/Help";
import LearnMore from "./screens/LearnMore";
import Resources from "./screens/Resources";
import EmployabilityInsights from "./screens/EmployabilityInsights";
import CollegePortal from "./screens/CollegePortal";
import SplashScreen from "./components/SplashScreen";
import ProfileMenu from "./components/ProfileMenu";
import SignOutModal from "./components/SignOutModal";
import BrandLogo from "./components/BrandLogo";
import { StoreProvider, useStore } from "./lib/store";
import { getStoredLanguage, t, type Language } from "./lib/i18n";

type Screen =
  | "overview"
  | "career"
  | "skills"
  | "gap"
  | "roadmap"
  | "resources"
  | "insights"
  | "college"
  | "opportunities"
  | "projects"
  | "progress"
  | "companies"
  | "technologies"
  | "trends"
  | "industry"
  | "assessment"
  | "instructions"
  | "settings"
  | "help"
  | "learnMore";

const NAV = [
  { id: "overview", labelKey: "overview", icon: GridIcon },
  { id: "career", labelKey: "career", icon: TargetIcon },
  { id: "skills", labelKey: "skills", icon: StarIcon },
  { id: "gap", labelKey: "gap", icon: ZapIcon },
  { id: "roadmap", labelKey: "roadmap", icon: MapIcon },
  { id: "resources", labelKey: "resources", icon: BookIcon },
  { id: "insights", labelKey: "insights", icon: SparklesIcon },
  { id: "opportunities", labelKey: "opportunities", icon: BriefcaseIcon },
  { id: "projects", labelKey: "projects", icon: FolderIcon },
  { id: "progress", labelKey: "progress", icon: ChartIcon },
  { id: "companies", labelKey: "companies", icon: BuildingIcon },
  { id: "technologies", labelKey: "technologies", icon: CpuIcon },
  { id: "trends", labelKey: "trends", icon: TrendIcon },
] as const;

export default function App() {
  return (
    <StoreProvider>
      <SplashScreen>
        <Shell />
      </SplashScreen>
    </StoreProvider>
  );
}

function Shell() {
  const { state, patch, reset } = useStore();
  const [screen, setScreen] = useState<Screen>("overview");
  const [mode, setMode] = useState<"student" | "college" | "industry">("student");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [signOutModalOpen, setSignOutModalOpen] = useState(false);
  const [lang, setLang] = useState<Language>(getStoredLanguage);

  useEffect(() => {
    const handleLangChange = () => {
      setLang(getStoredLanguage());
    };
    window.addEventListener("skillbridge:lang_change", handleLangChange);
    return () => window.removeEventListener("skillbridge:lang_change", handleLangChange);
  }, []);

  const handleSignOut = () => {
    patch({ onboarded: false, step: 1 });
    setScreen("overview");
  };

  const screens: Record<string, React.ReactNode> = {
    overview: <Dashboard onNavigate={(s) => setScreen(s as Screen)} />,
    career: <Career />,
    skills: <MySkills />,
    gap: <SkillGap onNavigate={(s) => setScreen(s as Screen)} />,
    roadmap: <Roadmap onNavigate={(s) => setScreen(s as Screen)} />,
    resources: <Resources onNavigate={(s) => setScreen(s as Screen)} />,
    insights: <EmployabilityInsights onNavigate={(s) => setScreen(s as Screen)} />,
    college: <CollegePortal />,
    opportunities: <Opportunities />,
    projects: <Projects />,
    progress: <Progress />,
    companies: <Companies />,
    technologies: <Technologies />,
    trends: <Trends />,
    industry: <IndustryPortal />,
    assessment: (
      <ComprehensiveAssessment
        onBackToDashboard={() => setScreen("overview")}
        onNavigate={(s) => setScreen(s as Screen)}
      />
    ),
    instructions: <Instructions onNavigate={(s) => setScreen(s as Screen)} />,
    settings: (
      <Settings
        onNavigate={(s) => setScreen(s as Screen)}
        onOpenSignOut={() => setSignOutModalOpen(true)}
      />
    ),
    help: <Help onNavigate={(s) => setScreen(s as Screen)} />,
    learnMore: <LearnMore onNavigate={(s) => setScreen(s as Screen)} />,
  };

  if (!state.onboarded) return <Onboarding />;

  const initials = (state.account?.name ?? "S").split(" ").map((w) => w[0]).slice(0, 2).join("").toUpperCase();

  return (
    <div className="flex h-full bg-slate-100 overflow-hidden">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-20 bg-slate-900/30 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-30 flex flex-col w-60 bg-white border-r border-slate-200 transition-transform duration-200 lg:relative lg:translate-x-0 ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        {/* Official Brand Logo */}
        <div className="flex items-center gap-2.5 px-4 h-14 border-b border-slate-200 shrink-0">
          <BrandLogo size="sm" showText={true} />
          <span className="ml-auto text-[10px] text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded font-mono">AI</span>
        </div>

        {/* 3-Way Mode toggle (Student | College | Industry) */}
        <div className="px-3 py-2.5 border-b border-slate-200 shrink-0">
          <div className="flex rounded-lg overflow-hidden bg-slate-100 p-0.5 text-xs">
            <button
              onClick={() => { setMode("student"); setScreen("overview"); }}
              className={`flex-1 py-1 rounded-md font-medium transition-all ${mode === "student" ? "bg-indigo-600 text-white shadow-xs" : "text-slate-500 hover:text-slate-800"}`}
            >
              {t("student", lang)}
            </button>
            <button
              onClick={() => { setMode("college"); setScreen("college"); }}
              className={`flex-1 py-1 rounded-md font-medium transition-all ${mode === "college" ? "bg-indigo-600 text-white shadow-xs" : "text-slate-500 hover:text-slate-800"}`}
            >
              {t("college", lang)}
            </button>
            <button
              onClick={() => { setMode("industry"); setScreen("industry"); }}
              className={`flex-1 py-1 rounded-md font-medium transition-all ${mode === "industry" ? "bg-indigo-600 text-white shadow-xs" : "text-slate-500 hover:text-slate-800"}`}
            >
              {t("industry", lang)}
            </button>
          </div>
        </div>

        {/* Nav items */}
        <nav className="flex-1 overflow-y-auto py-3 px-3 scrollbar-hide">
          {mode === "student" ? (
            <div className="space-y-0.5">
              <p className="text-[10px] text-slate-500 uppercase tracking-widest px-2 py-2 font-medium">
                {t("studentPortal", lang)}
              </p>
              {NAV.map(({ id, labelKey, icon: Icon }) => (
                <button
                  key={id}
                  onClick={() => { setScreen(id as Screen); setSidebarOpen(false); }}
                  className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                    screen === id
                      ? "bg-indigo-50 text-indigo-700 font-semibold"
                      : "text-slate-500 hover:text-slate-800 hover:bg-slate-50"
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{t(labelKey, lang)}</span>
                  {id === "gap" && <span className="ml-auto w-1.5 h-1.5 rounded-full bg-rose-400" />}
                </button>
              ))}
            </div>
          ) : mode === "college" ? (
            <div className="space-y-0.5">
              <p className="text-[10px] text-slate-500 uppercase tracking-widest px-2 py-2 font-medium">
                {t("collegePortal", lang)}
              </p>
              <button
                onClick={() => { setScreen("college"); setSidebarOpen(false); }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                  screen === "college"
                    ? "bg-indigo-50 text-indigo-700 font-semibold"
                    : "text-slate-500 hover:text-slate-800 hover:bg-slate-50"
                }`}
              >
                <AcademicIcon className="w-4 h-4 shrink-0" />
                <span>{t("collegePortal", lang)}</span>
              </button>
              <button
                onClick={() => { setScreen("insights"); setSidebarOpen(false); }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                  screen === "insights"
                    ? "bg-indigo-50 text-indigo-700 font-semibold"
                    : "text-slate-500 hover:text-slate-800 hover:bg-slate-50"
                }`}
              >
                <SparklesIcon className="w-4 h-4 shrink-0" />
                <span>{t("insights", lang)}</span>
              </button>
              <button
                onClick={() => { setScreen("resources"); setSidebarOpen(false); }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                  screen === "resources"
                    ? "bg-indigo-50 text-indigo-700 font-semibold"
                    : "text-slate-500 hover:text-slate-800 hover:bg-slate-50"
                }`}
              >
                <BookIcon className="w-4 h-4 shrink-0" />
                <span>{t("resources", lang)}</span>
              </button>
            </div>
          ) : (
            <div className="space-y-0.5">
              <p className="text-[10px] text-slate-500 uppercase tracking-widest px-2 py-2 font-medium">
                {t("industryPortal", lang)}
              </p>
              <button
                onClick={() => { setScreen("industry"); setSidebarOpen(false); }}
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium bg-indigo-50 text-indigo-700"
              >
                <BriefcaseIcon className="w-4 h-4" />
                <span>{t("companyDashboard", lang)}</span>
              </button>
            </div>
          )}
        </nav>

        {/* Profile footer */}
        <div className="p-4 border-t border-slate-200 shrink-0">
          <div className="flex items-center gap-3">
            <div
              onClick={() => setScreen("settings")}
              className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-400 to-violet-500 flex items-center justify-center text-xs text-white font-semibold shrink-0 cursor-pointer hover:ring-2 hover:ring-indigo-300"
            >
              {initials}
            </div>
            <div className="min-w-0">
              <p className="text-xs text-slate-800 font-medium truncate">{state.account?.name}</p>
              <p className="text-[11px] text-slate-500 truncate">{state.academic.degree || "Student"} · {state.academic.year} year</p>
            </div>
          </div>
          <div className="flex items-center justify-between mt-3 text-[11px]">
            <button onClick={() => setScreen("settings")} className="text-indigo-600 hover:underline font-medium">
              {t("editProfile", lang)}
            </button>
            <button
              onClick={() => setSignOutModalOpen(true)}
              className="text-slate-400 hover:text-rose-600 transition-colors"
            >
              {t("signOut", lang)}
            </button>
          </div>
          {state.demo && <p className="mt-2 text-[10px] text-amber-700 bg-amber-50 rounded px-2 py-1 font-medium">DEMO DATA profile</p>}
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top bar */}
        <header className="h-14 bg-white border-b border-slate-200 flex items-center px-4 gap-4 shrink-0 z-10">
          <button
            onClick={() => setSidebarOpen(true)}
            className="lg:hidden p-1.5 rounded-lg text-slate-500 hover:bg-slate-100"
          >
            <MenuIcon className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2 flex-1 max-w-xs">
            <SearchIcon className="w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder={t("searchPlaceholder", lang)}
              className="flex-1 text-sm text-slate-600 placeholder-slate-400 bg-transparent outline-none"
            />
          </div>
          <div className="ml-auto flex items-center gap-2.5">
            {/* Quick 15-Min Assessment Launch Pill */}
            <button
              onClick={() => setScreen("assessment")}
              className={`hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all border ${
                screen === "assessment"
                  ? "bg-indigo-600 text-white border-indigo-600 shadow-xs"
                  : "bg-indigo-50 text-indigo-700 hover:bg-indigo-100 border-indigo-100"
              }`}
            >
              <span>⏱</span>
              <span>{t("takeAssessment", lang)}</span>
            </button>

            <button
              onClick={() => setScreen("instructions")}
              title="Documentation & Instructions"
              className="p-2 text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <InfoIcon className="w-4 h-4" />
            </button>

            <button
              title="Notifications"
              className="relative p-2 text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <BellIcon className="w-4 h-4" />
              <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-rose-500 rounded-full" />
            </button>

            {/* User Avatar Menu */}
            <ProfileMenu
              onNavigate={(s) => setScreen(s as Screen)}
              onOpenSignOut={() => setSignOutModalOpen(true)}
            />
          </div>
        </header>

        {/* Screen */}
        <main className="flex-1 overflow-y-auto">
          {screens[screen] ?? screens["overview"]}
        </main>
      </div>

      {/* Sign Out Confirmation Modal */}
      <SignOutModal
        isOpen={signOutModalOpen}
        onClose={() => setSignOutModalOpen(false)}
        onConfirmSignOut={handleSignOut}
      />
    </div>
  );
}

// Icons
function GridIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="1" y="1" width="6" height="6" rx="1.5" /><rect x="9" y="1" width="6" height="6" rx="1.5" />
      <rect x="1" y="9" width="6" height="6" rx="1.5" /><rect x="9" y="9" width="6" height="6" rx="1.5" />
    </svg>
  );
}
function TargetIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
      <circle cx="8" cy="8" r="7" /><circle cx="8" cy="8" r="4" /><circle cx="8" cy="8" r="1" fill="currentColor" stroke="none" />
    </svg>
  );
}
function StarIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M8 1l1.8 3.6L14 5.3l-3 2.9.7 4.1L8 10.4l-3.7 1.9.7-4.1L2 5.3l4.2-.7L8 1z" />
    </svg>
  );
}
function ZapIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M9 1L4 9h5l-2 6 6-8H8l1-6z" />
    </svg>
  );
}
function MapIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M1 3l4-2 6 2 4-2v11l-4 2-6-2-4 2V3z" /><path d="M5 1v11M11 3v11" />
    </svg>
  );
}
function BriefcaseIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="1" y="5" width="14" height="9" rx="1.5" />
      <path d="M5 5V3.5A1.5 1.5 0 016.5 2h3A1.5 1.5 0 0111 3.5V5" /><path d="M1 9h14" />
    </svg>
  );
}
function FolderIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M1 3.5A1.5 1.5 0 012.5 2h3l2 2H13.5A1.5 1.5 0 0115 5.5v7A1.5 1.5 0 0113.5 14h-11A1.5 1.5 0 011 12.5v-9z" />
    </svg>
  );
}
function ChartIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M1 12l4-5 3 3 4-6 3 3" /><path d="M1 14h14" />
    </svg>
  );
}
function MenuIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M3 6h14M3 10h14M3 14h14" />
    </svg>
  );
}
function SearchIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
      <circle cx="6.5" cy="6.5" r="5" /><path d="M11 11l3 3" />
    </svg>
  );
}
function BellIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M8 1a5 5 0 015 5c0 3 1 4 1 4H2s1-1 1-4a5 5 0 015-5z" />
      <path d="M6.5 13a1.5 1.5 0 003 0" />
    </svg>
  );
}
function InfoIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
      <circle cx="8" cy="8" r="7" />
      <path d="M8 7v4M8 4.5h.01" />
    </svg>
  );
}
function BuildingIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="3" y="1.5" width="10" height="13" rx="1.5" /><path d="M6 5h1M9 5h1M6 8h1M9 8h1M7 14.5v-3h2v3" />
    </svg>
  );
}
function CpuIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="4" y="4" width="8" height="8" rx="1.5" /><path d="M6.5 1.5v2.5M9.5 1.5v2.5M6.5 12v2.5M9.5 12v2.5M1.5 6.5H4M1.5 9.5H4M12 6.5h2.5M12 9.5h2.5" />
    </svg>
  );
}
function TrendIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M1 11l4-4 3 3 5-6" /><path d="M10 4h3v3" />
    </svg>
  );
}
function BookIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M2 3.5A1.5 1.5 0 013.5 2H7v12H3.5A1.5 1.5 0 012 12.5v-9zM14 3.5A1.5 1.5 0 0012.5 2H9v12h3.5a1.5 1.5 0 001.5-1.5v-9z" />
    </svg>
  );
}
function AcademicIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M8 2l7 3.5L8 9 1 5.5 8 2zM3 7.5v4c0 1.5 2.2 2.5 5 2.5s5-1 5-2.5v-4" />
    </svg>
  );
}
function SparklesIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M8 1l1.5 4.5L14 7l-4.5 1.5L8 13l-1.5-4.5L2 7l4.5-1.5L8 1z" />
    </svg>
  );
}
