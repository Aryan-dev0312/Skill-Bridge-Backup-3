// Static reference data. Career targets are SkillBridge's own estimates for
// learning purposes - they are NOT employer requirements.
import type { Requirement } from "./skillGap.ts";

export const SKILL_CATEGORIES: { category: string; skills: string[] }[] = [
  { category: "Programming", skills: ["Python", "C++", "Java", "JavaScript", "TypeScript", "Go", "Rust"] },
  { category: "CS Foundations", skills: ["Data Structures", "Algorithms", "System Design", "Linux/Shell", "Git", "SQL", "Networking"] },
  { category: "Web & APIs", skills: ["React", "Node.js", "REST APIs"] },
  { category: "Data & ML", skills: ["Statistics", "NumPy/Pandas", "Machine Learning", "Deep Learning", "PyTorch", "TensorFlow", "Hugging Face", "Data Visualization"] },
  { category: "Generative AI", skills: ["LLMs", "RAG", "Vector Databases", "AI Agents"] },
  { category: "Data Engineering", skills: ["Spark", "Kafka", "dbt"] },
  { category: "Cloud & DevOps", skills: ["Cloud Platforms", "Docker", "Kubernetes", "Terraform", "CI/CD"] },
  { category: "Security", skills: ["Security Fundamentals", "OWASP", "SIEM", "Zero Trust"] },
  { category: "Hardware & Semiconductor", skills: ["Digital Logic", "Verilog/SystemVerilog", "VHDL", "FPGA", "Embedded C"] },
];
export const ALL_SKILLS = SKILL_CATEGORIES.flatMap((c) => c.skills);
export const categoryOf = (skill: string) => SKILL_CATEGORIES.find((c) => c.skills.includes(skill))?.category ?? "Other";

export interface Career {
  id: string;
  title: string;
  domain: string;
  description: string;
  required: Requirement[]; // target = expected proficiency (0-100)
  preferred: string[];
  languages: string[];
  frameworks: string[];
  tools: string[];
  projects: string[];
}

const r = (name: string, target: number, weight = 1): Requirement => ({ name, target, weight });

export const CAREERS: Career[] = [
  {
    id: "swe", title: "Software Engineer (Backend)", domain: "Software Engineering",
    description: "Designs and builds server-side applications, APIs and data layers that other software and users depend on.",
    required: [r("Python", 75), r("Data Structures", 80, 2), r("Algorithms", 75, 2), r("System Design", 65), r("SQL", 70), r("Git", 70), r("REST APIs", 70), r("Linux/Shell", 60), r("Docker", 55)],
    preferred: ["Java", "Go", "Node.js", "Cloud Platforms", "CI/CD"],
    languages: ["Python", "Java", "Go"], frameworks: ["Django", "FastAPI", "Spring Boot"], tools: ["Git", "PostgreSQL", "Docker", "Redis"],
    projects: ["REST API with authentication and a database", "Task queue with retries and priorities", "URL shortener with caching"],
  },
  {
    id: "ml", title: "AI / ML Engineer", domain: "AI / Machine Learning",
    description: "Trains, evaluates and ships machine-learning models and the pipelines around them.",
    required: [r("Python", 80), r("Machine Learning", 75, 2), r("Deep Learning", 65), r("Statistics", 65), r("NumPy/Pandas", 75), r("PyTorch", 65), r("SQL", 55), r("Git", 60), r("Docker", 50)],
    preferred: ["TensorFlow", "Cloud Platforms", "Kubernetes", "Hugging Face"],
    languages: ["Python", "C++"], frameworks: ["PyTorch", "TensorFlow", "scikit-learn"], tools: ["Jupyter", "MLflow", "Docker", "Git"],
    projects: ["Image classifier served behind an API", "Tabular prediction model with a reproducible pipeline", "Experiment tracking for 3 model variants"],
  },
  {
    id: "genai", title: "Generative AI Engineer", domain: "Generative AI",
    description: "Builds applications on top of large language models: retrieval, agents, evaluation and serving.",
    required: [r("Python", 80), r("LLMs", 70, 2), r("RAG", 70, 2), r("Vector Databases", 60), r("AI Agents", 55), r("Hugging Face", 60), r("REST APIs", 65), r("Machine Learning", 55), r("Git", 60)],
    preferred: ["PyTorch", "Docker", "Cloud Platforms", "System Design"],
    languages: ["Python", "TypeScript"], frameworks: ["Hugging Face Transformers", "LangChain", "LlamaIndex"], tools: ["Vector databases", "Docker", "Git"],
    projects: ["RAG chatbot over your own documents", "Tool-using agent that completes a multi-step task", "Prompt and retrieval evaluation harness"],
  },
  {
    id: "ds", title: "Data Scientist", domain: "Data Science",
    description: "Turns data into decisions through analysis, statistics, experimentation and predictive models.",
    required: [r("Python", 75), r("Statistics", 75, 2), r("SQL", 75), r("NumPy/Pandas", 80), r("Machine Learning", 65), r("Data Visualization", 65), r("Git", 55)],
    preferred: ["Spark", "dbt", "Deep Learning", "Cloud Platforms"],
    languages: ["Python", "SQL", "R"], frameworks: ["pandas", "scikit-learn", "Matplotlib"], tools: ["Jupyter", "Tableau or Power BI", "Git"],
    projects: ["A/B test analysis with a written recommendation", "Forecasting dashboard", "Customer churn model with feature analysis"],
  },
  {
    id: "cloud", title: "Cloud Engineer", domain: "Cloud Computing",
    description: "Designs, deploys and operates infrastructure and services on public cloud platforms.",
    required: [r("Cloud Platforms", 75, 2), r("Linux/Shell", 70), r("Networking", 65), r("Docker", 65), r("Terraform", 60), r("Python", 55), r("CI/CD", 60), r("Security Fundamentals", 50), r("Git", 60)],
    preferred: ["Kubernetes", "Go", "SQL"],
    languages: ["Python", "Go", "Bash"], frameworks: ["Terraform", "AWS CloudFormation"], tools: ["AWS / Azure / Google Cloud CLIs", "Docker", "Git"],
    projects: ["Three-tier app deployed with infrastructure as code", "Static site with CDN and HTTPS", "Serverless API with monitoring"],
  },
  {
    id: "devops", title: "DevOps Engineer", domain: "DevOps",
    description: "Automates build, test, deployment and monitoring so teams can release software reliably.",
    required: [r("Linux/Shell", 75), r("Docker", 75, 2), r("Kubernetes", 65, 2), r("CI/CD", 75, 2), r("Terraform", 65), r("Git", 70), r("Cloud Platforms", 60), r("Python", 55), r("Networking", 55)],
    preferred: ["Go", "Security Fundamentals", "System Design"],
    languages: ["Bash", "Python", "Go"], frameworks: ["Terraform", "Helm"], tools: ["GitHub Actions", "Prometheus", "Grafana", "Ansible"],
    projects: ["CI/CD pipeline with tests and automatic deploy", "Kubernetes deployment with monitoring", "Reproducible environment built with IaC"],
  },
  {
    id: "sec", title: "Cybersecurity Analyst", domain: "Cybersecurity",
    description: "Detects, investigates and reduces security risks across systems, networks and applications.",
    required: [r("Security Fundamentals", 75, 2), r("Networking", 70), r("Linux/Shell", 65), r("OWASP", 65), r("SIEM", 60), r("Zero Trust", 50), r("Python", 50), r("Git", 40)],
    preferred: ["Cloud Platforms", "Docker", "Statistics"],
    languages: ["Python", "Bash"], frameworks: ["OWASP Top 10", "Zero Trust model"], tools: ["Wireshark", "Nmap", "A SIEM (e.g. Splunk or Elastic)", "Burp Suite"],
    projects: ["Home lab with centralized log monitoring", "Assess an intentionally vulnerable web app (e.g. OWASP Juice Shop)", "Write and test detection rules"],
  },
  {
    id: "semi", title: "Semiconductor / Digital Design Engineer", domain: "Semiconductor Engineering",
    description: "Designs and verifies digital hardware using hardware description languages, simulation and FPGA prototyping.",
    required: [r("Digital Logic", 80, 2), r("Verilog/SystemVerilog", 75, 2), r("FPGA", 60), r("Embedded C", 55), r("VHDL", 45), r("C++", 50), r("Linux/Shell", 55), r("Python", 50), r("Git", 50)],
    preferred: ["Networking", "Algorithms"],
    languages: ["Verilog", "SystemVerilog", "VHDL", "C", "Python"], frameworks: ["UVM (verification methodology)"], tools: ["HDL simulators", "FPGA vendor toolchains", "Linux", "Git"],
    projects: ["UART transmitter and receiver in Verilog", "Simple RISC-style CPU", "FPGA design with a VGA or LED display"],
  },
];
export const careerById = (id: string | null | undefined) => CAREERS.find((c) => c.id === id) ?? null;

// ---- Diagnostic (5 questions, each tied to one skill) -------------------
export interface Question { id: string; skill: string; prompt: string; options: string[]; answer: number }
export const QUESTIONS: Question[] = [
  { id: "q1", skill: "Python", prompt: "What does len({1, 2, 2, 3}) return in Python?", options: ["4", "3", "2", "It raises an error"], answer: 1 },
  { id: "q2", skill: "Data Structures", prompt: "Which data structure offers average O(1) lookup by key?", options: ["Linked list", "Sorted array", "Hash table", "Binary heap"], answer: 2 },
  { id: "q3", skill: "SQL", prompt: "Which SQL clause filters groups after aggregation?", options: ["WHERE", "HAVING", "ORDER BY", "LIMIT"], answer: 1 },
  { id: "q4", skill: "Git", prompt: "Which command creates a new branch and switches to it?", options: ["git branch -d feature", "git merge feature", "git checkout -b feature", "git stash feature"], answer: 2 },
  { id: "q5", skill: "Algorithms", prompt: "What is the time complexity of binary search on a sorted array of n items?", options: ["O(n)", "O(log n)", "O(n log n)", "O(1)"], answer: 1 },
];

// ---- Learning resources (official docs / well-known free resources) ------
export interface Resource { title: string; url: string }
export const RESOURCES: Record<string, Resource> = {
  Python: { title: "The Python Tutorial (python.org)", url: "https://docs.python.org/3/tutorial/" },
  JavaScript: { title: "MDN Learn Web Development", url: "https://developer.mozilla.org/en-US/docs/Learn_web_development" },
  TypeScript: { title: "TypeScript Handbook", url: "https://www.typescriptlang.org/docs/handbook/intro.html" },
  React: { title: "React: Learn", url: "https://react.dev/learn" },
  "Node.js": { title: "Node.js: Learn", url: "https://nodejs.org/en/learn" },
  Git: { title: "Pro Git (book)", url: "https://git-scm.com/book" },
  SQL: { title: "SQLBolt interactive lessons", url: "https://sqlbolt.com/" },
  Docker: { title: "Docker: Get started", url: "https://docs.docker.com/get-started/" },
  Kubernetes: { title: "Kubernetes tutorials", url: "https://kubernetes.io/docs/tutorials/" },
  Terraform: { title: "HashiCorp Terraform tutorials", url: "https://developer.hashicorp.com/terraform/tutorials" },
  "CI/CD": { title: "GitHub Actions documentation", url: "https://docs.github.com/en/actions" },
  PyTorch: { title: "PyTorch tutorials", url: "https://pytorch.org/tutorials/" },
  TensorFlow: { title: "TensorFlow tutorials", url: "https://www.tensorflow.org/tutorials" },
  "Hugging Face": { title: "Hugging Face Learn", url: "https://huggingface.co/learn" },
  LLMs: { title: "Hugging Face Learn", url: "https://huggingface.co/learn" },
  "Machine Learning": { title: "scikit-learn user guide", url: "https://scikit-learn.org/stable/user_guide.html" },
  "Deep Learning": { title: "Dive into Deep Learning (d2l.ai)", url: "https://d2l.ai/" },
  Statistics: { title: "Khan Academy: Statistics & Probability", url: "https://www.khanacademy.org/math/statistics-probability" },
  OWASP: { title: "OWASP Top Ten", url: "https://owasp.org/www-project-top-ten/" },
  Rust: { title: "The Rust Programming Language (book)", url: "https://doc.rust-lang.org/book/" },
  Go: { title: "A Tour of Go", url: "https://go.dev/tour/" },
  Java: { title: "dev.java: Learn", url: "https://dev.java/learn/" },
  "C++": { title: "LearnCpp.com", url: "https://www.learncpp.com/" },
  "Linux/Shell": { title: "Linux Journey", url: "https://linuxjourney.com/" },
  Algorithms: { title: "VisuAlgo visualizations", url: "https://visualgo.net/" },
  "Data Structures": { title: "VisuAlgo visualizations", url: "https://visualgo.net/" },
  "System Design": { title: "System Design Primer (GitHub)", url: "https://github.com/donnemartin/system-design-primer" },
  "Cloud Platforms": { title: "AWS: Getting started", url: "https://aws.amazon.com/getting-started/" },
  Spark: { title: "Apache Spark quick start", url: "https://spark.apache.org/docs/latest/quick-start.html" },
  Kafka: { title: "Apache Kafka quickstart", url: "https://kafka.apache.org/quickstart" },
  dbt: { title: "dbt documentation", url: "https://docs.getdbt.com/" },
  "Verilog/SystemVerilog": { title: "HDLBits practice problems", url: "https://hdlbits.01xz.net/" },
};

// ---- Technology explorer -------------------------------------------------
export interface Tech { name: string; category: string; description: string; careers: string[] }
export const TECH_CATEGORIES = ["Programming", "AI/ML", "Generative AI", "AI Infrastructure", "Data", "Cloud", "DevOps", "Cybersecurity", "Semiconductor"];
const t = (name: string, category: string, description: string, careers: string[]): Tech => ({ name, category, description, careers });
export const TECHNOLOGIES: Tech[] = [
  t("Python", "Programming", "General-purpose language that dominates data science, machine learning and scripting.", ["swe", "ml", "genai", "ds", "cloud", "devops", "sec"]),
  t("C++", "Programming", "Compiled language for performance-critical software, systems programming and hardware tooling.", ["semi", "swe", "ml"]),
  t("Java", "Programming", "Statically typed language widely used for enterprise backends and large services.", ["swe"]),
  t("Go", "Programming", "Compiled language built for concurrency; common in cloud and infrastructure tooling.", ["swe", "cloud", "devops"]),
  t("Rust", "Programming", "Systems language focused on memory safety without a garbage collector.", ["swe", "sec"]),
  t("TypeScript", "Programming", "Typed superset of JavaScript used for large web and Node.js codebases.", ["swe", "genai"]),
  t("PyTorch", "AI/ML", "Open-source deep learning framework widely used in research and production.", ["ml", "genai"]),
  t("TensorFlow", "AI/ML", "Open-source machine learning framework with tooling for training and deployment.", ["ml"]),
  t("Hugging Face", "AI/ML", "Hub and libraries for pretrained models, datasets and the Transformers library.", ["genai", "ml"]),
  t("LLMs", "Generative AI", "Large language models: neural networks trained on large text corpora to understand and generate language.", ["genai", "ml"]),
  t("RAG", "Generative AI", "Retrieval-augmented generation: fetch relevant documents and give them to an LLM as context.", ["genai"]),
  t("Embeddings", "Generative AI", "Numeric vectors that represent text or images so that similar items can be found by distance.", ["genai", "ml", "ds"]),
  t("Vector databases", "Generative AI", "Stores built to index and search embeddings quickly (for example pgvector or Milvus).", ["genai"]),
  t("AI agents", "Generative AI", "LLM-driven systems that plan steps and call tools to complete multi-step tasks.", ["genai"]),
  t("CUDA", "AI Infrastructure", "NVIDIA's platform and programming model for running general computation on GPUs.", ["ml", "semi"]),
  t("GPU computing", "AI Infrastructure", "Using GPUs for highly parallel numeric workloads such as model training and inference.", ["ml", "genai"]),
  t("vLLM", "AI Infrastructure", "Open-source library for high-throughput serving of large language models.", ["genai", "ml"]),
  t("Model serving", "AI Infrastructure", "Packaging trained models behind APIs with batching, scaling and monitoring.", ["ml", "genai", "devops"]),
  t("Spark", "Data", "Distributed engine for large-scale data processing and analytics.", ["ds"]),
  t("Kafka", "Data", "Distributed event-streaming platform for real-time data pipelines.", ["swe", "ds"]),
  t("dbt", "Data", "SQL-based tool for transforming data inside a warehouse with testing and documentation.", ["ds"]),
  t("AWS", "Cloud", "Amazon's public cloud platform covering compute, storage, networking and managed services.", ["cloud", "devops", "swe"]),
  t("Azure", "Cloud", "Microsoft's public cloud platform.", ["cloud", "devops", "swe"]),
  t("Google Cloud", "Cloud", "Google's public cloud platform, including data and AI services.", ["cloud", "devops", "ml"]),
  t("Docker", "DevOps", "Packages applications and dependencies into portable containers.", ["devops", "cloud", "swe", "ml"]),
  t("Kubernetes", "DevOps", "Orchestrates containers: scheduling, scaling and self-healing across machines.", ["devops", "cloud"]),
  t("Terraform", "DevOps", "Infrastructure as code: describe cloud resources in files and apply them repeatably.", ["devops", "cloud"]),
  t("SIEM", "Cybersecurity", "Security information and event management: collects and correlates logs to detect threats.", ["sec"]),
  t("Zero Trust", "Cybersecurity", "Security model that verifies every request instead of trusting anything by network location.", ["sec", "cloud"]),
  t("OWASP", "Cybersecurity", "Community project best known for the OWASP Top 10 list of critical web application risks.", ["sec", "swe"]),
  t("Verilog", "Semiconductor", "Hardware description language for modelling and designing digital circuits.", ["semi"]),
  t("SystemVerilog", "Semiconductor", "Extension of Verilog with stronger design and verification features.", ["semi"]),
  t("VHDL", "Semiconductor", "Hardware description language common in aerospace, defense and FPGA work.", ["semi"]),
  t("FPGA", "Semiconductor", "Reconfigurable chips programmed with an HDL to prototype or run custom digital logic.", ["semi"]),
];

// ---- Company directory (general public information only) -----------------
export interface Company {
  id: string; name: string; overview: string; domains: string[]; technologies: string[]; careers: string[]; careersUrl: string;
}
export const COMPANIES: Company[] = [
  { id: "nvidia", name: "NVIDIA", overview: "Accelerated-computing company best known for GPUs, the CUDA platform and AI hardware and software.", domains: ["AI & accelerated computing", "Graphics", "Data center"], technologies: ["CUDA", "GPU computing", "C++", "Python"], careers: ["ml", "genai", "semi", "swe"], careersUrl: "https://www.nvidia.com/en-us/about-nvidia/careers/" },
  { id: "google", name: "Google", overview: "Technology company behind Search, Android, YouTube, Google Cloud and a large AI research effort.", domains: ["Search & ads", "Cloud", "AI research"], technologies: ["Go", "Python", "Java", "C++", "TensorFlow", "Kubernetes", "Google Cloud"], careers: ["swe", "ml", "genai", "ds", "cloud", "devops", "sec"], careersUrl: "https://www.google.com/about/careers/applications/" },
  { id: "microsoft", name: "Microsoft", overview: "Software and cloud company behind Windows, Office, GitHub, Azure and AI services.", domains: ["Cloud", "Productivity software", "Developer tools", "AI"], technologies: ["Azure", "TypeScript", "Python", "Docker"], careers: ["swe", "ml", "genai", "cloud", "devops", "sec", "ds"], careersUrl: "https://careers.microsoft.com/" },
  { id: "amazon", name: "Amazon", overview: "E-commerce and logistics company that also runs Amazon Web Services, the largest public cloud provider by market share.", domains: ["E-commerce", "Cloud (AWS)", "Logistics"], technologies: ["AWS", "Java", "Python"], careers: ["swe", "cloud", "devops", "ds", "ml", "sec"], careersUrl: "https://www.amazon.jobs/" },
  { id: "qualcomm", name: "Qualcomm", overview: "Semiconductor company focused on wireless technology and mobile processors such as Snapdragon.", domains: ["Semiconductors", "Wireless", "On-device AI"], technologies: ["Verilog/SystemVerilog", "C++", "Embedded C", "Python"], careers: ["semi", "ml", "swe"], careersUrl: "https://www.qualcomm.com/company/careers" },
  { id: "adobe", name: "Adobe", overview: "Software company known for Photoshop, Acrobat and Creative Cloud, with generative AI features such as Firefly.", domains: ["Creative software", "Document software", "Marketing cloud"], technologies: ["TypeScript", "Python", "LLMs"], careers: ["swe", "ml", "genai", "ds"], careersUrl: "https://careers.adobe.com/" },
  { id: "intel", name: "Intel", overview: "Semiconductor company that designs processors and operates chip manufacturing (foundry) capacity.", domains: ["Semiconductors", "CPUs", "Foundry"], technologies: ["Verilog/SystemVerilog", "C++", "FPGA", "Python"], careers: ["semi", "swe", "ml"], careersUrl: "https://jobs.intel.com/" },
  { id: "openai", name: "OpenAI", overview: "AI research and deployment company behind ChatGPT and a developer API for language and multimodal models.", domains: ["AI research", "AI products", "Developer API"], technologies: ["Python", "LLMs", "GPU computing"], careers: ["genai", "ml", "swe"], careersUrl: "https://openai.com/careers/" },
  { id: "salesforce", name: "Salesforce", overview: "Enterprise software company known for its CRM platform, cloud applications and AI agent products.", domains: ["CRM", "Enterprise cloud", "AI agents"], technologies: ["Java", "JavaScript", "REST APIs", "LLMs"], careers: ["swe", "genai", "ds", "cloud"], careersUrl: "https://careers.salesforce.com/" },
  { id: "cisco", name: "Cisco", overview: "Networking and security company with products spanning routing, collaboration and cybersecurity.", domains: ["Networking", "Security", "Collaboration"], technologies: ["Networking", "Python", "Zero Trust"], careers: ["sec", "cloud", "devops", "swe"], careersUrl: "https://jobs.cisco.com/" },
];

// ---- Industry trends: ONLY entries with verified facts carry findings -----
export interface TrendSource {
  id: string; title: string; publisher: string; published: string | null; url: string | null; topic: string; findings: string[];
}
export const TREND_SOURCES: TrendSource[] = [
  { id: "wef", title: "The Future of Jobs Report 2025", publisher: "World Economic Forum", published: "January 2025", url: "https://www.weforum.org/publications/the-future-of-jobs-report-2025/", topic: "Global jobs and skills outlook to 2030",
    findings: ["Employers expect about 170 million new roles to be created and about 92 million displaced by 2030 (net +78 million).", "Roughly 39% of workers' existing skill sets are expected to change by 2030.", "AI and big data, networks and cybersecurity, and technological literacy are among the fastest-growing skills."] },
  { id: "peoplelogic", title: "State of Hiring Report 2026", publisher: "PeopleLogic", published: null, url: null, topic: "Hiring trends", findings: [] },
  { id: "dsci", title: "Cyber Security Skilling Landscape 2025-2026", publisher: "DSCI", published: null, url: null, topic: "Cybersecurity skills in India", findings: [] },
  { id: "quess", title: "GCC Trends Q4 FY26", publisher: "Quess", published: null, url: null, topic: "Global capability centres in India", findings: [] },
  { id: "niit", title: "India Skills Gap Report 2026", publisher: "NIIT", published: null, url: null, topic: "Skills gap in India", findings: [] },
];
