# Run SkillBridge locally (VS Code)

1. Install Node.js 20+ from https://nodejs.org
2. Open the `SkillBridge` folder in VS Code (File > Open Folder)
3. Open the terminal (Ctrl + `) and run:

   npm install
   npm run dev

4. Open the Local URL it prints (http://localhost:8443)

If port 8443 is busy:  PORT=3000 npm run dev   (Windows PowerShell: $env:PORT=3000; npm run dev)
