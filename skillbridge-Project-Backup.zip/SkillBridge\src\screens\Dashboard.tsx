import { useState, useMemo } from "react";
import { QUESTIONS } from "../lib/catalog";
import { useStore } from "../lib/store";

export default function Dashboard({ onNavigate }: { onNavigate: (s: string) => void }) {
  const { state, skills, assessment, career, rows, counts, readiness, roadmap, taskStats, nextTask } = useStore();
  const [notificationsRead, setNotificationsRead] = useState(false);

  const studentName = state.account?.name ?? "Student";
  const firstName = studentName.split(" ")[0];
  const gaps = rows.filter((r) => r.gap > 0);
  const totalSkillsCount = Object.keys(skills).length;
  const assessedSkills = Object.values(skills).filter((s) => s.status === "assessed").length;
  const verifiedSkills = Object.values(skills).filter((s) => s.status === "verified").length;
  const assessedPct = totalSkillsCount > 0 ? Math.round((assessedSkills / totalSkillsCount) * 100) : 0;
  const currentReadiness = readiness ?? 0;

  // Bell curve position (0 - 100% mapped to 30px - 370px on a 400px width viewBox)
  const pinX = Math.min(370, Math.max(30, Math.round((currentReadiness / 100) * 340 + 30)));
  const pinY = Math.max(16, 75 - Math.sin((currentReadiness / 100) * Math.PI) * 58);

  const latestComprehensive =
    state.comprehensiveAssessments && state.comprehensiveAssessments.length > 0
      ? state.comprehensiveAssessments[state.comprehensiveAssessments.length - 1]
      : null;

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Welcome back, {firstName}
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Targeting <span className="font-semibold text-slate-700">{career?.title ?? "Software Engineer"}</span> · {state.academic.degree || "B.Tech"} ({state.academic.year || "3rd"} Year)
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate("assessment")}
            className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-xs transition-colors flex items-center gap-1.5"
          >
            <span>⏱</span>
            <span>Take 15-Min Assessment</span>
          </button>
        </div>
      </div>

      {/* TOP ROW: Two Major Panels (Matching Codility Reference Layout) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Left Panel: Candidate Performance & Distribution Curve */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <h2 className="text-sm font-bold text-slate-900">
                Candidate Performance & Benchmark
              </h2>
              <span className="text-[11px] text-slate-400 font-medium">
                Data for current profile
              </span>
            </div>

            {/* Gaussian Bell Curve Distribution Chart */}
            <div className="relative w-full h-32 pt-2">
              <svg viewBox="0 0 400 100" className="w-full h-full overflow-visible">
                <defs>
                  <linearGradient id="bellGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#F87171" stopOpacity="0.8" />
                    <stop offset="35%" stopColor="#FBBF24" stopOpacity="0.85" />
                    <stop offset="70%" stopColor="#34D399" stopOpacity="0.85" />
                    <stop offset="100%" stopColor="#10B981" stopOpacity="0.9" />
                  </linearGradient>
                  <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
                    <feDropShadow dx="0" dy="2" stdDeviation="2" floodColor="#0F172A" floodOpacity="0.15" />
                  </filter>
                </defs>

                {/* Bell Curve Area Fill */}
                <path
                  d="M 10,85 C 80,85 130,70 170,30 C 200,5 210,5 240,30 C 280,70 330,85 390,85 L 390,92 L 10,92 Z"
                  fill="url(#bellGrad)"
                />

                {/* Base Axis Line */}
                <line x1="10" y1="90" x2="390" y2="90" stroke="#CBD5E1" strokeWidth="1.5" />

                {/* Candidate Indicator Marker */}
                <g transform={`translate(${pinX}, ${pinY})`}>
                  <line x1="0" y1="0" x2="0" y2={90 - pinY} stroke="#1E293B" strokeWidth="1.5" strokeDasharray="2 2" />
                  <circle cx="0" cy="0" r="5" fill="#1E293B" stroke="#FFFFFF" strokeWidth="2" filter="url(#shadow)" />
                  <rect x="-38" y="-22" width="76" height="18" rx="5" fill="#0F172A" />
                  <text x="0" y="-10" textAnchor="middle" fill="#FFFFFF" fontSize="9" fontWeight="600" fontFamily="sans-serif">
                    {firstName}: {currentReadiness}%
                  </text>
                </g>
              </svg>
            </div>

            {/* 4-Metric Strip (Matching reference) */}
            <div className="grid grid-cols-4 gap-2 pt-3 border-t border-slate-100 text-center">
              <div>
                <p className="text-xs font-bold font-mono text-slate-800">
                  {totalSkillsCount} (100%)
                </p>
                <p className="text-[10px] text-slate-500 mt-0.5">Skills Tracked</p>
              </div>
              <div>
                <p className="text-xs font-bold font-mono text-slate-800">
                  {assessedSkills} ({assessedPct}%)
                </p>
                <p className="text-[10px] text-slate-500 mt-0.5">Assessed Skills</p>
              </div>
              <div>
                <p className="text-xs font-bold font-mono text-slate-800">
                  {counts.high} High
                </p>
                <p className="text-[10px] text-slate-500 mt-0.5">Priority Gaps</p>
              </div>
              <div>
                <p className="text-xs font-bold font-mono text-blue-600">
                  {currentReadiness}%
                </p>
                <p className="text-[10px] text-slate-500 mt-0.5">Readiness Score</p>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-4 mt-3 border-t border-slate-100 text-xs">
            <span className="text-slate-500">
              {gaps.length > 0 ? `${gaps.length} skill gaps remain for ${career?.title}` : "All expected proficiencies met!"}
            </span>
            <button
              onClick={() => onNavigate("assessment")}
              className="px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold transition-colors shadow-xs"
            >
              See More Analytics
            </button>
          </div>
        </div>

        {/* Right Panel: Notifications & Task Milestone Stream */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-bold text-slate-900">Notifications</h2>
              <button
                onClick={() => setNotificationsRead(true)}
                className="text-xs text-blue-600 hover:underline font-medium"
              >
                {notificationsRead ? "All Read ✓" : "Mark all as read"}
              </button>
            </div>

            <div className="space-y-3">
              {/* Notification 1: Roadmap Next Task */}
              <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 border border-slate-100">
                <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0 text-sm font-bold">
                  🎯
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold text-slate-800 truncate">
                    Recommended Milestone: {nextTask ? nextTask.title : "All phase tasks complete"}
                  </p>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    {nextTask ? `Phase: ${nextTask.phase}` : "Re-rate your skills to update your roadmap"} · Today
                  </p>
                </div>
                <button
                  onClick={() => onNavigate("roadmap")}
                  className="text-xs text-blue-600 hover:underline font-semibold shrink-0"
                >
                  Start
                </button>
              </div>

              {/* Notification 2: Assessment Recommendation */}
              <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 border border-slate-100">
                <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center shrink-0 text-sm font-bold">
                  ⏱
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold text-slate-800 truncate">
                    15-Minute Technical Assessment Available
                  </p>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Evaluate 9 engineering categories & update your assessed profile · 30 Questions
                  </p>
                </div>
                <button
                  onClick={() => onNavigate("assessment")}
                  className="text-xs text-blue-600 hover:underline font-semibold shrink-0"
                >
                  Launch
                </button>
              </div>

              {/* Notification 3: Industry Alignment */}
              <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 border border-slate-100">
                <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0 text-sm font-bold">
                  🏢
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold text-slate-800 truncate">
                    {state.projects.length} Projects Tracked for Verification
                  </p>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    {verifiedSkills} verified · Add GitHub links & evidence to impress recruiters
                  </p>
                </div>
                <button
                  onClick={() => onNavigate("projects")}
                  className="text-xs text-blue-600 hover:underline font-semibold shrink-0"
                >
                  Manage
                </button>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 text-right">
            <button
              onClick={() => onNavigate("roadmap")}
              className="text-xs text-slate-500 hover:text-slate-800 font-medium"
            >
              View Full Learning Roadmap →
            </button>
          </div>
        </div>
      </div>

      {/* FEATURED CARDS SECTION (Row of 4 Cards matching Codility Reference) */}
      <div className="space-y-2">
        <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500">
          Featured
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Card 1: Purple Gradient Card */}
          <div
            onClick={() => onNavigate("gap")}
            className="p-4 rounded-2xl bg-gradient-to-br from-purple-800 to-indigo-900 text-white cursor-pointer hover:shadow-md transition-all flex items-center justify-between"
          >
            <div className="space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-bold">
                <span>⚡</span>
                <span>Skills Intelligence</span>
              </div>
              <p className="text-[11px] text-purple-200">
                Identify {gaps.length} gaps in your target profile
              </p>
            </div>
            <span className="text-lg text-purple-300 font-bold">›</span>
          </div>

          {/* Card 2: Blue Outline Card */}
          <div
            onClick={() => onNavigate("assessment")}
            className="p-4 rounded-2xl bg-white border border-blue-200 text-slate-800 cursor-pointer hover:border-blue-400 hover:shadow-xs transition-all flex items-center justify-between"
          >
            <div className="space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-bold text-blue-700">
                <span>⏱</span>
                <span>15-Min Technical Test</span>
              </div>
              <p className="text-[11px] text-slate-500">
                Evaluate 9 engineering categories
              </p>
            </div>
            <span className="text-lg text-blue-500 font-bold">›</span>
          </div>

          {/* Card 3: Light Blue Card with NEW Badge */}
          <div
            onClick={() => onNavigate("projects")}
            className="p-4 rounded-2xl bg-blue-50/70 border border-blue-100 text-slate-800 cursor-pointer hover:bg-blue-50 hover:shadow-xs transition-all flex items-center justify-between"
          >
            <div className="space-y-1">
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-slate-900">Projects & Proof</span>
                <span className="text-[9px] bg-rose-600 text-white px-1.5 py-0.2 rounded font-bold uppercase">
                  NEW
                </span>
              </div>
              <p className="text-[11px] text-slate-500">
                Add code evidence for verified skills
              </p>
            </div>
            <span className="text-lg text-blue-600 font-bold">›</span>
          </div>

          {/* Card 4: Gray Outline Card */}
          <div
            onClick={() => onNavigate("roadmap")}
            className="p-4 rounded-2xl bg-white border border-slate-200 text-slate-800 cursor-pointer hover:border-slate-300 hover:shadow-xs transition-all flex items-center justify-between"
          >
            <div className="space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800">
                <span>🗺️</span>
                <span>Learning Roadmap</span>
              </div>
              <p className="text-[11px] text-slate-500">
                {taskStats.pct}% closed ({taskStats.done}/{taskStats.total} tasks)
              </p>
            </div>
            <span className="text-lg text-slate-400 font-bold">›</span>
          </div>
        </div>
      </div>

      {/* LOWER SECTION: "What's new" 3-Column Grid (Matching Reference Page 4) */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500">
            What&apos;s new & Activities
          </h2>
          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-400">Filter:</span>
            <span className="font-semibold text-slate-700 bg-slate-100 px-2 py-0.5 rounded-md">
              All updates
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {/* Column 1: Candidate / Assessment Results */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between">
            <div>
              <h3 className="text-xs font-bold text-slate-900 mb-3 uppercase tracking-wider">
                Candidates results
              </h3>
              <div className="space-y-3">
                {latestComprehensive ? (
                  <div className="flex items-center gap-3">
                    <span className="w-8 h-8 rounded-full bg-blue-100 text-blue-700 font-bold text-xs flex items-center justify-center shrink-0">
                      CA
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-semibold text-slate-800 truncate">
                        {firstName} scored {latestComprehensive.accuracy}% in Comprehensive Test
                      </p>
                      <p className="text-[10px] text-slate-400">
                        {latestComprehensive.score}/{latestComprehensive.totalQuestions} correct · {new Date(latestComprehensive.timestamp).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                ) : null}

                {assessment ? (
                  <div className="flex items-center gap-3">
                    <span className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-700 font-bold text-xs flex items-center justify-center shrink-0">
                      DG
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-semibold text-slate-800 truncate">
                        {firstName} scored {Math.round((assessment.score / assessment.total) * 100)}% in Diagnostic
                      </p>
                      <p className="text-[10px] text-slate-400">
                        {assessment.score}/{assessment.total} foundational questions passed
                      </p>
                    </div>
                  </div>
                ) : null}

                <div className="flex items-center gap-3">
                  <span className="w-8 h-8 rounded-full bg-slate-100 text-slate-600 font-bold text-xs flex items-center justify-center shrink-0">
                    TI
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-semibold text-slate-800 truncate">
                      Readiness calibrated at {currentReadiness}% for {career?.title}
                    </p>
                    <p className="text-[10px] text-slate-400">
                      Top skills: {Object.keys(skills).slice(0, 3).join(", ")}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <button
              onClick={() => onNavigate("skills")}
              className="mt-4 pt-3 border-t border-slate-100 text-xs text-blue-600 hover:underline font-medium text-left"
            >
              View all evaluated skills →
            </button>
          </div>

          {/* Column 2: Available Screening Assessments */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Screen
                </h3>
                <button
                  onClick={() => onNavigate("assessment")}
                  className="text-xs text-blue-600 font-semibold hover:underline"
                >
                  + Create assessment
                </button>
              </div>

              <div className="space-y-3 text-xs">
                <div
                  onClick={() => onNavigate("assessment")}
                  className="p-3 rounded-xl bg-slate-50 hover:bg-blue-50/50 cursor-pointer border border-slate-100 transition-colors"
                >
                  <p className="font-semibold text-slate-800">15-Minute Technical Assessment</p>
                  <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-1">
                    <span>⏱ 15 min</span>
                    <span>• 30 questions</span>
                    <span>• 9 domains</span>
                  </div>
                </div>

                <div
                  onClick={() => onNavigate("gap")}
                  className="p-3 rounded-xl bg-slate-50 hover:bg-blue-50/50 cursor-pointer border border-slate-100 transition-colors"
                >
                  <p className="font-semibold text-slate-800">Diagnostic Benchmark</p>
                  <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-1">
                    <span>⏱ 5 min</span>
                    <span>• 5 questions</span>
                    <span>• Baseline</span>
                  </div>
                </div>

                <div
                  onClick={() => onNavigate("career")}
                  className="p-3 rounded-xl bg-slate-50 hover:bg-blue-50/50 cursor-pointer border border-slate-100 transition-colors"
                >
                  <p className="font-semibold text-slate-800">{career?.title} Role Spec</p>
                  <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-1">
                    <span>⏱ Self-paced</span>
                    <span>• {career?.required.length} competencies</span>
                  </div>
                </div>
              </div>
            </div>

            <button
              onClick={() => onNavigate("assessment")}
              className="mt-4 pt-3 border-t border-slate-100 text-xs text-blue-600 hover:underline font-medium text-left"
            >
              Start comprehensive screening →
            </button>
          </div>

          {/* Column 3: Interviews & Opportunities */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Interview
                </h3>
                <button
                  onClick={() => onNavigate("opportunities")}
                  className="text-xs text-blue-600 font-semibold hover:underline"
                >
                  + Create interview
                </button>
              </div>

              <div className="space-y-3 text-xs">
                <div
                  onClick={() => onNavigate("opportunities")}
                  className="p-3 rounded-xl bg-slate-50 hover:bg-blue-50/50 cursor-pointer border border-slate-100 transition-colors"
                >
                  <p className="font-semibold text-slate-800">Junior {career?.title}</p>
                  <p className="text-[11px] text-slate-400 mt-0.5">Top Tech Campus Drive · Oct 2026</p>
                </div>

                <div
                  onClick={() => onNavigate("companies")}
                  className="p-3 rounded-xl bg-slate-50 hover:bg-blue-50/50 cursor-pointer border border-slate-100 transition-colors"
                >
                  <p className="font-semibold text-slate-800">Company Match: NVIDIA & Google</p>
                  <p className="text-[11px] text-slate-400 mt-0.5">AI and Accelerated Computing Track</p>
                </div>

                <div
                  onClick={() => onNavigate("opportunities")}
                  className="p-3 rounded-xl bg-slate-50 hover:bg-blue-50/50 cursor-pointer border border-slate-100 transition-colors"
                >
                  <p className="font-semibold text-slate-800">Mock Technical Screening</p>
                  <p className="text-[11px] text-slate-400 mt-0.5">Automated DSA & System Design Review</p>
                </div>
              </div>
            </div>

            <button
              onClick={() => onNavigate("opportunities")}
              className="mt-4 pt-3 border-t border-slate-100 text-xs text-blue-600 hover:underline font-medium text-left"
            >
              Explore all industry opportunities →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
